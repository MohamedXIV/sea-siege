// ============================================================================
// SEA SIEGE — SpacetimeDB Authoritative Server Module (spacetimedb/src/index.ts)
// Defines the authoritative relational schema, reducers, scheduled simulation
// tick, server-side Fog of War views, multi-layer construction, naval combat,
// and server-owned AI Bot decision engine.
// ============================================================================

import { schema, table, t } from 'spacetimedb/server';
import {
  GAME_CONSTANTS,
  FACTION_PALETTES,
  MATCH_PRESETS,
  STRUCTURE_DEFS,
  SHIP_DEFS,
  BOT_DIFFICULTIES,
  TERRAIN_TYPES,
} from '../../src/shared/balance.js';
import { generateDeterministicWorld } from '../../src/shared/worldgen.js';

// ----------------------------------------------------------------------------
// 1. SPACETIMEDB RELATIONAL TABLES
// ----------------------------------------------------------------------------

export const MatchTable = table(
  { name: 'match', public: true },
  {
    matchId: t.string().primaryKey(),
    joinCode: t.string().unique(),
    preset: t.string(),
    status: t.string(), // 'lobby' | 'active' | 'finished'
    seed: t.u32(),
    mapCells: t.u32(),
    maxSlots: t.u32(),
    hostIdentity: t.string(),
    createdAtMs: t.u64(),
    startedAtMs: t.u64(),
    tickCount: t.u64(),
    winnerFactionId: t.i32(), // -1 if none
    victoryReason: t.string(),
    allowLateJoinTakeover: t.bool(),
    fogOfWarEnabled: t.bool(),
  }
);

export const MatchSlotTable = table(
  { name: 'match_slot', public: true },
  {
    slotKey: t.string().primaryKey(), // `${matchId}_${slotIndex}`
    matchId: t.string(),
    slotIndex: t.u32(),
    slotType: t.string(), // 'human' | 'bot' | 'empty'
    occupantIdentity: t.string(),
    playerName: t.string(),
    botDifficulty: t.string(), // 'Cadet' | 'Commander' | 'Admiral'
    factionColor: t.string(),
    ready: t.bool(),
    connected: t.bool(),
    eliminated: t.bool(),
    salvage: t.f64(),
    totalSalvageGathered: t.f64(),
    shipsBuilt: t.u32(),
    shipsLost: t.u32(),
    structuresBuilt: t.u32(),
    enemiesDestroyed: t.u32(),
    weaponUpgradeLevel: t.u32(),
  }
);

export const WorldChunkTable = table(
  { name: 'world_chunk', public: true },
  {
    chunkKey: t.string().primaryKey(), // `${matchId}_${chunkX}_${chunkY}`
    matchId: t.string(),
    chunkX: t.u32(),
    chunkY: t.u32(),
    terrainJson: t.string(),
  }
);

export const ResourceNodeTable = table(
  { name: 'resource_node', public: true },
  {
    nodeKey: t.string().primaryKey(),
    matchId: t.string(),
    gridX: t.u32(),
    gridY: t.u32(),
    capacity: t.f64(),
    remaining: t.f64(),
    regenPerSec: t.f64(),
    isContested: t.bool(),
  }
);

export const StructureTable = table(
  { name: 'structure', public: true },
  {
    structureId: t.string().primaryKey(),
    matchId: t.string(),
    factionId: t.u32(),
    structureType: t.string(), // 'command_core' | 'platform' | 'workshop' | 'shipyard' | 'cannon' | 'salvage_rig'
    channel: t.string(), // 'surface' | 'superstructure'
    gridX: t.u32(),
    gridY: t.u32(),
    width: t.u32(),
    height: t.u32(),
    rotationDeg: t.u32(),
    hp: t.f64(),
    maxHp: t.f64(),
    isComplete: t.bool(),
    builtAtMs: t.u64(),
    completesAtMs: t.u64(),
    isConnected: t.bool(), // Connected to faction's Command Core via contiguous surface platforms
    turretAngleDeg: t.f64(),
    lastFiredAtMs: t.u64(),
    targetEntityId: t.string(),
    productionQueueJson: t.string(), // JSON array of { shipType, startedAtMs, completesAtMs }
  }
);

export const ShipTable = table(
  { name: 'ship', public: true },
  {
    shipId: t.string().primaryKey(),
    matchId: t.string(),
    factionId: t.u32(),
    shipType: t.string(), // 'scout' | 'gunboat' | 'siege'
    x: t.f64(), // World cell coordinates (e.g. 12.5, 18.2)
    y: t.f64(),
    vx: t.f64(),
    vy: t.f64(),
    hullAngleDeg: t.f64(),
    turretAngleDeg: t.f64(),
    hp: t.f64(),
    maxHp: t.f64(),
    orderType: t.string(), // 'idle' | 'move' | 'attack_move' | 'attack_target' | 'harvest' | 'stop'
    targetX: t.f64(),
    targetY: t.f64(),
    targetEntityId: t.string(),
    lastFiredAtMs: t.u64(),
    fleetGroup: t.i32(),
  }
);

export const ProjectileTable = table(
  { name: 'projectile', public: true },
  {
    projectileId: t.string().primaryKey(),
    matchId: t.string(),
    factionId: t.u32(),
    sourceId: t.string(),
    sourceType: t.string(),
    startX: t.f64(),
    startY: t.f64(),
    targetX: t.f64(),
    targetY: t.f64(),
    targetEntityId: t.string(),
    speedCellsPerSec: t.f64(),
    damage: t.f64(),
    structureMultiplier: t.f64(),
    splashRadiusCells: t.f64(),
    spawnedAtMs: t.u64(),
    impactAtMs: t.u64(),
  }
);

export const WorldEventTable = table(
  { name: 'world_event', public: true },
  {
    eventId: t.string().primaryKey(),
    matchId: t.string(),
    eventType: t.string(), // 'muzzle' | 'impact' | 'explosion' | 'splash' | 'built' | 'destroyed' | 'alert'
    x: t.f64(),
    y: t.f64(),
    factionId: t.i32(),
    payloadJson: t.string(),
    timestampMs: t.u64(),
  }
);

export const BotBrainTable = table(
  { name: 'bot_brain', public: false }, // Private server-only table (never exposed to clients)
  {
    botKey: t.string().primaryKey(), // `${matchId}_${slotIndex}`
    matchId: t.string(),
    slotIndex: t.u32(),
    difficulty: t.string(),
    currentGoal: t.string(), // 'expand' | 'economy' | 'build_fleet' | 'defend' | 'siege_attack'
    lastDecisionAtMs: t.u64(),
    targetEnemySlot: t.i32(),
  }
);

export const spacetimedb = schema(
  MatchTable,
  MatchSlotTable,
  WorldChunkTable,
  ResourceNodeTable,
  StructureTable,
  ShipTable,
  ProjectileTable,
  WorldEventTable,
  BotBrainTable
);

export {
  GAME_CONSTANTS,
  FACTION_PALETTES,
  MATCH_PRESETS,
  STRUCTURE_DEFS,
  SHIP_DEFS,
  BOT_DIFFICULTIES,
  TERRAIN_TYPES,
  generateDeterministicWorld,
};
