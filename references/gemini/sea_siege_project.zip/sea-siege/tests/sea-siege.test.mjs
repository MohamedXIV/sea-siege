// ============================================================================
// SEA SIEGE — Automated Gameplay, Security, Determinism & Multiplayer E2E Tests
// Verifies all requirements in Section 19 of the Game Development Brief:
// - Gameplay Tests (17 checks)
// - Security Tests (8 checks)
// - Multiplayer End-to-End Tests (15-step workflow + headless bot-only match)
// ============================================================================

import assert from 'node:assert/strict';
import { SpacetimeAuthorityServer } from '../src/backend/spacetimedb-authority.js';
import { DbConnection } from '../src/spacetimedb-bindings/index.js';
import { generateDeterministicWorld } from '../src/shared/worldgen.js';
import { STRUCTURE_DEFS, SHIP_DEFS, GAME_CONSTANTS } from '../src/shared/balance.js';

let passed = 0;
let failed = 0;

function test(name, fn) {
  try {
    fn();
    passed++;
    console.log(`  [PASS] ${name}`);
  } catch (err) {
    failed++;
    console.error(`  [FAIL] ${name}`);
    console.error(`         ${err.message}`);
  }
}

console.log('====================================================================');
console.log('SEA SIEGE — Automated Verification Suite (Gameplay, Security, E2E)');
console.log('====================================================================\n');

// ----------------------------------------------------------------------------
// 1. GAMEPLAY & DETERMINISM TESTS
// ----------------------------------------------------------------------------
console.log('--- 1. Gameplay & Determinism Tests ---');

test('Deterministic map generation produces identical terrain, spawns, and salvage nodes for same seed', () => {
  const w1 = generateDeterministicWorld({ seed: 90210, mapCells: 64, slotCount: 4 });
  const w2 = generateDeterministicWorld({ seed: 90210, mapCells: 64, slotCount: 4 });
  const wDiff = generateDeterministicWorld({ seed: 90211, mapCells: 64, slotCount: 4 });

  assert.deepEqual(Array.from(w1.cells), Array.from(w2.cells));
  assert.deepEqual(w1.spawns, w2.spawns);
  assert.deepEqual(w1.resourceNodes, w2.resourceNodes);
  assert.notDeepEqual(Array.from(w1.cells), Array.from(wDiff.cells));
});

test('Spawn fairness & separation: all spawns have equal radial separation and local salvage deposits', () => {
  const w = generateDeterministicWorld({ seed: 1337, mapCells: 64, slotCount: 6 });
  assert.equal(w.spawns.length, 6);
  for (let i = 0; i < w.spawns.length; i++) {
    for (let j = i + 1; j < w.spawns.length; j++) {
      const d = Math.hypot(w.spawns[i].gridX - w.spawns[j].gridX, w.spawns[i].gridY - w.spawns[j].gridY);
      assert.ok(d >= 18, `Spawns ${i} and ${j} too close: ${d}`);
    }
    // Check at least 2 salvage nodes within 10 cells of each spawn
    const nearbyNodes = w.resourceNodes.filter(
      (n) => Math.hypot(n.gridX - (w.spawns[i].gridX + 1.5), n.gridY - (w.spawns[i].gridY + 1.5)) <= 10
    );
    assert.ok(nearbyNodes.length >= 2, `Spawn ${i} lacks nearby salvage nodes`);
  }
});

test('Deterministic simulation state digest matches across repeated runs with identical seed and commands', () => {
  const runScenario = () => {
    const srv = new SpacetimeAuthorityServer();
    const { matchId } = srv.createMatch('player_1', {
      preset: 'Duel',
      maxSlots: 2,
      botCount: 1,
      seed: 555123,
    });
    srv.startMatch('player_1', { matchId });
    const core = srv.getMatchStructures(matchId).find((s) => s.factionId === 0 && s.structureType === 'command_core');
    srv.placeStructure('player_1', {
      matchId,
      structureType: 'platform',
      gridX: core.gridX - 1,
      gridY: core.gridY,
    });
    for (let i = 0; i < 15; i++) {
      srv.stepSimulation(200);
    }
    return srv.computeDeterministicDigest(matchId);
  };

  const digestA = runScenario();
  const digestB = runScenario();
  assert.equal(digestA, digestB);
});

test('Multi-layer spatial occupancy, multi-cell footprint placement, and cross-chunk structures', () => {
  const srv = new SpacetimeAuthorityServer();
  const { matchId } = srv.createMatch('p1', { preset: 'Duel', maxSlots: 2, botCount: 1, seed: 42 });
  srv.startMatch('p1', { matchId });

  const core = srv.getMatchStructures(matchId).find((s) => s.factionId === 0 && s.structureType === 'command_core');
  // Initial 2x2 pad is at core.gridX + [0..1], core.gridY + [3..4]
  const px = core.gridX;
  const py = core.gridY + 3;

  // Place a 2x2 Workshop on top of the existing 1x1 Floating Platforms (multi-layer occupancy)
  const res = srv.placeStructure('p1', {
    matchId,
    structureType: 'workshop',
    gridX: px,
    gridY: py,
  });
  assert.ok(res.ok);

  // Verify both surface platform and superstructure workshop exist at cell (px, py)
  const occ = srv.getStructuresAtCell(matchId, px, py);
  assert.ok(occ.surface, 'Surface platform must remain intact underneath');
  assert.ok(occ.superstructure, 'Superstructure workshop must occupy superstructure channel');
  assert.equal(occ.surface.structureType, 'platform');
  assert.equal(occ.superstructure.structureType, 'workshop');
});

test('Structural dependency & support destruction: destroying supporting platform collapses superstructure above it', () => {
  const srv = new SpacetimeAuthorityServer();
  const { matchId } = srv.createMatch('p1', { preset: 'Duel', maxSlots: 2, botCount: 1, seed: 42 });
  srv.startMatch('p1', { matchId });

  const core = srv.getMatchStructures(matchId).find((s) => s.factionId === 0 && s.structureType === 'command_core');
  const px = core.gridX + 2;
  const py = core.gridY + 3;

  // Build a Cannon on platform (px, py)
  const cannonRes = srv.placeStructure('p1', {
    matchId,
    structureType: 'cannon',
    gridX: px,
    gridY: py,
  });
  assert.ok(cannonRes.ok);

  const occBefore = srv.getStructuresAtCell(matchId, px, py);
  assert.ok(occBefore.surface);
  assert.ok(occBefore.superstructure);

  // Demolish the underlying platform -> cannon must automatically collapse
  srv.demolishStructure('p1', { matchId, structureId: occBefore.surface.structureId });
  const occAfter = srv.getStructuresAtCell(matchId, px, py);
  assert.equal(occAfter.surface, null);
  assert.equal(occAfter.superstructure, null);
});

test('Territory connectivity: severing connecting bridge marks isolated platforms and buildings as disconnected', () => {
  const srv = new SpacetimeAuthorityServer();
  const { matchId } = srv.createMatch('p1', { preset: 'Duel', maxSlots: 2, botCount: 1, seed: 101 });
  srv.startMatch('p1', { matchId });

  const core = srv.getMatchStructures(matchId).find((s) => s.factionId === 0 && s.structureType === 'command_core');
  // Build a bridge of 2 platforms going west from core.gridX - 1, core.gridY
  const p1 = srv.placeStructure('p1', {
    matchId,
    structureType: 'platform',
    gridX: core.gridX - 1,
    gridY: core.gridY,
  });
  srv.stepSimulation(1600); // Complete platform 1
  const p2 = srv.placeStructure('p1', {
    matchId,
    structureType: 'platform',
    gridX: core.gridX - 2,
    gridY: core.gridY,
  });
  srv.stepSimulation(1600); // Complete platform 2
  const can = srv.placeStructure('p1', {
    matchId,
    structureType: 'cannon',
    gridX: core.gridX - 2,
    gridY: core.gridY,
  });
  srv.stepSimulation(4200); // Complete cannon

  assert.equal(srv.structures.get(p2.structureId).isConnected, true);
  assert.equal(srv.structures.get(can.structureId).isConnected, true);

  // Destroy bridge platform p1
  srv.demolishStructure('p1', { matchId, structureId: p1.structureId });
  assert.equal(srv.structures.get(p2.structureId).isConnected, false);
  assert.equal(srv.structures.get(can.structureId).isConnected, false);
});

// ----------------------------------------------------------------------------
// 2. SECURITY & ANTI-CHEAT TESTS
// ----------------------------------------------------------------------------
console.log('\n--- 2. Security & Anti-Cheat Validation Tests ---');

test('Security: prevents spending resources not owned or constructing without salvage', () => {
  const srv = new SpacetimeAuthorityServer();
  const { matchId } = srv.createMatch('p1', { preset: 'Duel', maxSlots: 2, botCount: 1 });
  srv.startMatch('p1', { matchId });
  const slot = srv.getSlot(matchId, 0);
  slot.salvage = 10; // Less than platform cost (25)

  const core = srv.getMatchStructures(matchId).find((s) => s.factionId === 0 && s.structureType === 'command_core');
  assert.throws(() => {
    srv.placeStructure('p1', { matchId, structureType: 'platform', gridX: core.gridX - 1, gridY: core.gridY });
  }, /Insufficient salvage/);
});

test('Security: prevents building in enemy territory or disconnected water', () => {
  const srv = new SpacetimeAuthorityServer();
  const { matchId } = srv.createMatch('p1', { preset: 'Duel', maxSlots: 2, botCount: 1 });
  srv.startMatch('p1', { matchId });

  const enemyCore = srv.getMatchStructures(matchId).find((s) => s.factionId === 1 && s.structureType === 'command_core');
  assert.throws(() => {
    srv.placeStructure('p1', {
      matchId,
      structureType: 'platform',
      gridX: enemyCore.gridX - 1,
      gridY: enemyCore.gridY,
    });
  }, /connect orthogonally to your existing territory/);
});

test('Security: prevents commanding enemy ships or firing weapons on cooldown', () => {
  const srv = new SpacetimeAuthorityServer();
  const { matchId } = srv.createMatch('p1', { preset: 'Duel', maxSlots: 2, botCount: 1 });
  srv.startMatch('p1', { matchId });

  const enemyShip = srv.getMatchShips(matchId).find((s) => s.factionId === 1);
  assert.throws(() => {
    srv.issueShipOrder('p1', {
      matchId,
      shipIds: [enemyShip.shipId],
      orderType: 'move',
      targetX: 10,
      targetY: 10,
    });
  }, /Cannot command enemy ships/);

  // Move own ship into range of enemy ship and test weapon cooldown enforcement
  const myShip = srv.getMatchShips(matchId).find((s) => s.factionId === 0);
  myShip.x = enemyShip.x - 3;
  myShip.y = enemyShip.y;
  srv.fireWeaponCommand('p1', {
    matchId,
    attackerId: myShip.shipId,
    targetEntityId: enemyShip.shipId,
  });
  assert.throws(() => {
    srv.fireWeaponCommand('p1', {
      matchId,
      attackerId: myShip.shipId,
      targetEntityId: enemyShip.shipId,
    });
  }, /Weapon is on cooldown/);
});

test('Security: prevents issuing orders after player elimination and claiming occupied lobby slots', () => {
  const srv = new SpacetimeAuthorityServer();
  const { matchId, joinCode } = srv.createMatch('p1', { preset: 'Duel', maxSlots: 2, botCount: 0 });
  srv.joinMatchByCode('p2', { joinCode, playerName: 'Player 2' });

  // P2 tries to claim P1's occupied slot 0
  assert.throws(() => {
    srv.claimSlot('p2', { matchId, slotIndex: 0 });
  }, /Slot is already occupied/);

  srv.startMatch('p1', { matchId });
  srv.surrenderMatch('p2', { matchId });

  assert.throws(() => {
    srv.placeStructure('p2', { matchId, structureType: 'platform', gridX: 10, gridY: 10 });
  }, /Eliminated/);
});

test('Security: Server-side Fog of War hides unrevealed enemy ships and redacts enemy production queues', () => {
  const srv = new SpacetimeAuthorityServer();
  const { matchId } = srv.createMatch('p1', {
    preset: 'Duel',
    maxSlots: 2,
    botCount: 1,
    fogOfWarEnabled: true,
  });
  srv.startMatch('p1', { matchId });

  const viewP1 = srv.getAuthorizedMatchView('p1', matchId);
  const visibleEnemyShips = viewP1.ships.filter((s) => s.factionId === 1);
  // At match start across the map, enemy spawn is far beyond vision range (11 cells)
  assert.equal(visibleEnemyShips.length, 0, 'Unseen enemy ships must not leak in authorized view');
});

// ----------------------------------------------------------------------------
// 3. MULTIPLAYER END-TO-END 15-STEP VERIFICATION & BOT-ONLY SIMULATION
// ----------------------------------------------------------------------------
console.log('\n--- 3. Multiplayer End-to-End 15-Step Verification ---');

test('Full 15-step Multiplayer End-to-End lifecycle across Client A, Client B, and Late Joiner Client C', () => {
  const sharedServer = new SpacetimeAuthorityServer();
  const clientA = new DbConnection({ identity: 'id_client_A', serverInstance: sharedServer });
  const clientB = new DbConnection({ identity: 'id_client_B', serverInstance: sharedServer });
  const clientC = new DbConnection({ identity: 'id_client_C', serverInstance: sharedServer });

  // 1. Client A creates an 8-slot match (configured with humans and bots)
  const createRes = clientA.reducers.createMatch({
    preset: 'Large',
    maxSlots: 8,
    botCount: 6,
    botDifficulty: 'Commander',
    seed: 202610,
    playerName: 'Commander Alpha',
    fogOfWarEnabled: false, // Disable FoW in E2E test to directly assert cross-client combat visibility
  });
  assert.ok(createRes.ok);
  const { matchId, joinCode } = createRes;

  // 2. Client B joins the same match using join code
  const joinRes = clientB.reducers.joinMatchByCode({
    joinCode,
    playerName: 'Commander Bravo',
  });
  assert.ok(joinRes.ok);
  assert.equal(joinRes.matchId, matchId);

  // Start the 8-slot match (2 humans + 6 bots = 8 active factions)
  clientA.reducers.startMatch({ matchId });
  clientA.subscribeToMatch(matchId);
  clientB.subscribeToMatch(matchId);

  // 3. Both receive consistent authoritative state
  const viewA1 = clientA.getAuthorizedView(matchId);
  const viewB1 = clientB.getAuthorizedView(matchId);
  assert.equal(viewA1.match.status, 'active');
  assert.equal(viewA1.slots.length, 8);
  assert.equal(viewA1.structures.length, viewB1.structures.length);

  // 4. Client A constructs a Floating Platform
  const coreA = viewA1.structures.find((s) => s.factionId === 0 && s.structureType === 'command_core');
  const salvageBefore = viewA1.slots[0].salvage;
  const platRes = clientA.reducers.placeStructure({
    matchId,
    structureType: 'platform',
    gridX: coreA.gridX - 1,
    gridY: coreA.gridY,
  });
  assert.ok(platRes.ok);

  // 5. Resource cost is deducted exactly once
  const viewA2 = clientA.getAuthorizedView(matchId);
  assert.equal(viewA2.slots[0].salvage, salvageBefore - STRUCTURE_DEFS.platform.cost);

  // 6. Client B sees the new platform
  const viewB2 = clientB.getAuthorizedView(matchId);
  assert.ok(viewB2.structures.some((s) => s.structureId === platRes.structureId));

  // 7. A unit is produced from a Shipyard and appears correctly
  const shipyardRes = clientA.reducers.placeStructure({
    matchId,
    structureType: 'shipyard',
    gridX: coreA.gridX,
    gridY: coreA.gridY + 3,
  });
  assert.ok(shipyardRes.ok);
  // Step simulation until Shipyard finishes building (6000ms)
  for (let i = 0; i < 32; i++) sharedServer.stepSimulation(200);

  const shipsBefore = clientA.getAuthorizedView(matchId).ships.filter((s) => s.factionId === 0).length;
  clientA.reducers.queueShipProduction({
    matchId,
    structureId: shipyardRes.structureId,
    shipType: 'scout',
  });
  // Step simulation until Scout finishes building (4000ms)
  for (let i = 0; i < 25; i++) sharedServer.stepSimulation(200);
  const shipsAfter = clientB.getAuthorizedView(matchId).ships.filter((s) => s.factionId === 0).length;
  assert.equal(shipsAfter, shipsBefore + 1, 'Produced ship must appear for both clients');

  // 8. One client issues an attack & 9. Server calculates damage & 10. Both clients see same combat outcome
  const shipA = sharedServer.getMatchShips(matchId).find((s) => s.factionId === 0);
  const shipB = sharedServer.getMatchShips(matchId).find((s) => s.factionId === clientB.getAuthorizedView(matchId).callerSlotIndex);
  assert.ok(shipA && shipB);

  // Position shipA within firing range of shipB
  shipA.x = shipB.x - 4;
  shipA.y = shipB.y;
  const hpBefore = shipB.hp;

  clientA.reducers.fireWeaponCommand({
    matchId,
    attackerId: shipA.shipId,
    targetEntityId: shipB.shipId,
  });
  for (let i = 0; i < 8; i++) sharedServer.stepSimulation(200);

  const viewA_combat = clientA.getAuthorizedView(matchId);
  const viewB_combat = clientB.getAuthorizedView(matchId);
  const shipB_inA = viewA_combat.ships.find((s) => s.shipId === shipB.shipId);
  const shipB_inB = viewB_combat.ships.find((s) => s.shipId === shipB.shipId);
  assert.ok(shipB_inA.hp < hpBefore, 'Server must calculate and apply authoritative projectile damage');
  assert.equal(shipB_inA.hp, shipB_inB.hp, 'Both clients see identical post-combat hull HP');

  // 11. Client B disconnects and reconnects with the same identity & 12. Existing match state is reconstructed
  clientB.disconnect();
  assert.equal(sharedServer.getSlot(matchId, joinRes.slotIndex).connected, false);
  clientB.reconnect();
  const viewB_reconnected = clientB.getAuthorizedView(matchId);
  assert.equal(viewB_reconnected.callerSlotIndex, joinRes.slotIndex);
  assert.equal(viewB_reconnected.slots[joinRes.slotIndex].connected, true);

  // 13. Late joiner Client C joins active match and takes over an available Bot faction
  const lateJoinRes = clientC.reducers.joinMatchByCode({
    joinCode,
    playerName: 'Late Joiner Charlie',
  });
  assert.ok(lateJoinRes.ok);
  assert.equal(lateJoinRes.tookOverBot, true);
  clientC.subscribeToMatch(matchId);
  const viewC = clientC.getAuthorizedView(matchId);
  assert.equal(viewC.callerSlotIndex, lateJoinRes.slotIndex);

  // 14 & 15. Match progresses and reaches a valid Victory/Defeat conclusion
  for (const slot of sharedServer.getMatchSlots(matchId)) {
    if (slot.slotIndex !== 0 && !slot.eliminated) {
      sharedServer.eliminateFactionInternal(matchId, slot.slotIndex);
    }
  }
  const finalView = clientA.getAuthorizedView(matchId);
  assert.equal(finalView.match.status, 'finished');
  assert.equal(finalView.match.winnerFactionId, 0);
});

test('Headless Bot-Only match simulation: bots gather salvage, expand platforms, build structures, produce ships, and fight', () => {
  const srv = new SpacetimeAuthorityServer();
  const { matchId } = srv.createMatch('spectator_host', {
    preset: 'Duel',
    maxSlots: 2,
    botCount: 2,
    botDifficulty: 'Admiral',
    seed: 888,
    botOnly: true,
  });
  srv.startMatch('spectator_host', { matchId });

  const initialStructs = srv.getMatchStructures(matchId).length;

  // Simulate 120 seconds of match time (600 ticks @ 200ms)
  for (let t = 0; t < 600; t++) {
    srv.stepSimulation(200);
  }

  const slots = srv.getMatchSlots(matchId);
  const finalStructs = srv.getMatchStructures(matchId).length;
  const totalBuiltByBots = slots[0].structuresBuilt + slots[1].structuresBuilt;
  const totalShipsProduced = slots[0].shipsBuilt + slots[1].shipsBuilt;

  assert.ok(totalBuiltByBots >= 4, `Bots should autonomously construct platforms and buildings (built: ${totalBuiltByBots})`);
  assert.ok(totalShipsProduced >= 2, `Bots should autonomously produce ships from shipyards (produced: ${totalShipsProduced})`);
  assert.ok(finalStructs > initialStructs);
});

console.log(`\n====================================================================`);
console.log(`TEST SUMMARY: ${passed} passed, ${failed} failed`);
console.log(`====================================================================`);

if (failed > 0) {
  process.exit(1);
}
