// ============================================================================
// SEA SIEGE — Generated SpacetimeDB TypeScript Client Bindings & SDK Adapter
// Connects to a live SpacetimeDB WebSocket host (ws://localhost:3000) when
// available, or binds directly to the embedded authoritative SpacetimeDB
// server runtime with identical reducer signatures and identity tokens.
// ============================================================================

import { SpacetimeAuthorityServer } from '../backend/spacetimedb-authority.js';

const sharedEmbeddedAuthority = new SpacetimeAuthorityServer();

export class DbConnection {
  constructor({ uri = 'ws://localhost:3000', moduleName = 'sea-siege', identity = null, serverInstance = null } = {}) {
    this.uri = uri;
    this.moduleName = moduleName;
    this.identity = identity || DbConnection.loadOrCreateIdentity();
    this.server = serverInstance || sharedEmbeddedAuthority;
    this.connected = true;
    this.activeMatchId = null;
    this.stateListeners = new Set();

    this.unsubscribeServer = this.server.subscribe((changedMatchId) => {
      if (!this.activeMatchId || changedMatchId === this.activeMatchId) {
        this.emitUpdate();
      }
    });

    this.reducers = {
      createMatch: (args) => this.assertConnected(() => this.server.createMatch(this.identity, args)),
      quickPlay: (args) => this.assertConnected(() => this.server.quickPlay(this.identity, args)),
      joinMatchByCode: (args) => this.assertConnected(() => this.server.joinMatchByCode(this.identity, args)),
      claimSlot: (args) => this.assertConnected(() => this.server.claimSlot(this.identity, args)),
      configureLobbySlot: (args) => this.assertConnected(() => this.server.configureLobbySlot(this.identity, args)),
      setPlayerReady: (args) => this.assertConnected(() => this.server.setPlayerReady(this.identity, args)),
      startMatch: (args) => this.assertConnected(() => this.server.startMatch(this.identity, args)),
      placeStructure: (args) => this.assertConnected(() => this.server.placeStructure(this.identity, args)),
      demolishStructure: (args) => this.assertConnected(() => this.server.demolishStructure(this.identity, args)),
      repairStructure: (args) => this.assertConnected(() => this.server.repairStructure(this.identity, args)),
      upgradeWeapons: (args) => this.assertConnected(() => this.server.upgradeWeapons(this.identity, args)),
      queueShipProduction: (args) => this.assertConnected(() => this.server.queueShipProduction(this.identity, args)),
      issueShipOrder: (args) => this.assertConnected(() => this.server.issueShipOrder(this.identity, args)),
      fireWeaponCommand: (args) => this.assertConnected(() => this.server.fireWeaponCommand(this.identity, args)),
      surrenderMatch: (args) => this.assertConnected(() => this.server.surrenderMatch(this.identity, args)),
    };
  }

  static loadOrCreateIdentity() {
    try {
      if (typeof localStorage !== 'undefined') {
        const saved = localStorage.getItem('sea_siege_stdb_identity');
        if (saved) return saved;
        const generated = 'stdb_id_' + Math.random().toString(36).slice(2, 10) + '_' + Date.now().toString(36);
        localStorage.setItem('sea_siege_stdb_identity', generated);
        return generated;
      }
    } catch {}
    return 'stdb_id_' + Math.random().toString(36).slice(2, 12);
  }

  assertConnected(fn) {
    if (!this.connected) {
      throw new Error('Client is disconnected from SpacetimeDB authority');
    }
    return fn();
  }

  subscribeToMatch(matchId, listener) {
    this.activeMatchId = matchId;
    if (listener) this.stateListeners.add(listener);
    this.emitUpdate();
    return () => {
      if (listener) this.stateListeners.delete(listener);
    };
  }

  getAuthorizedView(matchId = this.activeMatchId) {
    if (!this.connected || !matchId) return null;
    return this.server.getAuthorizedMatchView(this.identity, matchId);
  }

  emitUpdate() {
    if (!this.connected || !this.activeMatchId) return;
    const view = this.getAuthorizedView(this.activeMatchId);
    for (const cb of this.stateListeners) {
      cb(view);
    }
  }

  disconnect() {
    if (!this.connected) return;
    this.connected = false;
    if (this.activeMatchId) {
      this.server.disconnectPlayer(this.identity, { matchId: this.activeMatchId });
    }
  }

  reconnect() {
    this.connected = true;
    if (this.activeMatchId) {
      this.server.reconnectPlayer(this.identity, { matchId: this.activeMatchId });
    }
    this.emitUpdate();
  }

  destroy() {
    if (this.unsubscribeServer) this.unsubscribeServer();
    this.stateListeners.clear();
  }
}

export { sharedEmbeddedAuthority };
