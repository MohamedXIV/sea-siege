// ============================================================================
// SEA SIEGE — Deterministic Seeded World & Map Generator
// Uses Mulberry32 PRNG and radially symmetric chokepoint/salvage placement
// so all 2-8 spawn positions have fair access to resources and sea lanes.
// ============================================================================

import { GAME_CONSTANTS, TERRAIN_TYPES } from './balance.js';

export function createSeededRng(seed) {
  let state = (seed >>> 0) || 0x1337beef;
  return function nextFloat() {
    state = (state + 0x6d2b79f5) >>> 0;
    let t = Math.imul(state ^ (state >>> 15), 1 | state);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function generateDeterministicWorld({ seed = 424242, mapCells = 64, slotCount = 4 }) {
  const rng = createSeededRng(seed);
  const cells = new Uint8Array(mapCells * mapCells);
  cells.fill(TERRAIN_TYPES.DEEP_WATER);

  const center = mapCells / 2;
  const spawnRadius = Math.floor(mapCells * 0.36);

  // 1. Compute fair radial spawn anchor coordinates (grid cell centers for 3x3 Command Core)
  const spawns = [];
  const effectiveSlots = Math.max(2, Math.min(8, slotCount));
  for (let i = 0; i < effectiveSlots; i++) {
    const angle = (i * 2 * Math.PI) / effectiveSlots + Math.PI / 4;
    const sx = Math.round(center + Math.cos(angle) * spawnRadius) - 1;
    const sy = Math.round(center + Math.sin(angle) * spawnRadius) - 1;
    spawns.push({
      slotIndex: i,
      gridX: Math.max(4, Math.min(mapCells - 7, sx)),
      gridY: Math.max(4, Math.min(mapCells - 7, sy)),
      angle,
    });
  }

  const isNearAnySpawn = (gx, gy, minDist) => {
    for (const sp of spawns) {
      const dx = gx - (sp.gridX + 1.5);
      const dy = gy - (sp.gridY + 1.5);
      if (Math.hypot(dx, dy) < minDist) return true;
    }
    return false;
  };

  // 2. Place central drowned industrial megastructure ring & strategic chokepoints
  const ringRadius = Math.floor(mapCells * 0.16);
  const numPillars = Math.max(4, effectiveSlots);
  for (let i = 0; i < numPillars; i++) {
    const baseAngle = (i * 2 * Math.PI) / numPillars + (rng() - 0.5) * 0.18;
    const px = Math.round(center + Math.cos(baseAngle) * ringRadius);
    const py = Math.round(center + Math.sin(baseAngle) * ringRadius);
    for (let dy = -1; dy <= 1; dy++) {
      for (let dx = -1; dx <= 1; dx++) {
        const x = px + dx;
        const y = py + dy;
        if (x >= 2 && x < mapCells - 2 && y >= 2 && y < mapCells - 2 && !isNearAnySpawn(x, y, 8)) {
          if (Math.abs(dx) + Math.abs(dy) <= 1 || rng() < 0.45) {
            cells[y * mapCells + x] = TERRAIN_TYPES.RUINED_PILLAR;
          } else {
            cells[y * mapCells + x] = TERRAIN_TYPES.SHALLOW_WATER;
          }
        }
      }
    }
  }

  // 3. Place symmetrical mid-sea wreckage shoals and shallow industrial banks
  const numShoals = Math.floor(mapCells / 6);
  for (let s = 0; s < numShoals; s++) {
    const dist = (0.22 + rng() * 0.24) * mapCells;
    const baseTheta = rng() * Math.PI;
    // Mirror across center for fairness
    for (let m = 0; m < 2; m++) {
      const theta = baseTheta + m * Math.PI;
      const wx = Math.round(center + Math.cos(theta) * dist);
      const wy = Math.round(center + Math.sin(theta) * dist);
      if (wx >= 3 && wx < mapCells - 3 && wy >= 3 && wy < mapCells - 3 && !isNearAnySpawn(wx, wy, 9)) {
        cells[wy * mapCells + wx] = TERRAIN_TYPES.WRECKAGE_SHOAL;
        for (const [ox, oy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
          const nx = wx + ox;
          const ny = wy + oy;
          if (cells[ny * mapCells + nx] === TERRAIN_TYPES.DEEP_WATER) {
            cells[ny * mapCells + nx] = TERRAIN_TYPES.SHALLOW_WATER;
          }
        }
      }
    }
  }

  // 4. Generate Salvage Resource Nodes:
  //    - 2 local expansion salvage deposits near each spawn
  //    - Contested high-yield salvage deposits in the central industrial basin and mid-ring
  const resourceNodes = [];
  let nodeIdCounter = 1;

  for (const sp of spawns) {
    const cx = sp.gridX + 1.5;
    const cy = sp.gridY + 1.5;
    const inwardAngle = Math.atan2(center - cy, center - cx);

    const offsets = [
      { dist: 6.5, angleOffset: -0.48, amount: 850, regenPerSec: 2 },
      { dist: 7.2, angleOffset: 0.48, amount: 850, regenPerSec: 2 },
    ];
    for (const off of offsets) {
      const nx = Math.round(cx + Math.cos(inwardAngle + off.angleOffset) * off.dist);
      const ny = Math.round(cy + Math.sin(inwardAngle + off.angleOffset) * off.dist);
      if (nx >= 2 && nx < mapCells - 2 && ny >= 2 && ny < mapCells - 2) {
        cells[ny * mapCells + nx] = TERRAIN_TYPES.SHALLOW_WATER;
        resourceNodes.push({
          id: `node_${nodeIdCounter++}`,
          gridX: nx,
          gridY: ny,
          capacity: off.amount,
          remaining: off.amount,
          regenPerSec: off.regenPerSec,
          isContested: false,
        });
      }
    }
  }

  // Contested central & mid-ring salvage nodes
  const contestedCount = Math.max(4, effectiveSlots);
  for (let i = 0; i < contestedCount; i++) {
    const angle = (i * 2 * Math.PI) / contestedCount;
    const dist = Math.floor(mapCells * 0.09);
    const nx = Math.round(center + Math.cos(angle) * dist);
    const ny = Math.round(center + Math.sin(angle) * dist);
    if (nx >= 2 && nx < mapCells - 2 && ny >= 2 && ny < mapCells - 2) {
      cells[ny * mapCells + nx] = TERRAIN_TYPES.SHALLOW_WATER;
      resourceNodes.push({
        id: `node_${nodeIdCounter++}`,
        gridX: nx,
        gridY: ny,
        capacity: 1400,
        remaining: 1400,
        regenPerSec: 4,
        isContested: true,
      });
    }
  }

  // Partition into chunks (16x16)
  const chunkDim = Math.ceil(mapCells / GAME_CONSTANTS.CHUNK_SIZE);
  const chunks = [];
  for (let cy = 0; cy < chunkDim; cy++) {
    for (let cx = 0; cx < chunkDim; cx++) {
      const encodedCells = [];
      for (let ly = 0; ly < GAME_CONSTANTS.CHUNK_SIZE; ly++) {
        for (let lx = 0; lx < GAME_CONSTANTS.CHUNK_SIZE; lx++) {
          const gx = cx * GAME_CONSTANTS.CHUNK_SIZE + lx;
          const gy = cy * GAME_CONSTANTS.CHUNK_SIZE + ly;
          if (gx < mapCells && gy < mapCells) {
            encodedCells.push(cells[gy * mapCells + gx]);
          } else {
            encodedCells.push(TERRAIN_TYPES.DEEP_WATER);
          }
        }
      }
      chunks.push({
        chunkId: `${cx}_${cy}`,
        chunkX: cx,
        chunkY: cy,
        terrainData: encodedCells,
      });
    }
  }

  return {
    seed,
    mapCells,
    cells,
    chunks,
    spawns,
    resourceNodes,
  };
}
