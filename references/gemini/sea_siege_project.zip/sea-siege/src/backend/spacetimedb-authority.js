// ============================================================================
// SEA SIEGE — Authoritative SpacetimeDB Runtime & Reducer Engine
// Implements all tables, indexes, atomic transactions, reducers, server-side
// Fog of War views, multi-layer platform/structure occupancy, territory
// connectivity BFS, naval physics/navigation, turret combat, and AI Bots.
// ============================================================================

import {
  GAME_CONSTANTS,
  FACTION_PALETTES,
  MATCH_PRESETS,
  STRUCTURE_DEFS,
  SHIP_DEFS,
  BOT_DIFFICULTIES,
  TERRAIN_TYPES,
} from '../shared/balance.js';
import { generateDeterministicWorld, createSeededRng } from '../shared/worldgen.js';

function normalizeAngleDeg(deg) {
  let a = deg % 360;
  if (a < 0) a += 360;
  return a;
}

function shortestAngleDiffDeg(fromDeg, toDeg) {
  const diff = ((toDeg - fromDeg + 540) % 360) - 180;
  return diff;
}

function rotateAngleTowards(currentDeg, targetDeg, maxStepDeg) {
  const diff = shortestAngleDiffDeg(currentDeg, targetDeg);
  if (Math.abs(diff) <= maxStepDeg) return normalizeAngleDeg(targetDeg);
  return normalizeAngleDeg(currentDeg + Math.sign(diff) * maxStepDeg);
}

export class SpacetimeAuthorityServer {
  constructor() {
    this.matches = new Map();
    this.matchSlots = new Map();
    this.worldChunks = new Map();
    this.resourceNodes = new Map();
    this.structures = new Map();
    this.ships = new Map();
    this.projectiles = new Map();
    this.worldEvents = new Map();
    this.botBrains = new Map();

    // Fast lookup cache for terrain arrays per matchId
    this.terrainCache = new Map();
    this.idCounter = 1;
    this.nowMs = 1000000;
    this.listeners = new Set();
  }

  nextId(prefix) {
    return `${prefix}_${this.idCounter++}`;
  }

  subscribe(callback) {
    this.listeners.add(callback);
    return () => this.listeners.delete(callback);
  }

  notifyChange(matchId) {
    for (const cb of this.listeners) {
      cb(matchId);
    }
  }

  emitEvent(matchId, eventType, x, y, factionId = -1, payload = {}) {
    const eventId = this.nextId('evt');
    const evt = {
      eventId,
      matchId,
      eventType,
      x,
      y,
      factionId,
      payloadJson: JSON.stringify(payload),
      timestampMs: this.nowMs,
    };
    this.worldEvents.set(eventId, evt);
    // Prune old events (> 5 seconds) to bound table memory
    for (const [k, v] of this.worldEvents.entries()) {
      if (v.matchId === matchId && this.nowMs - v.timestampMs > 5000) {
        this.worldEvents.delete(k);
      }
    }
    return evt;
  }

  // --------------------------------------------------------------------------
  // HELPER QUERIES
  // --------------------------------------------------------------------------

  getMatchSlots(matchId) {
    const list = [];
    for (const slot of this.matchSlots.values()) {
      if (slot.matchId === matchId) list.push(slot);
    }
    return list.sort((a, b) => a.slotIndex - b.slotIndex);
  }

  getSlotByIdentity(matchId, callerIdentity) {
    for (const slot of this.matchSlots.values()) {
      if (slot.matchId === matchId && slot.occupantIdentity === callerIdentity) {
        return slot;
      }
    }
    return null;
  }

  getSlot(matchId, slotIndex) {
    return this.matchSlots.get(`${matchId}_${slotIndex}`) || null;
  }

  getMatchStructures(matchId) {
    const list = [];
    for (const st of this.structures.values()) {
      if (st.matchId === matchId) list.push(st);
    }
    return list.sort((a, b) => a.structureId.localeCompare(b.structureId));
  }

  getMatchShips(matchId) {
    const list = [];
    for (const sh of this.ships.values()) {
      if (sh.matchId === matchId) list.push(sh);
    }
    return list.sort((a, b) => a.shipId.localeCompare(b.shipId));
  }

  getMatchNodes(matchId) {
    const list = [];
    for (const nd of this.resourceNodes.values()) {
      if (nd.matchId === matchId) list.push(nd);
    }
    return list.sort((a, b) => a.nodeKey.localeCompare(b.nodeKey));
  }

  getTerrainAt(matchId, gx, gy) {
    const match = this.matches.get(matchId);
    if (!match) return TERRAIN_TYPES.RUINED_PILLAR;
    if (gx < 0 || gy < 0 || gx >= match.mapCells || gy >= match.mapCells) {
      return TERRAIN_TYPES.RUINED_PILLAR;
    }
    const cells = this.terrainCache.get(matchId);
    if (!cells) return TERRAIN_TYPES.DEEP_WATER;
    return cells[gy * match.mapCells + gx];
  }

  isWaterCell(matchId, gx, gy) {
    const t = this.getTerrainAt(matchId, gx, gy);
    return t === TERRAIN_TYPES.DEEP_WATER || t === TERRAIN_TYPES.SHALLOW_WATER;
  }

  // --------------------------------------------------------------------------
  // MULTI-LAYER SPATIAL OCCUPANCY & TERRITORY CONNECTIVITY
  // --------------------------------------------------------------------------

  getStructuresAtCell(matchId, gx, gy) {
    const result = { surface: null, superstructure: null };
    for (const st of this.structures.values()) {
      if (st.matchId !== matchId || st.hp <= 0) continue;
      if (gx >= st.gridX && gx < st.gridX + st.width && gy >= st.gridY && gy < st.gridY + st.height) {
        if (st.channel === 'surface') result.surface = st;
        if (st.channel === 'superstructure') result.superstructure = st;
      }
    }
    return result;
  }

  recalculateTerritoryConnectivity(matchId, factionId) {
    const factionStructs = this.getMatchStructures(matchId).filter(
      (s) => s.factionId === factionId && s.hp > 0
    );
    const surfaceMap = new Map(); // `${gx}_${gy}` -> structure
    const anchors = [];

    for (const st of factionStructs) {
      if (st.channel === 'surface') {
        const def = STRUCTURE_DEFS[st.structureType];
        if (def && def.isAnchor) anchors.push(st);
        for (let dy = 0; dy < st.height; dy++) {
          for (let dx = 0; dx < st.width; dx++) {
            surfaceMap.set(`${st.gridX + dx}_${st.gridY + dy}`, st);
          }
        }
      }
    }

    const connectedCells = new Set();
    const queue = [];

    for (const anchor of anchors) {
      for (let dy = 0; dy < anchor.height; dy++) {
        for (let dx = 0; dx < anchor.width; dx++) {
          const key = `${anchor.gridX + dx}_${anchor.gridY + dy}`;
          connectedCells.add(key);
          queue.push([anchor.gridX + dx, anchor.gridY + dy]);
        }
      }
    }

    while (queue.length > 0) {
      const [cx, cy] = queue.shift();
      for (const [ox, oy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
        const nx = cx + ox;
        const ny = cy + oy;
        const nKey = `${nx}_${ny}`;
        if (!connectedCells.has(nKey) && surfaceMap.has(nKey)) {
          connectedCells.add(nKey);
          queue.push([nx, ny]);
        }
      }
    }

    // Update isConnected flag for all structures of this faction
    for (const st of factionStructs) {
      let connected = false;
      for (let dy = 0; dy < st.height; dy++) {
        for (let dx = 0; dx < st.width; dx++) {
          if (connectedCells.has(`${st.gridX + dx}_${st.gridY + dy}`)) {
            connected = true;
            break;
          }
        }
        if (connected) break;
      }
      if (st.isConnected !== connected) {
        st.isConnected = connected;
        if (!connected && st.channel === 'superstructure') {
          this.emitEvent(matchId, 'alert', st.gridX + st.width / 2, st.gridY + st.height / 2, factionId, {
            message: 'Territory disconnected! Superstructure offline.',
          });
        }
      }
    }
  }

  validateStructurePlacement(matchId, factionId, structureType, gridX, gridY, rotationDeg = 0) {
    const match = this.matches.get(matchId);
    if (!match || match.status !== 'active') {
      return { valid: false, reason: 'Match is not active' };
    }
    const def = STRUCTURE_DEFS[structureType];
    if (!def) return { valid: false, reason: 'Unknown structure type' };

    const slot = this.getSlot(matchId, factionId);
    if (!slot || slot.eliminated) return { valid: false, reason: 'Faction is eliminated' };
    if (slot.salvage < def.cost) return { valid: false, reason: 'Insufficient salvage' };

    if (gridX < 1 || gridY < 1 || gridX + def.width > match.mapCells - 1 || gridY + def.height > match.mapCells - 1) {
      return { valid: false, reason: 'Out of map bounds' };
    }

    // Check every footprint cell
    let hasAdjacentFriendlySurface = false;
    for (let dy = 0; dy < def.height; dy++) {
      for (let dx = 0; dx < def.width; dx++) {
        const cx = gridX + dx;
        const cy = gridY + dy;

        if (!this.isWaterCell(matchId, cx, cy)) {
          return { valid: false, reason: 'Blocked by impassable terrain' };
        }

        // Prevent building directly on top of a salvage deposit
        for (const node of this.getMatchNodes(matchId)) {
          if (node.gridX === cx && node.gridY === cy && node.remaining > 0) {
            return { valid: false, reason: 'Cannot build directly on a Salvage Deposit' };
          }
        }

        const occ = this.getStructuresAtCell(matchId, cx, cy);

        if (def.channel === 'surface') {
          if (occ.surface) {
            return { valid: false, reason: 'Surface cell already occupied' };
          }
          // Check orthogonal neighbors for friendly connected surface
          for (const [ox, oy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
            const neighborOcc = this.getStructuresAtCell(matchId, cx + ox, cy + oy);
            if (
              neighborOcc.surface &&
              neighborOcc.surface.factionId === factionId &&
              neighborOcc.surface.isComplete &&
              neighborOcc.surface.isConnected
            ) {
              hasAdjacentFriendlySurface = true;
            }
          }
        } else if (def.channel === 'superstructure') {
          if (occ.superstructure) {
            return { valid: false, reason: 'Superstructure cell already occupied' };
          }
          if (
            !occ.surface ||
            occ.surface.factionId !== factionId ||
            !occ.surface.isComplete ||
            !occ.surface.isConnected ||
            occ.surface.structureType === 'command_core'
          ) {
            return { valid: false, reason: 'Requires completed, connected friendly Floating Platform' };
          }
        }
      }
    }

    if (def.channel === 'surface' && !def.isAnchor && !hasAdjacentFriendlySurface) {
      return { valid: false, reason: 'Platform must connect orthogonally to your existing territory' };
    }

    // Shipyard requires at least one adjacent open water cell to launch ships
    if (def.requiresAdjacentWater) {
      let hasOpenWaterAdjacent = false;
      for (let dy = -1; dy <= def.height; dy++) {
        for (let dx = -1; dx <= def.width; dx++) {
          const isBorder = dx === -1 || dx === def.width || dy === -1 || dy === def.height;
          if (!isBorder) continue;
          const wx = gridX + dx;
          const wy = gridY + dy;
          if (this.isWaterCell(matchId, wx, wy)) {
            const occ = this.getStructuresAtCell(matchId, wx, wy);
            if (!occ.surface) {
              hasOpenWaterAdjacent = true;
              break;
            }
          }
        }
        if (hasOpenWaterAdjacent) break;
      }
      if (!hasOpenWaterAdjacent) {
        return { valid: false, reason: 'Shipyard requires at least one adjacent open water cell to launch vessels' };
      }
    }

    return { valid: true, reason: 'Valid placement' };
  }

  // --------------------------------------------------------------------------
  // AUTHORITATIVE REDUCERS
  // --------------------------------------------------------------------------

  createMatch(callerIdentity, {
    preset = 'Skirmish',
    maxSlots = 4,
    botCount = 3,
    botDifficulty = 'Commander',
    seed = 778899,
    playerName = 'Commander',
    fogOfWarEnabled = true,
    allowLateJoinTakeover = true,
    botOnly = false,
  } = {}) {
    const presetConfig = MATCH_PRESETS[preset] || MATCH_PRESETS.Skirmish;
    const totalSlots = Math.max(2, Math.min(8, maxSlots || presetConfig.maxSlots));
    const mapCells = presetConfig.mapCells || GAME_CONSTANTS.DEFAULT_MAP_CELLS;

    const matchId = this.nextId('match');
    const rng = createSeededRng(seed + this.idCounter * 17);
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    let joinCode = '';
    for (let i = 0; i < 6; i++) {
      joinCode += chars[Math.floor(rng() * chars.length)];
    }

    const match = {
      matchId,
      joinCode,
      preset,
      status: 'lobby',
      seed: seed >>> 0,
      mapCells,
      maxSlots: totalSlots,
      hostIdentity: callerIdentity,
      createdAtMs: this.nowMs,
      startedAtMs: 0,
      tickCount: 0,
      winnerFactionId: -1,
      victoryReason: '',
      allowLateJoinTakeover: Boolean(allowLateJoinTakeover),
      fogOfWarEnabled: Boolean(fogOfWarEnabled),
    };
    this.matches.set(matchId, match);

    let botsRemaining = Math.min(botOnly ? totalSlots : totalSlots - 1, Math.max(0, botCount));

    for (let i = 0; i < totalSlots; i++) {
      const palette = FACTION_PALETTES[i % FACTION_PALETTES.length];
      let slotType = 'empty';
      let occupantIdentity = '';
      let slotName = 'Open Slot';
      let ready = false;
      let connected = false;

      if (!botOnly && i === 0) {
        slotType = 'human';
        occupantIdentity = callerIdentity;
        slotName = playerName || 'Commander';
        ready = true;
        connected = true;
      } else if (botsRemaining > 0) {
        slotType = 'bot';
        occupantIdentity = `bot_${matchId}_${i}`;
        slotName = `AI ${palette.name.split(' ')[0]}`;
        ready = true;
        connected = true;
        botsRemaining--;
      }

      const slotKey = `${matchId}_${i}`;
      this.matchSlots.set(slotKey, {
        slotKey,
        matchId,
        slotIndex: i,
        slotType,
        occupantIdentity,
        playerName: slotName,
        botDifficulty,
        factionColor: palette.primary,
        ready,
        connected,
        eliminated: false,
        salvage: GAME_CONSTANTS.STARTING_SALVAGE,
        totalSalvageGathered: 0,
        shipsBuilt: 0,
        shipsLost: 0,
        structuresBuilt: 0,
        enemiesDestroyed: 0,
        weaponUpgradeLevel: 0,
      });
    }

    this.notifyChange(matchId);
    return { ok: true, matchId, joinCode };
  }

  quickPlay(callerIdentity, { playerName = 'Commander', preset = 'Skirmish', botDifficulty = 'Commander' } = {}) {
    // Look for an open lobby first
    for (const match of this.matches.values()) {
      if (match.status === 'lobby') {
        const res = this.joinMatchByCode(callerIdentity, { joinCode: match.joinCode, playerName });
        if (res.ok) return res;
      }
    }
    // Otherwise create a fresh match and immediately start it
    const presetCfg = MATCH_PRESETS[preset] || MATCH_PRESETS.Skirmish;
    const created = this.createMatch(callerIdentity, {
      preset,
      maxSlots: presetCfg.maxSlots,
      botCount: presetCfg.defaultBots,
      botDifficulty,
      playerName,
      seed: Math.floor(100000 + (this.nowMs % 899999)),
    });
    this.startMatch(callerIdentity, { matchId: created.matchId });
    return { ...created, slotIndex: 0 };
  }

  joinMatchByCode(callerIdentity, { joinCode, playerName = 'Challenger' } = {}) {
    if (!joinCode) throw new Error('Join code is required');
    const normalized = String(joinCode).trim().toUpperCase();
    let targetMatch = null;
    for (const m of this.matches.values()) {
      if (m.joinCode === normalized) {
        targetMatch = m;
        break;
      }
    }
    if (!targetMatch) {
      throw new Error('Lobby join code not found or expired');
    }
    if (targetMatch.status === 'finished') {
      throw new Error('Cannot join a finished match');
    }

    // Check if caller already owns a slot in this match (Reconnect)
    const existing = this.getSlotByIdentity(targetMatch.matchId, callerIdentity);
    if (existing) {
      existing.connected = true;
      this.notifyChange(targetMatch.matchId);
      return {
        ok: true,
        matchId: targetMatch.matchId,
        slotIndex: existing.slotIndex,
        reconnected: true,
        spectator: false,
      };
    }

    const slots = this.getMatchSlots(targetMatch.matchId);

    if (targetMatch.status === 'lobby') {
      const emptySlot = slots.find((s) => s.slotType === 'empty');
      if (!emptySlot) {
        throw new Error('Match lobby is at full capacity');
      }
      emptySlot.slotType = 'human';
      emptySlot.occupantIdentity = callerIdentity;
      emptySlot.playerName = playerName;
      emptySlot.ready = true;
      emptySlot.connected = true;
      this.notifyChange(targetMatch.matchId);
      return {
        ok: true,
        matchId: targetMatch.matchId,
        slotIndex: emptySlot.slotIndex,
        reconnected: false,
        spectator: false,
      };
    }

    // Late Join policy during active match:
    if (targetMatch.status === 'active') {
      if (targetMatch.allowLateJoinTakeover) {
        const activeBotSlot = slots.find((s) => s.slotType === 'bot' && !s.eliminated);
        if (activeBotSlot) {
          activeBotSlot.slotType = 'human';
          activeBotSlot.occupantIdentity = callerIdentity;
          activeBotSlot.playerName = `${playerName} (Takeover)`;
          activeBotSlot.connected = true;
          this.botBrains.delete(`${targetMatch.matchId}_${activeBotSlot.slotIndex}`);
          this.notifyChange(targetMatch.matchId);
          return {
            ok: true,
            matchId: targetMatch.matchId,
            slotIndex: activeBotSlot.slotIndex,
            reconnected: false,
            spectator: false,
            tookOverBot: true,
          };
        }
      }
      return {
        ok: true,
        matchId: targetMatch.matchId,
        slotIndex: -1,
        reconnected: false,
        spectator: true,
      };
    }

    throw new Error('Match unavailable');
  }

  claimSlot(callerIdentity, { matchId, slotIndex, playerName = 'Commander' }) {
    const match = this.matches.get(matchId);
    if (!match || match.status !== 'lobby') {
      throw new Error('Can only claim slots while in lobby');
    }
    const targetSlot = this.getSlot(matchId, slotIndex);
    if (!targetSlot) throw new Error('Invalid slot index');
    if (targetSlot.slotType !== 'empty' && targetSlot.occupantIdentity !== callerIdentity) {
      throw new Error('Slot is already occupied');
    }
    // Release old slot if caller had one
    const prevSlot = this.getSlotByIdentity(matchId, callerIdentity);
    if (prevSlot && prevSlot.slotIndex !== slotIndex) {
      prevSlot.slotType = 'empty';
      prevSlot.occupantIdentity = '';
      prevSlot.playerName = 'Open Slot';
      prevSlot.ready = false;
      prevSlot.connected = false;
    }
    targetSlot.slotType = 'human';
    targetSlot.occupantIdentity = callerIdentity;
    targetSlot.playerName = playerName;
    targetSlot.ready = true;
    targetSlot.connected = true;
    this.notifyChange(matchId);
    return { ok: true, slotIndex };
  }

  configureLobbySlot(callerIdentity, { matchId, slotIndex, slotType, botDifficulty = 'Commander' }) {
    const match = this.matches.get(matchId);
    if (!match || match.status !== 'lobby') throw new Error('Match not in lobby');
    if (match.hostIdentity !== callerIdentity) throw new Error('Only host can configure slots');

    const slot = this.getSlot(matchId, slotIndex);
    if (!slot) throw new Error('Invalid slot');
    if (slot.occupantIdentity === callerIdentity && slotType !== 'human') {
      throw new Error('Host cannot remove their own human slot');
    }

    const palette = FACTION_PALETTES[slotIndex % FACTION_PALETTES.length];
    if (slotType === 'bot') {
      slot.slotType = 'bot';
      slot.occupantIdentity = `bot_${matchId}_${slotIndex}`;
      slot.playerName = `AI ${palette.name.split(' ')[0]}`;
      slot.botDifficulty = botDifficulty;
      slot.ready = true;
      slot.connected = true;
    } else if (slotType === 'empty') {
      slot.slotType = 'empty';
      slot.occupantIdentity = '';
      slot.playerName = 'Open Slot';
      slot.ready = false;
      slot.connected = false;
    }
    this.notifyChange(matchId);
    return { ok: true };
  }

  setPlayerReady(callerIdentity, { matchId, ready }) {
    const slot = this.getSlotByIdentity(matchId, callerIdentity);
    if (!slot) throw new Error('Caller is not in a slot');
    slot.ready = Boolean(ready);
    this.notifyChange(matchId);
    return { ok: true };
  }

  disconnectPlayer(callerIdentity, { matchId }) {
    const slot = this.getSlotByIdentity(matchId, callerIdentity);
    if (slot) {
      slot.connected = false;
      this.notifyChange(matchId);
    }
    return { ok: true };
  }

  reconnectPlayer(callerIdentity, { matchId }) {
    const slot = this.getSlotByIdentity(matchId, callerIdentity);
    if (!slot) throw new Error('No existing faction ownership found for identity');
    slot.connected = true;
    this.notifyChange(matchId);
    return { ok: true, slotIndex: slot.slotIndex };
  }

  startMatch(callerIdentity, { matchId }) {
    const match = this.matches.get(matchId);
    if (!match) throw new Error('Match not found');
    if (match.status !== 'lobby') throw new Error('Match already started');
    if (match.hostIdentity !== callerIdentity) throw new Error('Only the host can start the match');

    const activeSlots = this.getMatchSlots(matchId).filter((s) => s.slotType !== 'empty');
    if (activeSlots.length < 2) {
      throw new Error('At least 2 active players/bots are required to start a match');
    }

    // Generate deterministic world
    const world = generateDeterministicWorld({
      seed: match.seed,
      mapCells: match.mapCells,
      slotCount: match.maxSlots,
    });

    this.terrainCache.set(matchId, world.cells);

    for (const ch of world.chunks) {
      const chunkKey = `${matchId}_${ch.chunkX}_${ch.chunkY}`;
      this.worldChunks.set(chunkKey, {
        chunkKey,
        matchId,
        chunkX: ch.chunkX,
        chunkY: ch.chunkY,
        terrainJson: JSON.stringify(ch.terrainData),
      });
    }

    for (const nd of world.resourceNodes) {
      const nodeKey = `${matchId}_${nd.id}`;
      this.resourceNodes.set(nodeKey, {
        nodeKey,
        matchId,
        gridX: nd.gridX,
        gridY: nd.gridY,
        capacity: nd.capacity,
        remaining: nd.remaining,
        regenPerSec: nd.regenPerSec,
        isContested: nd.isContested,
      });
    }

    // Spawn Command Core, initial surrounding platforms, and 1 starting Scout for each active faction
    for (const slot of this.getMatchSlots(matchId)) {
      if (slot.slotType === 'empty') {
        slot.eliminated = true;
        continue;
      }
      const sp = world.spawns[slot.slotIndex] || world.spawns[0];
      const coreDef = STRUCTURE_DEFS.command_core;
      const coreId = this.nextId('struct');

      // Clear any accidental terrain under Command Core and immediate ring
      for (let dy = -2; dy <= coreDef.height + 1; dy++) {
        for (let dx = -2; dx <= coreDef.width + 1; dx++) {
          const tx = sp.gridX + dx;
          const ty = sp.gridY + dy;
          if (tx >= 0 && ty >= 0 && tx < match.mapCells && ty < match.mapCells) {
            world.cells[ty * match.mapCells + tx] = TERRAIN_TYPES.DEEP_WATER;
          }
        }
      }

      this.structures.set(coreId, {
        structureId: coreId,
        matchId,
        factionId: slot.slotIndex,
        structureType: 'command_core',
        channel: 'surface',
        gridX: sp.gridX,
        gridY: sp.gridY,
        width: coreDef.width,
        height: coreDef.height,
        rotationDeg: 0,
        hp: coreDef.maxHp,
        maxHp: coreDef.maxHp,
        isComplete: true,
        builtAtMs: this.nowMs,
        completesAtMs: this.nowMs,
        isConnected: true,
        turretAngleDeg: 0,
        lastFiredAtMs: 0,
        targetEntityId: '',
        productionQueueJson: '[]',
      });

      // Spawn a 2x2 connected platform pad adjacent to the Command Core so players can immediately build a Shipyard or Workshop
      const padOffsets = [
        [0, 3],
        [1, 3],
        [0, 4],
        [1, 4],
        [2, 3],
        [2, 4],
      ];
      for (const [ox, oy] of padOffsets) {
        const px = sp.gridX + ox;
        const py = sp.gridY + oy;
        if (px >= 1 && py >= 1 && px < match.mapCells - 1 && py < match.mapCells - 1) {
          const pid = this.nextId('struct');
          this.structures.set(pid, {
            structureId: pid,
            matchId,
            factionId: slot.slotIndex,
            structureType: 'platform',
            channel: 'surface',
            gridX: px,
            gridY: py,
            width: 1,
            height: 1,
            rotationDeg: 0,
            hp: STRUCTURE_DEFS.platform.maxHp,
            maxHp: STRUCTURE_DEFS.platform.maxHp,
            isComplete: true,
            builtAtMs: this.nowMs,
            completesAtMs: this.nowMs,
            isConnected: true,
            turretAngleDeg: 0,
            lastFiredAtMs: 0,
            targetEntityId: '',
            productionQueueJson: '[]',
          });
        }
      }

      // Spawn 1 starting Scout Hydrofoil & 1 Ironclad Gunboat per active faction
      this.spawnShipInternal(matchId, slot.slotIndex, 'scout', sp.gridX - 1.5, sp.gridY + 1.5);
      this.spawnShipInternal(matchId, slot.slotIndex, 'gunboat', sp.gridX + 4.5, sp.gridY + 1.5);

      // Initialize BotBrain if slot is bot
      if (slot.slotType === 'bot') {
        const botKey = `${matchId}_${slot.slotIndex}`;
        this.botBrains.set(botKey, {
          botKey,
          matchId,
          slotIndex: slot.slotIndex,
          difficulty: slot.botDifficulty || 'Commander',
          currentGoal: 'expand',
          lastDecisionAtMs: this.nowMs,
          targetEnemySlot: -1,
        });
      }
    }

    match.status = 'active';
    match.startedAtMs = this.nowMs;
    this.notifyChange(matchId);
    return { ok: true };
  }

  spawnShipInternal(matchId, factionId, shipType, x, y) {
    const def = SHIP_DEFS[shipType];
    if (!def) throw new Error(`Unknown ship type: ${shipType}`);
    const shipId = this.nextId('ship');
    const ship = {
      shipId,
      matchId,
      factionId,
      shipType,
      x,
      y,
      vx: 0,
      vy: 0,
      hullAngleDeg: 0,
      turretAngleDeg: 0,
      hp: def.maxHp,
      maxHp: def.maxHp,
      orderType: 'idle',
      targetX: x,
      targetY: y,
      targetEntityId: '',
      lastFiredAtMs: 0,
      fleetGroup: -1,
    };
    this.ships.set(shipId, ship);
    return ship;
  }

  // --------------------------------------------------------------------------
  // CONSTRUCTION, DEMOLITION & REPAIR REDUCERS
  // --------------------------------------------------------------------------

  placeStructure(callerIdentity, { matchId, structureType, gridX, gridY, rotationDeg = 0 }) {
    const slot = this.getSlotByIdentity(matchId, callerIdentity);
    if (!slot) throw new Error('Caller does not control a faction in this match');
    if (slot.eliminated) throw new Error('Eliminated players cannot construct');
    if (structureType === 'command_core') throw new Error('Cannot manually construct Command Core');

    const check = this.validateStructurePlacement(matchId, slot.slotIndex, structureType, gridX, gridY, rotationDeg);
    if (!check.valid) {
      throw new Error(check.reason);
    }

    const def = STRUCTURE_DEFS[structureType];
    slot.salvage -= def.cost;
    slot.structuresBuilt += 1;

    const structureId = this.nextId('struct');
    const st = {
      structureId,
      matchId,
      factionId: slot.slotIndex,
      structureType,
      channel: def.channel,
      gridX,
      gridY,
      width: def.width,
      height: def.height,
      rotationDeg: rotationDeg % 360,
      hp: Math.max(40, def.maxHp * 0.25),
      maxHp: def.maxHp,
      isComplete: false,
      builtAtMs: this.nowMs,
      completesAtMs: this.nowMs + def.buildTimeMs,
      isConnected: true,
      turretAngleDeg: rotationDeg % 360,
      lastFiredAtMs: 0,
      targetEntityId: '',
      productionQueueJson: '[]',
    };
    this.structures.set(structureId, st);
    this.recalculateTerritoryConnectivity(matchId, slot.slotIndex);
    this.emitEvent(matchId, 'built', gridX + def.width / 2, gridY + def.height / 2, slot.slotIndex, {
      structureType,
    });
    this.notifyChange(matchId);
    return { ok: true, structureId };
  }

  demolishStructure(callerIdentity, { matchId, structureId }) {
    const slot = this.getSlotByIdentity(matchId, callerIdentity);
    if (!slot || slot.eliminated) throw new Error('Unauthorized');

    const st = this.structures.get(structureId);
    if (!st || st.matchId !== matchId) throw new Error('Structure not found');
    if (st.factionId !== slot.slotIndex) throw new Error('Cannot demolish enemy structure');
    if (st.structureType === 'command_core') throw new Error('Cannot demolish Command Core');

    const def = STRUCTURE_DEFS[st.structureType];
    const refund = Math.floor((def ? def.cost : 20) * (st.isComplete ? 0.5 : 0.75));
    slot.salvage += refund;

    this.destroyStructureInternal(st);
    this.notifyChange(matchId);
    return { ok: true, refund };
  }

  repairStructure(callerIdentity, { matchId, structureId }) {
    const slot = this.getSlotByIdentity(matchId, callerIdentity);
    if (!slot || slot.eliminated) throw new Error('Unauthorized');
    const st = this.structures.get(structureId);
    if (!st || st.matchId !== matchId || st.factionId !== slot.slotIndex) {
      throw new Error('Invalid structure for repair');
    }
    if (st.hp >= st.maxHp) return { ok: true, repaired: 0 };
    const repairCost = 30;
    if (slot.salvage < repairCost) throw new Error('Insufficient salvage to repair');
    slot.salvage -= repairCost;
    const oldHp = st.hp;
    st.hp = Math.min(st.maxHp, st.hp + 220);
    this.notifyChange(matchId);
    return { ok: true, repaired: st.hp - oldHp };
  }

  upgradeWeapons(callerIdentity, { matchId }) {
    const slot = this.getSlotByIdentity(matchId, callerIdentity);
    if (!slot || slot.eliminated) throw new Error('Unauthorized');
    if (slot.weaponUpgradeLevel >= 3) throw new Error('Maximum weapon upgrade level reached');

    // Require an active connected Workshop
    const hasWorkshop = this.getMatchStructures(matchId).some(
      (s) =>
        s.factionId === slot.slotIndex &&
        s.structureType === 'workshop' &&
        s.isComplete &&
        s.isConnected &&
        s.hp > 0
    );
    if (!hasWorkshop) throw new Error('Requires an operational Industrial Workshop');

    const cost = GAME_CONSTANTS.WORKSHOP_UPGRADE_COST * (slot.weaponUpgradeLevel + 1);
    if (slot.salvage < cost) throw new Error('Insufficient salvage for fleet upgrade');

    slot.salvage -= cost;
    slot.weaponUpgradeLevel += 1;
    this.notifyChange(matchId);
    return { ok: true, level: slot.weaponUpgradeLevel };
  }

  destroyStructureInternal(st) {
    const { matchId, factionId } = st;
    this.structures.delete(st.structureId);
    this.emitEvent(matchId, 'explosion', st.gridX + st.width / 2, st.gridY + st.height / 2, factionId, {
      structureType: st.structureType,
    });

    // If a supporting surface platform is destroyed, check superstructures above its cells
    if (st.channel === 'surface') {
      const remainingStructures = this.getMatchStructures(matchId).filter(
        (other) => other.channel === 'superstructure' && other.factionId === factionId
      );
      for (const sup of remainingStructures) {
        let stillSupported = true;
        for (let dy = 0; dy < sup.height; dy++) {
          for (let dx = 0; dx < sup.width; dx++) {
            const occ = this.getStructuresAtCell(matchId, sup.gridX + dx, sup.gridY + dy);
            if (!occ.surface || occ.surface.factionId !== factionId) {
              stillSupported = false;
              break;
            }
          }
          if (!stillSupported) break;
        }
        if (!stillSupported) {
          this.structures.delete(sup.structureId);
          this.emitEvent(matchId, 'explosion', sup.gridX + sup.width / 2, sup.gridY + sup.height / 2, factionId, {
            collapsed: true,
            structureType: sup.structureType,
          });
        }
      }
    }

    if (st.structureType === 'command_core') {
      this.eliminateFactionInternal(matchId, factionId);
    } else {
      this.recalculateTerritoryConnectivity(matchId, factionId);
    }
  }

  eliminateFactionInternal(matchId, factionId) {
    const slot = this.getSlot(matchId, factionId);
    if (!slot || slot.eliminated) return;
    slot.eliminated = true;

    // Scuttle remaining ships & structures of defeated faction
    for (const sh of this.getMatchShips(matchId)) {
      if (sh.factionId === factionId) {
        this.ships.delete(sh.shipId);
        this.emitEvent(matchId, 'explosion', sh.x, sh.y, factionId, { shipType: sh.shipType });
      }
    }
    for (const st of this.getMatchStructures(matchId)) {
      if (st.factionId === factionId) {
        this.structures.delete(st.structureId);
      }
    }
    this.botBrains.delete(`${matchId}_${factionId}`);
    this.checkVictoryCondition(matchId);
  }

  surrenderMatch(callerIdentity, { matchId }) {
    const slot = this.getSlotByIdentity(matchId, callerIdentity);
    if (!slot || slot.eliminated) throw new Error('Caller cannot surrender');
    this.eliminateFactionInternal(matchId, slot.slotIndex);
    this.notifyChange(matchId);
    return { ok: true };
  }

  checkVictoryCondition(matchId) {
    const match = this.matches.get(matchId);
    if (!match || match.status !== 'active') return;

    const surviving = this.getMatchSlots(matchId).filter((s) => s.slotType !== 'empty' && !s.eliminated);
    if (surviving.length === 1) {
      match.status = 'finished';
      match.winnerFactionId = surviving[0].slotIndex;
      match.victoryReason = `${surviving[0].playerName} destroyed all rival Command Cores!`;
    } else if (surviving.length === 0) {
      match.status = 'finished';
      match.winnerFactionId = 0;
      match.victoryReason = 'Mutual destruction!';
    }
  }

  // --------------------------------------------------------------------------
  // SHIP PRODUCTION & ORDERS REDUCERS
  // --------------------------------------------------------------------------

  queueShipProduction(callerIdentity, { matchId, structureId, shipType }) {
    const slot = this.getSlotByIdentity(matchId, callerIdentity);
    if (!slot || slot.eliminated) throw new Error('Unauthorized');

    const shipyard = this.structures.get(structureId);
    if (!shipyard || shipyard.matchId !== matchId || shipyard.structureType !== 'shipyard') {
      throw new Error('Invalid Shipyard');
    }
    if (shipyard.factionId !== slot.slotIndex) {
      throw new Error('Cannot produce from enemy Shipyard');
    }
    if (!shipyard.isComplete || !shipyard.isConnected) {
      throw new Error('Shipyard must be completed and connected to Command Core');
    }

    const shipDef = SHIP_DEFS[shipType];
    if (!shipDef) throw new Error('Invalid ship type');
    if (slot.salvage < shipDef.cost) throw new Error('Insufficient salvage');

    const queue = JSON.parse(shipyard.productionQueueJson || '[]');
    if (queue.length >= STRUCTURE_DEFS.shipyard.maxQueueSize) {
      throw new Error('Shipyard production queue is full');
    }

    slot.salvage -= shipDef.cost;
    const prevEnd = queue.length > 0 ? queue[queue.length - 1].completesAtMs : this.nowMs;
    queue.push({
      shipType,
      startedAtMs: prevEnd,
      completesAtMs: prevEnd + shipDef.buildTimeMs,
    });
    shipyard.productionQueueJson = JSON.stringify(queue);
    this.notifyChange(matchId);
    return { ok: true, queueLength: queue.length };
  }

  issueShipOrder(callerIdentity, {
    matchId,
    shipIds = [],
    orderType = 'move',
    targetX = 0,
    targetY = 0,
    targetEntityId = '',
  }) {
    const slot = this.getSlotByIdentity(matchId, callerIdentity);
    if (!slot) throw new Error('Unauthorized');
    if (slot.eliminated) throw new Error('Eliminated faction cannot issue orders');

    const match = this.matches.get(matchId);
    if (!match || match.status !== 'active') throw new Error('Match is not active');

    const validShips = [];
    for (const id of shipIds) {
      const sh = this.ships.get(id);
      if (!sh || sh.matchId !== matchId) continue;
      if (sh.factionId !== slot.slotIndex) {
        throw new Error('Cannot command enemy ships');
      }
      validShips.push(sh);
    }

    if (validShips.length === 0) {
      throw new Error('No valid owned ships selected');
    }

    // Compute cohesive fleet formation offsets so grouped ships do not stack on the exact same point
    const cols = Math.ceil(Math.sqrt(validShips.length));
    const spacing = 1.45;

    validShips.forEach((sh, idx) => {
      const row = Math.floor(idx / cols);
      const col = idx % cols;
      const offsetX = validShips.length > 1 ? (col - (cols - 1) / 2) * spacing : 0;
      const offsetY = validShips.length > 1 ? (row - (cols - 1) / 2) * spacing : 0;

      const destX = Math.max(1.5, Math.min(match.mapCells - 1.5, targetX + offsetX));
      const destY = Math.max(1.5, Math.min(match.mapCells - 1.5, targetY + offsetY));

      sh.orderType = orderType;
      sh.targetX = destX;
      sh.targetY = destY;
      sh.targetEntityId = targetEntityId || '';
      if (orderType === 'stop') {
        sh.vx = 0;
        sh.vy = 0;
        sh.targetX = sh.x;
        sh.targetY = sh.y;
      }
    });

    this.notifyChange(matchId);
    return { ok: true, orderedCount: validShips.length };
  }

  fireWeaponCommand(callerIdentity, { matchId, attackerId, targetEntityId }) {
    const slot = this.getSlotByIdentity(matchId, callerIdentity);
    if (!slot || slot.eliminated) throw new Error('Unauthorized');

    const ship = this.ships.get(attackerId);
    const turret = this.structures.get(attackerId);
    const attacker = ship || turret;
    if (!attacker || attacker.matchId !== matchId) throw new Error('Attacker not found');
    if (attacker.factionId !== slot.slotIndex) throw new Error('Cannot fire enemy weapon');

    const cooldownMs = ship
      ? SHIP_DEFS[ship.shipType].cooldownMs
      : STRUCTURE_DEFS[turret.structureType].cooldownMs || 1400;

    if (attacker.lastFiredAtMs > 0 && this.nowMs - attacker.lastFiredAtMs < cooldownMs) {
      throw new Error('Weapon is on cooldown');
    }

    const targetShip = this.ships.get(targetEntityId);
    const targetStruct = this.structures.get(targetEntityId);
    const target = targetShip || targetStruct;
    if (!target || target.matchId !== matchId || target.factionId === slot.slotIndex) {
      throw new Error('Invalid target');
    }

    const ax = ship ? ship.x : turret.gridX + turret.width / 2;
    const ay = ship ? ship.y : turret.gridY + turret.height / 2;
    const tx = targetShip ? targetShip.x : targetStruct.gridX + targetStruct.width / 2;
    const targetPosY = targetShip ? targetShip.y : targetStruct.gridY + targetStruct.height / 2;

    const maxRange = ship
      ? SHIP_DEFS[ship.shipType].attackRangeCells
      : STRUCTURE_DEFS[turret.structureType].attackRangeCells;

    const dist = Math.hypot(tx - ax, targetPosY - ay);
    if (dist > maxRange + 0.8) {
      throw new Error('Target is out of weapon range');
    }

    this.spawnProjectileInternal(matchId, slot.slotIndex, attacker, ship ? 'ship' : 'structure', target, tx, targetPosY);
    this.notifyChange(matchId);
    return { ok: true };
  }

  spawnProjectileInternal(matchId, factionId, attacker, sourceType, target, tx, ty) {
    const slot = this.getSlot(matchId, factionId);
    const upgradeMult = 1 + (slot ? slot.weaponUpgradeLevel * 0.12 : 0);

    let damage = 35;
    let speed = 15;
    let structMult = 1.0;
    let splash = 0.4;
    let ax = 0;
    let ay = 0;
    let sourceId = '';

    if (sourceType === 'ship') {
      const def = SHIP_DEFS[attacker.shipType];
      damage = def.damage * upgradeMult;
      speed = def.projectileSpeedCellsPerSec;
      structMult = def.structureDamageMultiplier;
      splash = def.SplashRadiusCells || 0.4;
      ax = attacker.x;
      ay = attacker.y;
      sourceId = attacker.shipId;
    } else {
      const def = STRUCTURE_DEFS[attacker.structureType];
      damage = def.damage * upgradeMult;
      speed = def.projectileSpeedCellsPerSec;
      structMult = 1.0;
      splash = 0.5;
      ax = attacker.gridX + attacker.width / 2;
      ay = attacker.gridY + attacker.height / 2;
      sourceId = attacker.structureId;
    }

    const dist = Math.max(0.4, Math.hypot(tx - ax, ty - ay));
    const travelMs = Math.max(100, Math.round((dist / speed) * 1000));
    const angleDeg = normalizeAngleDeg((Math.atan2(ty - ay, tx - ax) * 180) / Math.PI);

    attacker.turretAngleDeg = angleDeg;
    attacker.lastFiredAtMs = this.nowMs;

    const projectileId = this.nextId('proj');
    const targetId = target.shipId || target.structureId || '';

    this.projectiles.set(projectileId, {
      projectileId,
      matchId,
      factionId,
      sourceId,
      sourceType,
      startX: ax,
      startY: ay,
      targetX: tx,
      targetY: ty,
      targetEntityId: targetId,
      speedCellsPerSec: speed,
      damage,
      structureMultiplier: structMult,
      splashRadiusCells: splash,
      spawnedAtMs: this.nowMs,
      impactAtMs: this.nowMs + travelMs,
    });

    this.emitEvent(matchId, 'muzzle', ax, ay, factionId, { angleDeg, sourceType });
  }

  // --------------------------------------------------------------------------
  // AUTHORITATIVE SIMULATION STEP (Scheduled Reducer / Tick)
  // --------------------------------------------------------------------------

  stepSimulation(deltaMs = GAME_CONSTANTS.SIMULATION_TICK_MS) {
    this.nowMs += deltaMs;
    const dtSec = deltaMs / 1000;

    for (const match of this.matches.values()) {
      if (match.status !== 'active') continue;
      match.tickCount += 1;

      this.stepMatchEconomyAndStructures(match, dtSec);
      this.stepMatchShips(match, dtSec);
      this.stepMatchProjectiles(match);
      this.stepMatchBots(match);
      this.stepSuddenDeathCheck(match);
      this.notifyChange(match.matchId);
    }
  }

  stepMatchEconomyAndStructures(match, dtSec) {
    const matchId = match.matchId;
    const slots = this.getMatchSlots(matchId);
    const structures = this.getMatchStructures(matchId);
    const nodes = this.getMatchNodes(matchId);
    const ships = this.getMatchShips(matchId);

    // 1. Regenerate salvage nodes slowly if below capacity
    for (const nd of nodes) {
      if (nd.remaining > 0 && nd.remaining < nd.capacity) {
        nd.remaining = Math.min(nd.capacity, nd.remaining + nd.regenPerSec * dtSec);
      }
    }

    // 2. Passive Command Core income
    for (const slot of slots) {
      if (slot.slotType !== 'empty' && !slot.eliminated) {
        const gain = GAME_CONSTANTS.PASSIVE_CORE_SALVAGE_PER_SEC * dtSec;
        slot.salvage += gain;
        slot.totalSalvageGathered += gain;
      }
    }

    // 3. Process structure completion, production queues, repairs, and defensive cannons
    for (const st of structures) {
      if (st.hp <= 0) continue;
      const slot = this.getSlot(matchId, st.factionId);
      if (!slot || slot.eliminated) continue;

      if (!st.isComplete) {
        const def = STRUCTURE_DEFS[st.structureType];
        const progressRatio = Math.min(
          1,
          (this.nowMs - st.builtAtMs) / Math.max(1, st.completesAtMs - st.builtAtMs)
        );
        st.hp = Math.min(st.maxHp, Math.max(st.hp, st.maxHp * (0.25 + 0.75 * progressRatio)));
        if (this.nowMs >= st.completesAtMs) {
          st.isComplete = true;
          st.hp = st.maxHp;
          if (st.channel === 'surface') {
            this.recalculateTerritoryConnectivity(matchId, st.factionId);
          }
        }
        continue;
      }

      if (!st.isConnected) continue;

      // Salvage Extractor income
      if (st.structureType === 'salvage_rig') {
        const rigDef = STRUCTURE_DEFS.salvage_rig;
        let rigGain = rigDef.passiveIncomePerSec * dtSec;
        const cx = st.gridX + st.width / 2;
        const cy = st.gridY + st.height / 2;
        for (const nd of nodes) {
          if (nd.remaining > 0 && Math.hypot(nd.gridX - cx, nd.gridY - cy) <= rigDef.extractionRangeCells) {
            const extracted = Math.min(nd.remaining, rigDef.nodeBonusPerSec * dtSec);
            nd.remaining -= extracted;
            rigGain += extracted;
            break;
          }
        }
        slot.salvage += rigGain;
        slot.totalSalvageGathered += rigGain;
      }

      // Workshop passive aura repair
      if (st.structureType === 'workshop') {
        const wkDef = STRUCTURE_DEFS.workshop;
        const cx = st.gridX + st.width / 2;
        const cy = st.gridY + st.height / 2;
        for (const allySt of structures) {
          if (allySt.factionId === st.factionId && allySt.isComplete && allySt.hp < allySt.maxHp) {
            const dist = Math.hypot(allySt.gridX - cx, allySt.gridY - cy);
            if (dist <= wkDef.repairRadiusCells) {
              allySt.hp = Math.min(allySt.maxHp, allySt.hp + wkDef.repairPerSec * dtSec);
            }
          }
        }
        for (const allyShip of ships) {
          if (allyShip.factionId === st.factionId && allyShip.hp < allyShip.maxHp) {
            const dist = Math.hypot(allyShip.x - cx, allyShip.y - cy);
            if (dist <= wkDef.repairRadiusCells) {
              allyShip.hp = Math.min(allyShip.maxHp, allyShip.hp + wkDef.repairPerSec * dtSec);
            }
          }
        }
      }

      // Shipyard production queue
      if (st.structureType === 'shipyard') {
        const queue = JSON.parse(st.productionQueueJson || '[]');
        if (queue.length > 0 && this.nowMs >= queue[0].completesAtMs) {
          const finished = queue.shift();
          st.productionQueueJson = JSON.stringify(queue);
          const spawnPos = this.findShipSpawnCellNearShipyard(matchId, st);
          const newShip = this.spawnShipInternal(matchId, st.factionId, finished.shipType, spawnPos.x, spawnPos.y);
          slot.shipsBuilt += 1;
          this.emitEvent(matchId, 'built', newShip.x, newShip.y, st.factionId, {
            shipType: finished.shipType,
          });
        }
      }

      // Defensive Cannon auto-engagement
      if (st.structureType === 'cannon') {
        const canDef = STRUCTURE_DEFS.cannon;
        const cx = st.gridX + 0.5;
        const cy = st.gridY + 0.5;
        let bestTarget = null;
        let bestDist = canDef.attackRangeCells;

        for (const enemyShip of ships) {
          if (enemyShip.factionId === st.factionId || enemyShip.hp <= 0) continue;
          const d = Math.hypot(enemyShip.x - cx, enemyShip.y - cy);
          if (d <= bestDist) {
            bestDist = d;
            bestTarget = enemyShip;
          }
        }

        if (bestTarget) {
          const desiredAngle = normalizeAngleDeg((Math.atan2(bestTarget.y - cy, bestTarget.x - cx) * 180) / Math.PI);
          st.turretAngleDeg = rotateAngleTowards(
            st.turretAngleDeg,
            desiredAngle,
            canDef.turretTurnSpeedDegPerSec * dtSec
          );
          const aimDiff = Math.abs(shortestAngleDiffDeg(st.turretAngleDeg, desiredAngle));
          if (aimDiff <= 18 && this.nowMs - st.lastFiredAtMs >= canDef.cooldownMs) {
            this.spawnProjectileInternal(matchId, st.factionId, st, 'structure', bestTarget, bestTarget.x, bestTarget.y);
          }
        }
      }
    }
  }

  findShipSpawnCellNearShipyard(matchId, shipyard) {
    for (let radius = 1; radius <= 4; radius++) {
      for (let dy = -radius; dy <= shipyard.height + radius - 1; dy++) {
        for (let dx = -radius; dx <= shipyard.width + radius - 1; dx++) {
          const gx = shipyard.gridX + dx;
          const gy = shipyard.gridY + dy;
          if (!this.isWaterCell(matchId, gx, gy)) continue;
          const occ = this.getStructuresAtCell(matchId, gx, gy);
          if (!occ.surface && !occ.superstructure) {
            return { x: gx + 0.5, y: gy + 0.5 };
          }
        }
      }
    }
    return { x: shipyard.gridX - 0.5, y: shipyard.gridY + 0.5 };
  }

  stepMatchShips(match, dtSec) {
    const matchId = match.matchId;
    const ships = this.getMatchShips(matchId);
    const structures = this.getMatchStructures(matchId);
    const nodes = this.getMatchNodes(matchId);

    for (const sh of ships) {
      if (sh.hp <= 0) continue;
      const def = SHIP_DEFS[sh.shipType];
      const slot = this.getSlot(matchId, sh.factionId);
      if (!slot || slot.eliminated) continue;

      // 1. Salvage Harvesting if Scout/Gunboat is near a salvage deposit
      if (def.harvestRatePerSec > 0) {
        for (const nd of nodes) {
          if (nd.remaining <= 0) continue;
          const d = Math.hypot(nd.gridX + 0.5 - sh.x, nd.gridY + 0.5 - sh.y);
          if (d <= GAME_CONSTANTS.HARVEST_RANGE_CELLS) {
            const amount = Math.min(nd.remaining, def.harvestRatePerSec * dtSec);
            nd.remaining -= amount;
            slot.salvage += amount;
            slot.totalSalvageGathered += amount;
            break;
          }
        }
      }

      // 2. Resolve explicit target entity if attacking
      if (sh.orderType === 'attack_target' && sh.targetEntityId) {
        const tShip = this.ships.get(sh.targetEntityId);
        const tStruct = this.structures.get(sh.targetEntityId);
        const tObj = tShip || tStruct;
        if (!tObj || tObj.hp <= 0) {
          sh.targetEntityId = '';
          sh.orderType = 'idle';
        } else {
          const tx = tShip ? tShip.x : tStruct.gridX + tStruct.width / 2;
          const ty = tShip ? tShip.y : tStruct.gridY + tStruct.height / 2;
          const distToTarget = Math.hypot(tx - sh.x, ty - sh.y);
          if (distToTarget > def.attackRangeCells * 0.88) {
            sh.targetX = tx;
            sh.targetY = ty;
          } else {
            sh.targetX = sh.x;
            sh.targetY = sh.y;
          }
        }
      }

      // 3. Movement & Naval Steering with separation and obstacle avoidance
      const dx = sh.targetX - sh.x;
      const dy = sh.targetY - sh.y;
      const distToGoal = Math.hypot(dx, dy);

      if ((sh.orderType === 'move' || sh.orderType === 'attack_move' || sh.orderType === 'harvest' || sh.orderType === 'attack_target') && distToGoal > 0.35) {
        const desiredHeading = normalizeAngleDeg((Math.atan2(dy, dx) * 180) / Math.PI);
        sh.hullAngleDeg = rotateAngleTowards(sh.hullAngleDeg, desiredHeading, def.turnSpeedDegPerSec * dtSec);

        const rad = (sh.hullAngleDeg * Math.PI) / 180;
        const speedFactor = Math.min(1, distToGoal / 1.5);
        let stepX = Math.cos(rad) * def.speedCellsPerSec * speedFactor * dtSec;
        let stepY = Math.sin(rad) * def.speedCellsPerSec * speedFactor * dtSec;

        // Fleet separation force
        for (const other of ships) {
          if (other.shipId === sh.shipId) continue;
          const sepDx = sh.x - other.x;
          const sepDy = sh.y - other.y;
          const sepDist = Math.hypot(sepDx, sepDy);
          const minSep = def.radiusCells + (SHIP_DEFS[other.shipType]?.radiusCells || 0.5) + 0.25;
          if (sepDist > 0.001 && sepDist < minSep) {
            const push = ((minSep - sepDist) / minSep) * 1.8 * dtSec;
            stepX += (sepDx / sepDist) * push;
            stepY += (sepDy / sepDist) * push;
          }
        }

        const nextX = sh.x + stepX;
        const nextY = sh.y + stepY;

        if (this.isNavigableForShip(matchId, nextX, nextY)) {
          sh.vx = stepX / dtSec;
          sh.vy = stepY / dtSec;
          sh.x = nextX;
          sh.y = nextY;
        } else if (this.isNavigableForShip(matchId, nextX, sh.y)) {
          sh.vx = stepX / dtSec;
          sh.vy = 0;
          sh.x = nextX;
        } else if (this.isNavigableForShip(matchId, sh.x, nextY)) {
          sh.vx = 0;
          sh.vy = stepY / dtSec;
          sh.y = nextY;
        } else {
          // Detour steering around obstacle
          sh.hullAngleDeg = normalizeAngleDeg(sh.hullAngleDeg + 45);
          sh.vx = 0;
          sh.vy = 0;
        }
      } else {
        sh.vx = 0;
        sh.vy = 0;
        if (sh.orderType === 'move') sh.orderType = 'idle';
      }

      // 4. Independent Turret Aiming & Weapon Firing
      let combatTarget = null;
      let combatTargetX = 0;
      let combatTargetY = 0;

      if (sh.targetEntityId) {
        const tShip = this.ships.get(sh.targetEntityId);
        const tStruct = this.structures.get(sh.targetEntityId);
        if (tShip && tShip.hp > 0 && tShip.factionId !== sh.factionId) {
          const d = Math.hypot(tShip.x - sh.x, tShip.y - sh.y);
          if (d <= def.attackRangeCells) {
            combatTarget = tShip;
            combatTargetX = tShip.x;
            combatTargetY = tShip.y;
          }
        } else if (tStruct && tStruct.hp > 0 && tStruct.factionId !== sh.factionId) {
          const sx = tStruct.gridX + tStruct.width / 2;
          const sy = tStruct.gridY + tStruct.height / 2;
          const d = Math.hypot(sx - sh.x, sy - sh.y);
          if (d <= def.attackRangeCells) {
            combatTarget = tStruct;
            combatTargetX = sx;
            combatTargetY = sy;
          }
        }
      }

      // Auto-acquire nearest hostile in range based on unit role preference
      if (!combatTarget) {
        let bestScore = Infinity;
        for (const enemyShip of ships) {
          if (enemyShip.factionId === sh.factionId || enemyShip.hp <= 0) continue;
          const d = Math.hypot(enemyShip.x - sh.x, enemyShip.y - sh.y);
          if (d <= def.attackRangeCells) {
            const score = def.preferredTarget === 'ship' ? d * 0.7 : d * 1.2;
            if (score < bestScore) {
              bestScore = score;
              combatTarget = enemyShip;
              combatTargetX = enemyShip.x;
              combatTargetY = enemyShip.y;
            }
          }
        }
        for (const enemySt of structures) {
          if (enemySt.factionId === sh.factionId || enemySt.hp <= 0) continue;
          const sx = enemySt.gridX + enemySt.width / 2;
          const sy = enemySt.gridY + enemySt.height / 2;
          const d = Math.hypot(sx - sh.x, sy - sh.y);
          if (d <= def.attackRangeCells) {
            const score = def.preferredTarget === 'structure' ? d * 0.65 : d * 1.15;
            if (score < bestScore) {
              bestScore = score;
              combatTarget = enemySt;
              combatTargetX = sx;
              combatTargetY = sy;
            }
          }
        }
      }

      if (combatTarget) {
        const desiredTurret = normalizeAngleDeg(
          (Math.atan2(combatTargetY - sh.y, combatTargetX - sh.x) * 180) / Math.PI
        );
        sh.turretAngleDeg = rotateAngleTowards(
          sh.turretAngleDeg,
          desiredTurret,
          def.turretTurnSpeedDegPerSec * dtSec
        );
        const aimDiff = Math.abs(shortestAngleDiffDeg(sh.turretAngleDeg, desiredTurret));
        if (aimDiff <= 20 && this.nowMs - sh.lastFiredAtMs >= def.cooldownMs) {
          this.spawnProjectileInternal(matchId, sh.factionId, sh, 'ship', combatTarget, combatTargetX, combatTargetY);
        }
      } else {
        sh.turretAngleDeg = rotateAngleTowards(
          sh.turretAngleDeg,
          sh.hullAngleDeg,
          def.turretTurnSpeedDegPerSec * 0.6 * dtSec
        );
      }
    }
  }

  isNavigableForShip(matchId, x, y) {
    const gx = Math.floor(x);
    const gy = Math.floor(y);
    if (!this.isWaterCell(matchId, gx, gy)) return false;
    const occ = this.getStructuresAtCell(matchId, gx, gy);
    if (occ.surface && occ.surface.structureType === 'command_core') return false;
    if (occ.superstructure) return false;
    return true;
  }

  stepMatchProjectiles(match) {
    const matchId = match.matchId;
    for (const [projId, proj] of this.projectiles.entries()) {
      if (proj.matchId !== matchId) continue;
      if (this.nowMs < proj.impactAtMs) continue;

      this.projectiles.delete(projId);
      const attackerSlot = this.getSlot(matchId, proj.factionId);

      // Check direct target or splash radius hits
      let hitSomething = false;
      const targetShip = this.ships.get(proj.targetEntityId);
      const targetStruct = this.structures.get(proj.targetEntityId);

      if (targetShip && targetShip.hp > 0 && targetShip.factionId !== proj.factionId) {
        const armor = SHIP_DEFS[targetShip.shipType]?.armor || 0;
        const finalDmg = Math.max(4, proj.damage - armor);
        targetShip.hp -= finalDmg;
        hitSomething = true;
        this.emitEvent(matchId, 'impact', targetShip.x, targetShip.y, proj.factionId, {
          damage: finalDmg,
          targetId: targetShip.shipId,
        });
        if (targetShip.hp <= 0) {
          this.ships.delete(targetShip.shipId);
          const victimSlot = this.getSlot(matchId, targetShip.factionId);
          if (victimSlot) victimSlot.shipsLost += 1;
          if (attackerSlot) {
            attackerSlot.enemiesDestroyed += 1;
            const bounty = SHIP_DEFS[targetShip.shipType]?.killSalvageBounty || 30;
            attackerSlot.salvage += bounty;
            attackerSlot.totalSalvageGathered += bounty;
          }
          this.emitEvent(matchId, 'explosion', targetShip.x, targetShip.y, targetShip.factionId, {
            shipType: targetShip.shipType,
          });
        }
      } else if (targetStruct && targetStruct.hp > 0 && targetStruct.factionId !== proj.factionId) {
        const armor = STRUCTURE_DEFS[targetStruct.structureType]?.armor || 0;
        const finalDmg = Math.max(5, proj.damage * proj.structureMultiplier - armor);
        targetStruct.hp -= finalDmg;
        hitSomething = true;
        const sx = targetStruct.gridX + targetStruct.width / 2;
        const sy = targetStruct.gridY + targetStruct.height / 2;
        this.emitEvent(matchId, 'impact', sx, sy, proj.factionId, {
          damage: finalDmg,
          targetId: targetStruct.structureId,
        });
        if (targetStruct.hp <= 0) {
          if (attackerSlot) {
            attackerSlot.enemiesDestroyed += 1;
            attackerSlot.salvage += 35;
          }
          this.destroyStructureInternal(targetStruct);
        }
      }

      if (!hitSomething) {
        this.emitEvent(matchId, 'splash', proj.targetX, proj.targetY, proj.factionId, {});
      }
    }
  }

  // --------------------------------------------------------------------------
  // SERVER-OWNED AI BOT ENGINE
  // --------------------------------------------------------------------------

  stepMatchBots(match) {
    const matchId = match.matchId;
    for (const brain of this.botBrains.values()) {
      if (brain.matchId !== matchId) continue;
      const slot = this.getSlot(matchId, brain.slotIndex);
      if (!slot || slot.eliminated || slot.slotType !== 'bot') continue;

      const diff = BOT_DIFFICULTIES[brain.difficulty] || BOT_DIFFICULTIES.Commander;
      if (this.nowMs - brain.lastDecisionAtMs < diff.decisionIntervalMs) continue;
      brain.lastDecisionAtMs = this.nowMs;

      const callerId = slot.occupantIdentity;
      const myStructs = this.getMatchStructures(matchId).filter((s) => s.factionId === slot.slotIndex);
      const myShips = this.getMatchShips(matchId).filter((s) => s.factionId === slot.slotIndex);
      const core = myStructs.find((s) => s.structureType === 'command_core');
      if (!core) continue;

      const platforms = myStructs.filter((s) => s.structureType === 'platform' && s.isComplete);
      const shipyards = myStructs.filter((s) => s.structureType === 'shipyard');
      const rigs = myStructs.filter((s) => s.structureType === 'salvage_rig');
      const cannons = myStructs.filter((s) => s.structureType === 'cannon');
      const workshops = myStructs.filter((s) => s.structureType === 'workshop');

      // 1. Construct Shipyard first if none exists
      if (shipyards.length === 0 && slot.salvage >= STRUCTURE_DEFS.shipyard.cost) {
        this.tryBotBuildSuperstructure(callerId, matchId, slot.slotIndex, 'shipyard');
      }

      // 2. Expand Floating Platforms if below target or need building room
      if (platforms.length < diff.expandPlatformTarget && slot.salvage >= STRUCTURE_DEFS.platform.cost + 40) {
        this.tryBotExpandPlatform(callerId, matchId, slot.slotIndex, core);
      }

      // 3. Build Salvage Extractor if < 2
      if (rigs.length < 2 && slot.salvage >= STRUCTURE_DEFS.salvage_rig.cost) {
        const built = this.tryBotBuildSuperstructure(callerId, matchId, slot.slotIndex, 'salvage_rig');
        if (!built && slot.salvage >= STRUCTURE_DEFS.platform.cost) {
          this.tryBotExpandPlatform(callerId, matchId, slot.slotIndex, core);
        }
      }

      // 4. Build Defensive Cannon if < 2
      if (cannons.length < 2 && slot.salvage >= STRUCTURE_DEFS.cannon.cost) {
        this.tryBotBuildSuperstructure(callerId, matchId, slot.slotIndex, 'cannon');
      }

      // 5. Build Workshop if none
      if (workshops.length === 0 && shipyards.length > 0 && slot.salvage >= STRUCTURE_DEFS.workshop.cost) {
        this.tryBotBuildSuperstructure(callerId, matchId, slot.slotIndex, 'workshop');
      }

      // 6. Queue Naval Units from Shipyards
      for (const sy of shipyards) {
        if (!sy.isComplete || !sy.isConnected) continue;
        const q = JSON.parse(sy.productionQueueJson || '[]');
        if (q.length >= 2 || myShips.length >= diff.maxShips) continue;

        const scouts = myShips.filter((s) => s.shipType === 'scout').length;
        const gunboats = myShips.filter((s) => s.shipType === 'gunboat').length;

        let desiredShip = 'gunboat';
        if (scouts < 2) desiredShip = 'scout';
        else if (gunboats >= 2 && slot.salvage >= SHIP_DEFS.siege.cost) desiredShip = 'siege';

        if (slot.salvage >= SHIP_DEFS[desiredShip].cost) {
          try {
            this.queueShipProduction(callerId, { matchId, structureId: sy.structureId, shipType: desiredShip });
          } catch {}
        }
      }

      // 7. Tactical Fleet Orders: Defend Core, Harvest Salvage, or Siege Enemy Base
      const coreX = core.gridX + 1.5;
      const coreY = core.gridY + 1.5;
      const nearbyThreats = this.getMatchShips(matchId).filter(
        (s) => s.factionId !== slot.slotIndex && Math.hypot(s.x - coreX, s.y - coreY) <= 14
      );

      if (nearbyThreats.length > 0) {
        brain.currentGoal = 'defend';
        const threat = nearbyThreats[0];
        const idleOrAvailable = myShips.map((s) => s.shipId);
        if (idleOrAvailable.length > 0) {
          try {
            this.issueShipOrder(callerId, {
              matchId,
              shipIds: idleOrAvailable,
              orderType: 'attack_target',
              targetX: threat.x,
              targetY: threat.y,
              targetEntityId: threat.shipId,
            });
          } catch {}
        }
        continue;
      }

      // Send idle Scouts to nearest undepleted Salvage Deposit
      const nodes = this.getMatchNodes(matchId).filter((n) => n.remaining > 50);
      for (const sc of myShips.filter((s) => s.shipType === 'scout' && s.orderType === 'idle')) {
        if (nodes.length > 0) {
          nodes.sort((a, b) => Math.hypot(a.gridX - sc.x, a.gridY - sc.y) - Math.hypot(b.gridX - sc.x, b.gridY - sc.y));
          const targetNode = nodes[0];
          try {
            this.issueShipOrder(callerId, {
              matchId,
              shipIds: [sc.shipId],
              orderType: 'harvest',
              targetX: targetNode.gridX + 0.5,
              targetY: targetNode.gridY + 0.5,
            });
          } catch {}
        }
      }

      // Assemble Strike Fleet once threshold reached
      const strikeShips = myShips.filter((s) => s.shipType !== 'scout' || myShips.length >= diff.attackFleetThreshold + 1);
      if (strikeShips.length >= diff.attackFleetThreshold) {
        brain.currentGoal = 'siege_attack';
        const enemyCores = this.getMatchStructures(matchId).filter(
          (s) => s.factionId !== slot.slotIndex && s.structureType === 'command_core'
        );
        if (enemyCores.length > 0) {
          enemyCores.sort(
            (a, b) => Math.hypot(a.gridX - coreX, a.gridY - coreY) - Math.hypot(b.gridX - coreX, b.gridY - coreY)
          );
          const targetCore = enemyCores[0];
          const readyAttackers = strikeShips.filter((s) => s.orderType === 'idle').map((s) => s.shipId);
          if (readyAttackers.length > 0) {
            try {
              this.issueShipOrder(callerId, {
                matchId,
                shipIds: readyAttackers,
                orderType: 'attack_target',
                targetX: targetCore.gridX + 1.5,
                targetY: targetCore.gridY + 1.5,
                targetEntityId: targetCore.structureId,
              });
            } catch {}
          }
        }
      }
    }
  }

  tryBotExpandPlatform(callerId, matchId, factionId, core) {
    for (let r = 1; r <= 7; r++) {
      for (let dy = -r; dy <= core.height + r; dy++) {
        for (let dx = -r; dx <= core.width + r; dx++) {
          const gx = core.gridX + dx;
          const gy = core.gridY + dy;
          const check = this.validateStructurePlacement(matchId, factionId, 'platform', gx, gy, 0);
          if (check.valid) {
            try {
              this.placeStructure(callerId, { matchId, structureType: 'platform', gridX: gx, gridY: gy, rotationDeg: 0 });
              return true;
            } catch {}
          }
        }
      }
    }
    return false;
  }

  tryBotBuildSuperstructure(callerId, matchId, factionId, structureType) {
    const myPlatforms = this.getMatchStructures(matchId).filter(
      (s) => s.factionId === factionId && s.structureType === 'platform' && s.isComplete && s.isConnected
    );
    for (const plat of myPlatforms) {
      const check = this.validateStructurePlacement(matchId, factionId, structureType, plat.gridX, plat.gridY, 0);
      if (check.valid) {
        try {
          this.placeStructure(callerId, {
            matchId,
            structureType,
            gridX: plat.gridX,
            gridY: plat.gridY,
            rotationDeg: 0,
          });
          return true;
        } catch {}
      }
    }
    return false;
  }

  stepSuddenDeathCheck(match) {
    const elapsed = this.nowMs - match.startedAtMs;
    if (elapsed < GAME_CONSTANTS.SUDDEN_DEATH_TIME_MS) return;

    const surviving = this.getMatchSlots(match.matchId).filter((s) => s.slotType !== 'empty' && !s.eliminated);
    if (surviving.length <= 1) return;

    // Tiebreaker score: Core HP + active structures * 80 + active ships * 100 + total salvage * 0.2
    let bestSlot = surviving[0];
    let bestScore = -1;

    for (const s of surviving) {
      const structs = this.getMatchStructures(match.matchId).filter((st) => st.factionId === s.slotIndex);
      const ships = this.getMatchShips(match.matchId).filter((sh) => sh.factionId === s.slotIndex);
      const coreHp = structs.find((st) => st.structureType === 'command_core')?.hp || 0;
      const score = coreHp + structs.length * 80 + ships.length * 100 + s.totalSalvageGathered * 0.2;
      if (score > bestScore) {
        bestScore = score;
        bestSlot = s;
      }
    }

    match.status = 'finished';
    match.winnerFactionId = bestSlot.slotIndex;
    match.victoryReason = `Sudden Death Tiebreaker won by ${bestSlot.playerName} (Naval Dominance Score: ${Math.round(bestScore)})`;
  }

  // --------------------------------------------------------------------------
  // SERVER-SIDE FOG OF WAR & AUTHORIZED STATE VIEW
  // Clients never receive raw enemy structures/ships outside their vision
  // radius or private BotBrain rows.
  // --------------------------------------------------------------------------

  getAuthorizedMatchView(callerIdentity, matchId) {
    const match = this.matches.get(matchId);
    if (!match) throw new Error('Match not found');

    const slots = this.getMatchSlots(matchId);
    const callerSlot = this.getSlotByIdentity(matchId, callerIdentity);
    const isSpectator = !callerSlot || callerSlot.eliminated || match.status === 'finished';

    const allStructures = this.getMatchStructures(matchId);
    const allShips = this.getMatchShips(matchId);
    const nodes = this.getMatchNodes(matchId);

    // Compute vision sources for caller's faction
    const visionSources = [];
    if (!isSpectator && match.fogOfWarEnabled) {
      for (const st of allStructures) {
        if (st.factionId === callerSlot.slotIndex && st.hp > 0) {
          const def = STRUCTURE_DEFS[st.structureType];
          visionSources.push({
            x: st.gridX + st.width / 2,
            y: st.gridY + st.height / 2,
            r: def ? def.visionCells : 6,
          });
        }
      }
      for (const sh of allShips) {
        if (sh.factionId === callerSlot.slotIndex && sh.hp > 0) {
          const def = SHIP_DEFS[sh.shipType];
          visionSources.push({
            x: sh.x,
            y: sh.y,
            r: def ? def.visionCells : 8,
          });
        }
      }
    }

    const isPointVisible = (x, y) => {
      if (isSpectator || !match.fogOfWarEnabled) return true;
      for (const src of visionSources) {
        if (Math.hypot(x - src.x, y - src.y) <= src.r) return true;
      }
      return false;
    };

    // Filter structures and sanitize enemy production queues
    const visibleStructures = [];
    for (const st of allStructures) {
      const cx = st.gridX + st.width / 2;
      const cy = st.gridY + st.height / 2;
      if (
        isSpectator ||
        !match.fogOfWarEnabled ||
        (callerSlot && st.factionId === callerSlot.slotIndex) ||
        isPointVisible(cx, cy)
      ) {
        const isOwn = callerSlot && st.factionId === callerSlot.slotIndex;
        visibleStructures.push({
          ...st,
          // Redact enemy production queues & internal targets
          productionQueueJson: isOwn || isSpectator ? st.productionQueueJson : '[]',
        });
      }
    }

    // Filter ships and redact secret enemy move/attack coordinates
    const visibleShips = [];
    for (const sh of allShips) {
      if (
        isSpectator ||
        !match.fogOfWarEnabled ||
        (callerSlot && sh.factionId === callerSlot.slotIndex) ||
        isPointVisible(sh.x, sh.y)
      ) {
        const isOwn = callerSlot && sh.factionId === callerSlot.slotIndex;
        visibleShips.push({
          ...sh,
          targetX: isOwn || isSpectator ? sh.targetX : sh.x,
          targetY: isOwn || isSpectator ? sh.targetY : sh.y,
          orderType: isOwn || isSpectator ? sh.orderType : 'hidden',
        });
      }
    }

    // Filter active projectiles
    const visibleProjectiles = [];
    for (const proj of this.projectiles.values()) {
      if (proj.matchId !== matchId) continue;
      if (isPointVisible(proj.startX, proj.startY) || isPointVisible(proj.targetX, proj.targetY)) {
        visibleProjectiles.push({ ...proj });
      }
    }

    // Filter recent world events
    const visibleEvents = [];
    for (const evt of this.worldEvents.values()) {
      if (evt.matchId !== matchId) continue;
      if (evt.eventType === 'alert') {
        if (callerSlot && evt.factionId === callerSlot.slotIndex) {
          visibleEvents.push({ ...evt });
        }
      } else if (isPointVisible(evt.x, evt.y)) {
        visibleEvents.push({ ...evt });
      }
    }

    // Sanitize enemy salvage reserves while match is active unless spectator
    const sanitizedSlots = slots.map((s) => {
      const isOwn = callerSlot && s.slotIndex === callerSlot.slotIndex;
      return {
        ...s,
        salvage: isOwn || isSpectator ? s.salvage : Math.floor(s.salvage / 50) * 50,
      };
    });

    return {
      nowMs: this.nowMs,
      match: { ...match },
      callerSlotIndex: callerSlot ? callerSlot.slotIndex : -1,
      isSpectator,
      visionSources,
      slots: sanitizedSlots,
      resourceNodes: nodes.map((n) => ({ ...n })),
      structures: visibleStructures,
      ships: visibleShips,
      projectiles: visibleProjectiles,
      events: visibleEvents,
      terrainCells: this.terrainCache.get(matchId) || null,
    };
  }

  // Deterministic state digest for testing reproducibility
  computeDeterministicDigest(matchId) {
    const structures = this.getMatchStructures(matchId).map(
      (s) => `${s.structureType}:${s.factionId}:${s.gridX},${s.gridY}:${Math.round(s.hp)}:${s.isConnected}`
    );
    const ships = this.getMatchShips(matchId).map(
      (s) => `${s.shipType}:${s.factionId}:${s.x.toFixed(2)},${s.y.toFixed(2)}:${Math.round(s.hp)}`
    );
    const nodes = this.getMatchNodes(matchId).map((n) => `${n.gridX},${n.gridY}:${Math.round(n.remaining)}`);
    const slots = this.getMatchSlots(matchId).map((s) => `${s.slotIndex}:${Math.round(s.salvage)}:${s.eliminated}`);
    return JSON.stringify({ slots, nodes, structures, ships });
  }
}
