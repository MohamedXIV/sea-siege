// ============================================================================
// SEA SIEGE — Handcrafted Procedural Pixel-Art Sprite & Silhouette Generator
// Generates crisp 90-degree overhead naval hulls, turrets, floating steel
// platforms, and 82-85 degree top-down extruded industrial structures.
// ============================================================================

export class PixelAssetGenerator {
  constructor() {
    this.cache = new Map();
  }

  getStructureCanvas(structureType, factionColor = '#38bdf8', isConnected = true, isComplete = true) {
    const key = `struct_${structureType}_${factionColor}_${isConnected}_${isComplete}`;
    if (this.cache.has(key)) return this.cache.get(key);

    const dims = {
      command_core: [120, 120],
      platform: [40, 40],
      workshop: [80, 80],
      shipyard: [80, 80],
      cannon: [40, 40],
      salvage_rig: [80, 80],
    }[structureType] || [40, 40];

    const canvas = document.createElement('canvas');
    canvas.width = dims[0];
    canvas.height = dims[1];
    const ctx = canvas.getContext('2d');
    ctx.imageSmoothingEnabled = false;

    const w = dims[0];
    const h = dims[1];
    const accent = isConnected ? factionColor : '#64748b';

    if (structureType === 'platform') {
      // 90-degree overhead steel grate deck with subtle 3px bottom-edge extrusion
      ctx.fillStyle = '#0f172a';
      ctx.fillRect(1, 1, w - 2, h - 2);
      // Extruded lower lip
      ctx.fillStyle = '#1e293b';
      ctx.fillRect(2, h - 5, w - 4, 4);
      // Main steel plate
      ctx.fillStyle = '#334155';
      ctx.fillRect(2, 2, w - 4, h - 6);
      // Industrial cross-grating pixels
      ctx.fillStyle = '#1e293b';
      for (let y = 6; y < h - 8; y += 6) {
        for (let x = 6; x < w - 6; x += 6) {
          ctx.fillRect(x, y, 3, 3);
        }
      }
      // Corner rivets & faction trim
      ctx.fillStyle = '#94a3b8';
      ctx.fillRect(4, 4, 2, 2);
      ctx.fillRect(w - 6, 4, 2, 2);
      ctx.fillRect(4, h - 8, 2, 2);
      ctx.fillRect(w - 6, h - 8, 2, 2);
      ctx.fillStyle = accent;
      ctx.fillRect(w / 2 - 4, 3, 8, 2);
    } else if (structureType === 'command_core') {
      // 3x3 Drowned Industrial Citadel with octagonal reactor dome & hazard stripes
      ctx.fillStyle = '#090d16';
      ctx.fillRect(2, 2, w - 4, h - 4);
      // 83-deg south-side architectural extrusion shadow
      ctx.fillStyle = '#1e293b';
      ctx.fillRect(6, h - 14, w - 12, 10);
      // Base fortress deck
      ctx.fillStyle = '#334155';
      ctx.fillRect(6, 6, w - 12, h - 18);
      // Hazard caution border
      ctx.fillStyle = '#eab308';
      for (let i = 10; i < w - 14; i += 12) {
        ctx.fillRect(i, 8, 6, 3);
        ctx.fillRect(i, h - 16, 6, 3);
      }
      // Elevated steel superstructure tier
      ctx.fillStyle = '#475569';
      ctx.fillRect(18, 16, w - 36, h - 38);
      ctx.fillStyle = '#1e293b';
      ctx.fillRect(18, h - 24, w - 36, 6);
      // Faction beacon core
      ctx.fillStyle = accent;
      ctx.fillRect(w / 2 - 16, h / 2 - 18, 32, 28);
      ctx.fillStyle = '#e0f2fe';
      ctx.fillRect(w / 2 - 8, h / 2 - 10, 16, 12);
    } else if (structureType === 'shipyard') {
      // 2x2 Naval Slipway & Gantry Crane
      ctx.fillStyle = '#1e293b';
      ctx.fillRect(4, 4, w - 8, h - 8);
      // Water slipway basin inside dock
      ctx.fillStyle = '#082f49';
      ctx.fillRect(14, 14, w - 28, h - 22);
      // Gantry rails left & right
      ctx.fillStyle = '#475569';
      ctx.fillRect(6, 6, 10, h - 14);
      ctx.fillRect(w - 16, 6, 10, h - 14);
      // Overhead orange/yellow crane bridge
      ctx.fillStyle = '#d97706';
      ctx.fillRect(6, 22, w - 12, 10);
      ctx.fillStyle = accent;
      ctx.fillRect(10, 8, w - 20, 5);
    } else if (structureType === 'workshop') {
      // 2x2 Industrial Foundry & Repair Crane
      ctx.fillStyle = '#1e293b';
      ctx.fillRect(6, h - 12, w - 12, 8);
      ctx.fillStyle = '#334155';
      ctx.fillRect(6, 6, w - 12, h - 16);
      // Sawtooth industrial roof ridges
      ctx.fillStyle = '#475569';
      ctx.fillRect(10, 12, w - 20, 14);
      ctx.fillRect(10, 32, w - 20, 14);
      // Glowing repair arc furnace
      ctx.fillStyle = '#f97316';
      ctx.fillRect(w - 28, h - 30, 14, 14);
      ctx.fillStyle = accent;
      ctx.fillRect(12, 14, 16, 6);
    } else if (structureType === 'salvage_rig') {
      // 2x2 Dredging Derrick & Scrap Conveyor
      ctx.fillStyle = '#1e293b';
      ctx.fillRect(6, h - 12, w - 12, 8);
      ctx.fillStyle = '#334155';
      ctx.fillRect(6, 6, w - 12, h - 16);
      // Dredge pit
      ctx.fillStyle = '#0f172a';
      ctx.fillRect(16, 16, 24, 24);
      ctx.fillStyle = '#ca8a04';
      ctx.fillRect(20, 20, 16, 16);
      // Faction storage silos
      ctx.fillStyle = accent;
      ctx.fillRect(w - 28, 14, 16, 16);
      ctx.fillRect(w - 28, 36, 16, 16);
    } else if (structureType === 'cannon') {
      // 1x1 Armored Turret Pedestal (barrel is drawn dynamically with turretAngleDeg)
      ctx.fillStyle = '#1e293b';
      ctx.fillRect(4, 4, w - 8, h - 8);
      ctx.fillStyle = '#475569';
      ctx.fillRect(7, 7, w - 14, h - 14);
      ctx.fillStyle = accent;
      ctx.fillRect(12, 12, w - 24, h - 24);
    }

    if (!isComplete) {
      ctx.strokeStyle = '#eab308';
      ctx.lineWidth = 2;
      ctx.strokeRect(2, 2, w - 4, h - 4);
    }

    this.cache.set(key, canvas);
    return canvas;
  }
}
