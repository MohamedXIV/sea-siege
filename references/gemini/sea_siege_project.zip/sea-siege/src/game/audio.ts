// ============================================================================
// SEA SIEGE — Synthesized Industrial Naval Audio & Atmosphere Engine
// Uses Web Audio API to generate responsive sound effects and ocean/weather
// ambience without blocking initialization or requiring external audio files.
// ============================================================================

export class SeaSiegeAudioEngine {
  constructor() {
    this.ctx = null;
    this.masterGain = null;
    this.sfxGain = null;
    this.ambienceGain = null;
    this.muted = false;
    this.sfxVolume = 0.65;
    this.musicVolume = 0.35;
    this.ambienceRunning = false;
  }

  ensureContext() {
    if (this.ctx) {
      if (this.ctx.state === 'suspended') {
        this.ctx.resume().catch(() => {});
      }
      return this.ctx;
    }
    try {
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      if (!AudioCtx) return null;
      this.ctx = new AudioCtx();
      this.masterGain = this.ctx.createGain();
      this.sfxGain = this.ctx.createGain();
      this.ambienceGain = this.ctx.createGain();

      this.sfxGain.gain.value = this.sfxVolume;
      this.ambienceGain.gain.value = this.musicVolume;
      this.masterGain.gain.value = this.muted ? 0 : 1;

      this.sfxGain.connect(this.masterGain);
      this.ambienceGain.connect(this.masterGain);
      this.masterGain.connect(this.ctx.destination);
      this.startOceanAmbience();
    } catch {
      return null;
    }
    return this.ctx;
  }

  setMuted(muted) {
    this.muted = Boolean(muted);
    if (this.masterGain && this.ctx) {
      this.masterGain.gain.setTargetAtTime(this.muted ? 0 : 1, this.ctx.currentTime, 0.04);
    }
  }

  setVolumes({ sfx, music }) {
    if (typeof sfx === 'number') {
      this.sfxVolume = Math.max(0, Math.min(1, sfx));
      if (this.sfxGain && this.ctx) {
        this.sfxGain.gain.setTargetAtTime(this.sfxVolume, this.ctx.currentTime, 0.05);
      }
    }
    if (typeof music === 'number') {
      this.musicVolume = Math.max(0, Math.min(1, music));
      if (this.ambienceGain && this.ctx) {
        this.ambienceGain.gain.setTargetAtTime(this.musicVolume, this.ctx.currentTime, 0.05);
      }
    }
  }

  startOceanAmbience() {
    if (this.ambienceRunning || !this.ctx) return;
    this.ambienceRunning = true;
    try {
      const bufferSize = this.ctx.sampleRate * 3;
      const noiseBuffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
      const output = noiseBuffer.getChannelData(0);
      let lastOut = 0.0;
      for (let i = 0; i < bufferSize; i++) {
        const white = Math.random() * 2 - 1;
        output[i] = (lastOut + 0.02 * white) / 1.02;
        lastOut = output[i];
        output[i] *= 0.25;
      }
      const whiteNoise = this.ctx.createBufferSource();
      whiteNoise.buffer = noiseBuffer;
      whiteNoise.loop = true;

      const filter = this.ctx.createBiquadFilter();
      filter.type = 'lowpass';
      filter.frequency.value = 180;

      whiteNoise.connect(filter);
      filter.connect(this.ambienceGain);
      whiteNoise.start(0);
    } catch {}
  }

  playUiClick() {
    const ctx = this.ensureContext();
    if (!ctx || this.muted) return;
    try {
      const osc = ctx.createOscillator();
      const g = ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(520, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(260, ctx.currentTime + 0.06);
      g.gain.setValueAtTime(0.18, ctx.currentTime);
      g.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.06);
      osc.connect(g);
      g.connect(this.sfxGain);
      osc.start();
      osc.stop(ctx.currentTime + 0.07);
    } catch {}
  }

  playBuildPlace() {
    const ctx = this.ensureContext();
    if (!ctx || this.muted) return;
    try {
      const osc = ctx.createOscillator();
      const g = ctx.createGain();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(140, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(290, ctx.currentTime + 0.14);
      g.gain.setValueAtTime(0.25, ctx.currentTime);
      g.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.15);
      osc.connect(g);
      g.connect(this.sfxGain);
      osc.start();
      osc.stop(ctx.currentTime + 0.16);
    } catch {}
  }

  playOrderAck() {
    const ctx = this.ensureContext();
    if (!ctx || this.muted) return;
    try {
      const osc = ctx.createOscillator();
      const g = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(420, ctx.currentTime);
      osc.frequency.setValueAtTime(640, ctx.currentTime + 0.06);
      g.gain.setValueAtTime(0.15, ctx.currentTime);
      g.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.14);
      osc.connect(g);
      g.connect(this.sfxGain);
      osc.start();
      osc.stop(ctx.currentTime + 0.15);
    } catch {}
  }

  playCannonFire() {
    const ctx = this.ensureContext();
    if (!ctx || this.muted) return;
    try {
      const osc = ctx.createOscillator();
      const g = ctx.createGain();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(115, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(32, ctx.currentTime + 0.22);
      g.gain.setValueAtTime(0.32, ctx.currentTime);
      g.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.23);
      osc.connect(g);
      g.connect(this.sfxGain);
      osc.start();
      osc.stop(ctx.currentTime + 0.24);
    } catch {}
  }

  playExplosion() {
    const ctx = this.ensureContext();
    if (!ctx || this.muted) return;
    try {
      const osc = ctx.createOscillator();
      const g = ctx.createGain();
      osc.type = 'square';
      osc.frequency.setValueAtTime(80, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(18, ctx.currentTime + 0.45);
      g.gain.setValueAtTime(0.4, ctx.currentTime);
      g.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.46);
      osc.connect(g);
      g.connect(this.sfxGain);
      osc.start();
      osc.stop(ctx.currentTime + 0.48);
    } catch {}
  }

  playVictory(isWinner = true) {
    const ctx = this.ensureContext();
    if (!ctx || this.muted) return;
    try {
      const notes = isWinner ? [261.6, 329.6, 392.0, 523.2] : [293.6, 261.6, 220.0, 174.6];
      notes.forEach((freq, idx) => {
        const osc = ctx.createOscillator();
        const g = ctx.createGain();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(freq, ctx.currentTime + idx * 0.14);
        g.gain.setValueAtTime(0.22, ctx.currentTime + idx * 0.14);
        g.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + idx * 0.14 + 0.35);
        osc.connect(g);
        g.connect(this.sfxGain);
        osc.start(ctx.currentTime + idx * 0.14);
        osc.stop(ctx.currentTime + idx * 0.14 + 0.36);
      });
    } catch {}
  }
}
