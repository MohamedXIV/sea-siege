// ============================================================================
// SEA SIEGE — Interactive Living Ocean & Battlefield Renderer (src/game/scene.ts)
// Implements 90-degree overhead naval viewport, quantized wave bands, evolving
// ship wakes, platform contact foam, water splash ripples, muzzle flashes,
// independent hull/turret rotation, Fog of War shroud, and RTS input/camera.
// ============================================================================

import {
  GAME_CONSTANTS,
  FACTION_PALETTES,
  STRUCTURE_DEFS,
  SHIP_DEFS,
  TERRAIN_TYPES,
} from '../shared/balance.js';
import { PixelAssetGenerator } from './assets.js';

export class SeaSiegeBattlefieldRenderer {
  constructor(canvas, { onSelectEntities, onIssueOrder, onPlaceStructure, audio }) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d');
    this.onSelectEntities = onSelectEntities;
    this.onIssueOrder = onIssueOrder;
    this.onPlaceStructure = onPlaceStructure;
    this.audio = audio;
    this.assets = new PixelAssetGenerator();

    this.camera = {
      x: 400,
      y: 400,
      zoom: 1.0,
    };

    this.viewState = null;
    this.selectedIds = new Set();
    this.buildMode = null; // { structureType, rotationDeg }
    this.hoverCell = { gx: -1, gy: -1, worldX: 0, worldY: 0 };
    this.dragBox = null; // { startX, startY, currX, currY }
    this.isPanning = false;
    this.panStart = { x: 0, y: 0, camX: 0, camY: 0 };

    // Living Ocean disturbance & VFX pools
    this.wakes = []; // { x, y, radius, alpha, maxRadius }
    this.ripples = []; // { x, y, radius, maxRadius, alpha, color }
    this.particles = []; // { x, y, vx, vy, size, alpha, color, life, maxLife }
    this.rainDrops = [];
    this.processedEventIds = new Set();
    this.shipVisualCache = new Map(); // shipId -> { x, y, hullAngleDeg, turretAngleDeg, lastWakeMs }
    this.graphicsQuality = 'high'; // 'high' | 'low'
    this.edgeScrollEnabled = false;
    this.keysDown = new Set();

    this.initRain();
    this.bindInputEvents();
  }

  initRain() {
    this.rainDrops = [];
    for (let i = 0; i < 65; i++) {
      this.rainDrops.push({
        x: Math.random() * 1600,
        y: Math.random() * 1000,
        len: 10 + Math.random() * 12,
        speed: 380 + Math.random() * 160,
      });
    }
  }

  centerCameraOnFaction(view) {
    if (!view || !view.structures) return;
    const myCore = view.structures.find(
      (s) => s.factionId === view.callerSlotIndex && s.structureType === 'command_core'
    ) || view.structures[0];
    if (myCore) {
      const ts = GAME_CONSTANTS.TILE_SIZE;
      this.camera.x = (myCore.gridX + 1.5) * ts - this.canvas.width / (2 * this.camera.zoom);
      this.camera.y = (myCore.gridY + 1.5) * ts - this.canvas.height / (2 * this.camera.zoom);
    }
  }

  screenToWorld(sx, sy) {
    const wx = sx / this.camera.zoom + this.camera.x;
    const wy = sy / this.camera.zoom + this.camera.y;
    const ts = GAME_CONSTANTS.TILE_SIZE;
    return {
      worldX: wx / ts,
      worldY: wy / ts,
      gx: Math.floor(wx / ts),
      gy: Math.floor(wy / ts),
    };
  }

  worldToScreen(wxCells, wyCells) {
    const ts = GAME_CONSTANTS.TILE_SIZE;
    return {
      sx: (wxCells * ts - this.camera.x) * this.camera.zoom,
      sy: (wyCells * ts - this.camera.y) * this.camera.zoom,
    };
  }

  bindInputEvents() {
    this.onMouseDown = (e) => {
      const rect = this.canvas.getBoundingClientRect();
      const sx = e.clientX - rect.left;
      const sy = e.clientY - rect.top;
      const world = this.screenToWorld(sx, sy);

      // Middle mouse button or Alt+LeftClick -> Pan camera
      if (e.button === 1 || (e.button === 0 && e.altKey)) {
        this.isPanning = true;
        this.panStart = { x: sx, y: sy, camX: this.camera.x, camY: this.camera.y };
        return;
      }

      // Right Click -> Cancel build mode or Issue Move / Attack / Harvest Order
      if (e.button === 2) {
        e.preventDefault();
        if (this.buildMode) {
          this.buildMode = null;
          return;
        }
        this.handleRightClickOrder(world);
        return;
      }

      // Left Click -> Place Structure if in buildMode, else start selection box
      if (e.button === 0) {
        if (this.buildMode) {
          this.onPlaceStructure({
            structureType: this.buildMode.structureType,
            gridX: world.gx,
            gridY: world.gy,
            rotationDeg: this.buildMode.rotationDeg || 0,
          });
          return;
        }
        this.dragBox = { startX: sx, startY: sy, currX: sx, currY: sy };
      }
    };

    this.onMouseMove = (e) => {
      const rect = this.canvas.getBoundingClientRect();
      const sx = e.clientX - rect.left;
      const sy = e.clientY - rect.top;
      this.hoverCell = this.screenToWorld(sx, sy);

      if (this.isPanning) {
        const dx = (sx - this.panStart.x) / this.camera.zoom;
        const dy = (sy - this.panStart.y) / this.camera.zoom;
        this.camera.x = this.panStart.camX - dx;
        this.camera.y = this.panStart.camY - dy;
        return;
      }

      if (this.dragBox) {
        this.dragBox.currX = sx;
        this.dragBox.currY = sy;
      }
    };

    this.onMouseUp = (e) => {
      if (this.isPanning) {
        this.isPanning = false;
        return;
      }
      if (e.button === 0 && this.dragBox) {
        const box = this.dragBox;
        this.dragBox = null;
        this.resolveSelectionBox(box, e.shiftKey);
      }
    };

    this.onWheel = (e) => {
      e.preventDefault();
      const rect = this.canvas.getBoundingClientRect();
      const sx = e.clientX - rect.left;
      const sy = e.clientY - rect.top;
      const before = this.screenToWorld(sx, sy);

      const zoomFactor = e.deltaY < 0 ? 1.12 : 0.89;
      this.camera.zoom = Math.max(0.45, Math.min(2.2, this.camera.zoom * zoomFactor));

      const ts = GAME_CONSTANTS.TILE_SIZE;
      this.camera.x = before.worldX * ts - sx / this.camera.zoom;
      this.camera.y = before.worldY * ts - sy / this.camera.zoom;
    };

    this.onContextMenu = (e) => e.preventDefault();

    this.canvas.addEventListener('mousedown', this.onMouseDown);
    window.addEventListener('mousemove', this.onMouseMove);
    window.addEventListener('mouseup', this.onMouseUp);
    this.canvas.addEventListener('wheel', this.onWheel, { passive: false });
    this.canvas.addEventListener('contextmenu', this.onContextMenu);
  }

  resolveSelectionBox(box, additive = false) {
    if (!this.viewState) return;
    const dist = Math.hypot(box.currX - box.startX, box.currY - box.startY);
    const nextSelection = additive ? new Set(this.selectedIds) : new Set();

    if (dist < 6) {
      // Single click selection
      const world = this.screenToWorld(box.currX, box.currY);
      let clickedId = null;

      for (const sh of this.viewState.ships) {
        if (Math.hypot(sh.x - world.worldX, sh.y - world.worldY) <= 0.85) {
          clickedId = sh.shipId;
          break;
        }
      }

      if (!clickedId) {
        // Prefer superstructure over surface platform when clicking a cell
        const structsAtCell = this.viewState.structures.filter(
          (st) =>
            world.gx >= st.gridX &&
            world.gx < st.gridX + st.width &&
            world.gy >= st.gridY &&
            world.gy < st.gridY + st.height
        );
        const superSt = structsAtCell.find((s) => s.channel === 'superstructure');
        const surfSt = structsAtCell.find((s) => s.channel === 'surface');
        if (superSt) clickedId = superSt.structureId;
        else if (surfSt) clickedId = surfSt.structureId;
      }

      if (clickedId) {
        nextSelection.add(clickedId);
        this.audio?.playUiClick();
      }
    } else {
      // Box drag-select own ships inside screen rectangle
      const minX = Math.min(box.startX, box.currX);
      const maxX = Math.max(box.startX, box.currX);
      const minY = Math.min(box.startY, box.currY);
      const maxY = Math.max(box.startY, box.currY);

      for (const sh of this.viewState.ships) {
        if (sh.factionId !== this.viewState.callerSlotIndex) continue;
        const scr = this.worldToScreen(sh.x, sh.y);
        if (scr.sx >= minX && scr.sx <= maxX && scr.sy >= minY && scr.sy <= maxY) {
          nextSelection.add(sh.shipId);
        }
      }
      if (nextSelection.size > 0) this.audio?.playUiClick();
    }

    this.selectedIds = nextSelection;
    this.onSelectEntities?.(Array.from(this.selectedIds));
  }

  handleRightClickOrder(world) {
    if (!this.viewState) return;
    const ownedSelectedShips = this.viewState.ships
      .filter((s) => s.factionId === this.viewState.callerSlotIndex && this.selectedIds.has(s.shipId))
      .map((s) => s.shipId);

    if (ownedSelectedShips.length === 0) return;

    // Check if right-clicking an enemy ship or structure
    let targetEnemyId = '';
    for (const sh of this.viewState.ships) {
      if (sh.factionId !== this.viewState.callerSlotIndex && Math.hypot(sh.x - world.worldX, sh.y - world.worldY) <= 0.95) {
        targetEnemyId = sh.shipId;
        break;
      }
    }
    if (!targetEnemyId) {
      for (const st of this.viewState.structures) {
        if (
          st.factionId !== this.viewState.callerSlotIndex &&
          world.gx >= st.gridX &&
          world.gx < st.gridX + st.width &&
          world.gy >= st.gridY &&
          world.gy < st.gridY + st.height
        ) {
          targetEnemyId = st.structureId;
          break;
        }
      }
    }

    if (targetEnemyId) {
      this.onIssueOrder?.({
        shipIds: ownedSelectedShips,
        orderType: 'attack_target',
        targetX: world.worldX,
        targetY: world.worldY,
        targetEntityId: targetEnemyId,
      });
      this.spawnOrderRipple(world.worldX, world.worldY, '#ef4444');
      this.audio?.playOrderAck();
      return;
    }

    // Check if right-clicking a Salvage Deposit
    const node = this.viewState.resourceNodes.find(
      (n) => Math.hypot(n.gridX + 0.5 - world.worldX, n.gridY + 0.5 - world.worldY) <= 1.2
    );
    if (node) {
      this.onIssueOrder?.({
        shipIds: ownedSelectedShips,
        orderType: 'harvest',
        targetX: node.gridX + 0.5,
        targetY: node.gridY + 0.5,
      });
      this.spawnOrderRipple(node.gridX + 0.5, node.gridY + 0.5, '#eab308');
      this.audio?.playOrderAck();
      return;
    }

    // Default move order
    this.onIssueOrder?.({
      shipIds: ownedSelectedShips,
      orderType: 'move',
      targetX: world.worldX,
      targetY: world.worldY,
    });
    this.spawnOrderRipple(world.worldX, world.worldY, '#38bdf8');
    this.audio?.playOrderAck();
  }

  spawnOrderRipple(wx, wy, color) {
    this.ripples.push({
      x: wx * GAME_CONSTANTS.TILE_SIZE,
      y: wy * GAME_CONSTANTS.TILE_SIZE,
      radius: 4,
      maxRadius: 28,
      alpha: 0.9,
      color,
    });
  }

  render(dtSec, nowPerfMs) {
    const ctx = this.ctx;
    const width = this.canvas.width;
    const height = this.canvas.height;
    ctx.clearRect(0, 0, width, height);

    if (!this.viewState) return;
    const view = this.viewState;
    const ts = GAME_CONSTANTS.TILE_SIZE;
    const mapCells = view.match.mapCells;

    this.processWorldEvents(view.events);

    ctx.save();
    ctx.scale(this.camera.zoom, this.camera.zoom);
    ctx.translate(-this.camera.x, -this.camera.y);

    // 1. LIVING INTERACTIVE OCEAN LAYER
    this.renderInteractiveOcean(ctx, mapCells, ts, nowPerfMs);

    // 2. TERRAIN OBSTACLES & SUBMERGED INDUSTRIAL RUINS
    this.renderTerrainAndNodes(ctx, view, ts, nowPerfMs);

    // 3. WATER WAKES & RIPPLES
    this.updateAndRenderWaterDisturbances(ctx, dtSec);

    // 4. STRUCTURES (Surface Platforms first, then Superstructures)
    this.renderStructures(ctx, view, ts, nowPerfMs);

    // 5. NAVAL SHIPS & INDEPENDENT TURRETS
    this.renderShips(ctx, view, dtSec, ts, nowPerfMs);

    // 6. AUTHORITATIVE PROJECTILES & VFX PARTICLES
    this.renderProjectilesAndParticles(ctx, view, dtSec, ts);

    // 7. PLACEMENT PREVIEW (When in Build Mode)
    if (this.buildMode) {
      this.renderBuildPreview(ctx, view, ts);
    }

    // 8. SERVER-ENFORCED FOG OF WAR SHROUD
    if (view.match.fogOfWarEnabled && !view.isSpectator) {
      this.renderFogOfWar(ctx, view, mapCells, ts);
    }

    ctx.restore();

    // 9. ATMOSPHERIC RAIN & SELECTION DRAG BOX IN SCREEN SPACE
    if (this.graphicsQuality === 'high') {
      this.renderAtmosphericRain(ctx, width, height, dtSec);
    }
    if (this.dragBox) {
      ctx.save();
      ctx.strokeStyle = '#38bdf8';
      ctx.fillStyle = 'rgba(56, 189, 248, 0.14)';
      ctx.lineWidth = 1.5;
      const x = Math.min(this.dragBox.startX, this.dragBox.currX);
      const y = Math.min(this.dragBox.startY, this.dragBox.currY);
      const w = Math.abs(this.dragBox.currX - this.dragBox.startX);
      const h = Math.abs(this.dragBox.currY - this.dragBox.startY);
      ctx.fillRect(x, y, w, h);
      ctx.strokeRect(x, y, w, h);
      ctx.restore();
    }
  }

  renderInteractiveOcean(ctx, mapCells, ts, nowPerfMs) {
    const worldPx = mapCells * ts;
    ctx.fillStyle = '#06131f';
    ctx.fillRect(0, 0, worldPx, worldPx);

    const startGx = Math.max(0, Math.floor(this.camera.x / ts) - 1);
    const endGx = Math.min(mapCells, Math.ceil((this.camera.x + this.canvas.width / this.camera.zoom) / ts) + 1);
    const startGy = Math.max(0, Math.floor(this.camera.y / ts) - 1);
    const endGy = Math.min(mapCells, Math.ceil((this.camera.y + this.canvas.height / this.camera.zoom) / ts) + 1);

    const t = nowPerfMs * 0.0012;

    for (let gy = startGy; gy < endGy; gy++) {
      for (let gx = startGx; gx < endGx; gx++) {
        const px = gx * ts;
        const py = gy * ts;

        // Quantized procedural wave bands
        const waveVal =
          Math.sin(gx * 0.35 + t) * 0.5 +
          Math.cos(gy * 0.28 - t * 0.8) * 0.5 +
          Math.sin((gx + gy) * 0.2 + t * 0.6) * 0.3;

        if (waveVal > 0.55) {
          ctx.fillStyle = '#0c273c';
          ctx.fillRect(px, py, ts, ts);
          if (waveVal > 0.85 && this.graphicsQuality === 'high') {
            ctx.fillStyle = 'rgba(148, 210, 232, 0.16)';
            ctx.fillRect(px + 6, py + 14, 14, 3);
          }
        } else if (waveVal > -0.15) {
          ctx.fillStyle = '#081c2c';
          ctx.fillRect(px, py, ts, ts);
        }

        // Subtle tactical grid lines
        ctx.strokeStyle = 'rgba(56, 189, 248, 0.04)';
        ctx.lineWidth = 1;
        ctx.strokeRect(px, py, ts, ts);
      }
    }
  }

  renderTerrainAndNodes(ctx, view, ts, nowPerfMs) {
    const mapCells = view.match.mapCells;
    const cells = view.terrainCells;
    if (!cells) return;

    const startGx = Math.max(0, Math.floor(this.camera.x / ts) - 1);
    const endGx = Math.min(mapCells, Math.ceil((this.camera.x + this.canvas.width / this.camera.zoom) / ts) + 1);
    const startGy = Math.max(0, Math.floor(this.camera.y / ts) - 1);
    const endGy = Math.min(mapCells, Math.ceil((this.camera.y + this.canvas.height / this.camera.zoom) / ts) + 1);

    for (let gy = startGy; gy < endGy; gy++) {
      for (let gx = startGx; gx < endGx; gx++) {
        const t = cells[gy * mapCells + gx];
        const px = gx * ts;
        const py = gy * ts;

        if (t === TERRAIN_TYPES.SHALLOW_WATER) {
          ctx.fillStyle = 'rgba(20, 83, 116, 0.42)';
          ctx.fillRect(px, py, ts, ts);
        } else if (t === TERRAIN_TYPES.RUINED_PILLAR) {
          // Shoreline foam pulse
          const foam = 2 + Math.sin(nowPerfMs * 0.004 + gx + gy) * 1.5;
          ctx.fillStyle = 'rgba(186, 230, 253, 0.28)';
          ctx.fillRect(px - foam, py - foam, ts + foam * 2, ts + foam * 2);
          // Extruded concrete & rusted iron pillar
          ctx.fillStyle = '#1e293b';
          ctx.fillRect(px + 2, py + 2, ts - 4, ts - 4);
          ctx.fillStyle = '#334155';
          ctx.fillRect(px + 4, py + 4, ts - 8, ts - 12);
          ctx.fillStyle = '#7c2d12';
          ctx.fillRect(px + 8, py + 8, 10, 8);
        } else if (t === TERRAIN_TYPES.WRECKAGE_SHOAL) {
          ctx.fillStyle = 'rgba(186, 230, 253, 0.22)';
          ctx.fillRect(px + 2, py + 2, ts - 4, ts - 4);
          ctx.fillStyle = '#451a03';
          ctx.fillRect(px + 6, py + 8, ts - 12, ts - 16);
          ctx.fillStyle = '#9a3412';
          ctx.fillRect(px + 10, py + 12, ts - 20, 8);
        }
      }
    }

    // Salvage Resource Nodes
    for (const nd of view.resourceNodes) {
      if (nd.remaining <= 0) continue;
      const px = nd.gridX * ts;
      const py = nd.gridY * ts;
      const pulse = 0.7 + 0.3 * Math.sin(nowPerfMs * 0.005 + nd.gridX);

      ctx.strokeStyle = nd.isContested ? `rgba(249, 115, 22, ${pulse})` : `rgba(234, 179, 8, ${pulse})`;
      ctx.lineWidth = 2;
      ctx.strokeRect(px + 3, py + 3, ts - 6, ts - 6);

      ctx.fillStyle = '#422006';
      ctx.fillRect(px + 7, py + 7, ts - 14, ts - 14);
      ctx.fillStyle = nd.isContested ? '#f97316' : '#eab308';
      ctx.fillRect(px + 11, py + 11, 8, 8);
      ctx.fillRect(px + 21, py + 19, 7, 7);

      ctx.fillStyle = '#fef08a';
      ctx.font = 'bold 9px monospace';
      ctx.textAlign = 'center';
      ctx.fillText(`${Math.round(nd.remaining)}`, px + ts / 2, py + ts - 2);
    }
  }

  processWorldEvents(events = []) {
    const ts = GAME_CONSTANTS.TILE_SIZE;
    for (const evt of events) {
      if (this.processedEventIds.has(evt.eventId)) continue;
      this.processedEventIds.add(evt.eventId);

      const wx = evt.x * ts;
      const wy = evt.y * ts;

      if (evt.eventType === 'muzzle') {
        this.audio?.playCannonFire();
        for (let i = 0; i < 6; i++) {
          this.particles.push({
            x: wx,
            y: wy,
            vx: (Math.random() - 0.5) * 65,
            vy: (Math.random() - 0.5) * 65,
            size: 3 + Math.random() * 3,
            alpha: 1,
            color: '#f97316',
            life: 0,
            maxLife: 0.25,
          });
        }
      } else if (evt.eventType === 'impact') {
        this.ripples.push({
          x: wx,
          y: wy,
          radius: 3,
          maxRadius: 22,
          alpha: 0.85,
          color: '#fb923c',
        });
        for (let i = 0; i < 8; i++) {
          this.particles.push({
            x: wx,
            y: wy,
            vx: (Math.random() - 0.5) * 90,
            vy: (Math.random() - 0.5) * 90,
            size: 2.5,
            alpha: 1,
            color: '#fef08a',
            life: 0,
            maxLife: 0.35,
          });
        }
      } else if (evt.eventType === 'explosion') {
        this.audio?.playExplosion();
        this.ripples.push({
          x: wx,
          y: wy,
          radius: 5,
          maxRadius: 46,
          alpha: 0.95,
          color: '#ef4444',
        });
        for (let i = 0; i < 18; i++) {
          this.particles.push({
            x: wx,
            y: wy,
            vx: (Math.random() - 0.5) * 130,
            vy: (Math.random() - 0.5) * 130,
            size: 4 + Math.random() * 4,
            alpha: 1,
            color: i % 2 === 0 ? '#ef4444' : '#f59e0b',
            life: 0,
            maxLife: 0.6,
          });
        }
      } else if (evt.eventType === 'splash') {
        this.ripples.push({
          x: wx,
          y: wy,
          radius: 2,
          maxRadius: 20,
          alpha: 0.7,
          color: '#bae6fd',
        });
      }
    }
  }

  updateAndRenderWaterDisturbances(ctx, dtSec) {
    // Update & render ship wakes
    for (let i = this.wakes.length - 1; i >= 0; i--) {
      const w = this.wakes[i];
      w.radius += 14 * dtSec;
      w.alpha -= 0.55 * dtSec;
      if (w.alpha <= 0) {
        this.wakes.splice(i, 1);
        continue;
      }
      ctx.strokeStyle = `rgba(186, 230, 253, ${w.alpha * 0.45})`;
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.arc(w.x, w.y, w.radius, 0, Math.PI * 2);
      ctx.stroke();
    }

    // Update & render impact/order ripples
    for (let i = this.ripples.length - 1; i >= 0; i--) {
      const r = this.ripples[i];
      r.radius += 42 * dtSec;
      r.alpha -= 1.1 * dtSec;
      if (r.alpha <= 0 || r.radius >= r.maxRadius) {
        this.ripples.splice(i, 1);
        continue;
      }
      ctx.save();
      ctx.globalAlpha = Math.max(0, r.alpha);
      ctx.strokeStyle = r.color;
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(r.x, r.y, r.radius, 0, Math.PI * 2);
      ctx.stroke();
      ctx.restore();
    }
  }

  renderStructures(ctx, view, ts, nowPerfMs) {
    const surfaceList = view.structures.filter((s) => s.channel === 'surface');
    const superList = view.structures.filter((s) => s.channel === 'superstructure');
    const ordered = [...surfaceList, ...superList];

    for (const st of ordered) {
      const palette = FACTION_PALETTES[st.factionId % FACTION_PALETTES.length];
      const px = st.gridX * ts;
      const py = st.gridY * ts;
      const w = st.width * ts;
      const h = st.height * ts;

      // Contact sea foam along platform boundaries
      if (st.channel === 'surface') {
        const foam = 1.5 + Math.sin(nowPerfMs * 0.004 + st.gridX) * 1.0;
        ctx.fillStyle = 'rgba(186, 230, 253, 0.22)';
        ctx.fillRect(px - foam, py - foam, w + foam * 2, h + foam * 2);
      }

      const sprite = this.assets.getStructureCanvas(st.structureType, palette.primary, st.isConnected, st.isComplete);
      ctx.drawImage(sprite, px, py);

      // Draw rotating cannon turret barrel on top of cannon pedestal
      if (st.structureType === 'cannon') {
        ctx.save();
        ctx.translate(px + w / 2, py + h / 2);
        ctx.rotate((st.turretAngleDeg * Math.PI) / 180);
        ctx.fillStyle = '#0f172a';
        ctx.fillRect(-5, -5, 10, 10);
        ctx.fillStyle = '#94a3b8';
        ctx.fillRect(0, -3, 16, 6);
        ctx.restore();
      }

      // Disconnected warning badge
      if (!st.isConnected) {
        ctx.fillStyle = 'rgba(239, 68, 68, 0.88)';
        ctx.font = 'bold 10px monospace';
        ctx.textAlign = 'center';
        ctx.fillText('OFFLINE', px + w / 2, py + h / 2 + 3);
      }

      // Construction progress bar
      if (!st.isComplete) {
        const prog = Math.min(1, Math.max(0, (view.nowMs - st.builtAtMs) / Math.max(1, st.completesAtMs - st.builtAtMs)));
        ctx.fillStyle = '#0f172a';
        ctx.fillRect(px + 4, py + h - 8, w - 8, 5);
        ctx.fillStyle = '#eab308';
        ctx.fillRect(px + 4, py + h - 8, (w - 8) * prog, 5);
      } else if (st.hp < st.maxHp) {
        // Health bar
        const hpRatio = Math.max(0, st.hp / st.maxHp);
        ctx.fillStyle = '#0f172a';
        ctx.fillRect(px + 4, py - 6, w - 8, 4);
        ctx.fillStyle = hpRatio > 0.5 ? '#22c55e' : '#ef4444';
        ctx.fillRect(px + 4, py - 6, (w - 8) * hpRatio, 4);
      }

      // Selection highlight
      if (this.selectedIds.has(st.structureId)) {
        ctx.strokeStyle = '#38bdf8';
        ctx.lineWidth = 2;
        ctx.strokeRect(px - 1, py - 1, w + 2, h + 2);
      }
    }
  }

  renderShips(ctx, view, dtSec, ts, nowPerfMs) {
    for (const sh of view.ships) {
      const palette = FACTION_PALETTES[sh.factionId % FACTION_PALETTES.length];
      let vis = this.shipVisualCache.get(sh.shipId);
      if (!vis) {
        vis = {
          x: sh.x,
          y: sh.y,
          hullAngleDeg: sh.hullAngleDeg,
          turretAngleDeg: sh.turretAngleDeg,
          lastWakeMs: 0,
        };
        this.shipVisualCache.set(sh.shipId, vis);
      } else {
        // Smooth client interpolation toward authoritative position
        const lerp = Math.min(1, dtSec * 12);
        vis.x += (sh.x - vis.x) * lerp;
        vis.y += (sh.y - vis.y) * lerp;
        vis.hullAngleDeg = sh.hullAngleDeg;
        vis.turretAngleDeg = sh.turretAngleDeg;
      }

      const px = vis.x * ts;
      const py = vis.y * ts;

      // Spawn evolving water wake when moving
      const speed = Math.hypot(sh.vx, sh.vy);
      if (speed > 0.2 && nowPerfMs - vis.lastWakeMs > 120) {
        vis.lastWakeMs = nowPerfMs;
        this.wakes.push({
          x: px,
          y: py,
          radius: 5,
          alpha: 0.75,
        });
      }

      // Selection ring & move order indicator
      if (this.selectedIds.has(sh.shipId)) {
        ctx.strokeStyle = '#38bdf8';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.arc(px, py, 19, 0, Math.PI * 2);
        ctx.stroke();

        if (sh.factionId === view.callerSlotIndex && sh.orderType !== 'idle' && sh.orderType !== 'stop') {
          ctx.save();
          ctx.strokeStyle = sh.orderType === 'attack_target' ? 'rgba(239,68,68,0.45)' : 'rgba(56,189,248,0.35)';
          ctx.setLineDash([4, 4]);
          ctx.beginPath();
          ctx.moveTo(px, py);
          ctx.lineTo(sh.targetX * ts, sh.targetY * ts);
          ctx.stroke();
          ctx.restore();
        }
      }

      // Draw 90-degree overhead ship hull
      ctx.save();
      ctx.translate(px, py);
      ctx.rotate((vis.hullAngleDeg * Math.PI) / 180);

      if (sh.shipType === 'scout') {
        ctx.fillStyle = '#1e293b';
        ctx.fillRect(-12, -7, 24, 14);
        ctx.fillStyle = palette.primary;
        ctx.fillRect(-8, -5, 18, 10);
      } else if (sh.shipType === 'gunboat') {
        ctx.fillStyle = '#0f172a';
        ctx.fillRect(-16, -10, 32, 20);
        ctx.fillStyle = '#475569';
        ctx.fillRect(-14, -8, 28, 16);
        ctx.fillStyle = palette.primary;
        ctx.fillRect(-10, -5, 20, 10);
      } else {
        // Dreadnought Siege Monitor
        ctx.fillStyle = '#090d16';
        ctx.fillRect(-21, -13, 42, 26);
        ctx.fillStyle = '#334155';
        ctx.fillRect(-18, -11, 36, 22);
        ctx.fillStyle = palette.primary;
        ctx.fillRect(-12, -7, 24, 14);
      }
      ctx.restore();

      // Draw independently rotating weapon turret
      ctx.save();
      ctx.translate(px, py);
      ctx.rotate((vis.turretAngleDeg * Math.PI) / 180);
      ctx.fillStyle = '#0f172a';
      ctx.fillRect(-5, -5, 10, 10);
      ctx.fillStyle = '#e2e8f0';
      const barrelLen = sh.shipType === 'siege' ? 18 : sh.shipType === 'gunboat' ? 14 : 10;
      ctx.fillRect(0, -2.5, barrelLen, 5);
      ctx.restore();

      // Ship Health Bar
      if (sh.hp < sh.maxHp || this.selectedIds.has(sh.shipId)) {
        const hpRatio = Math.max(0, sh.hp / sh.maxHp);
        ctx.fillStyle = '#0f172a';
        ctx.fillRect(px - 14, py - 20, 28, 4);
        ctx.fillStyle = hpRatio > 0.5 ? '#22c55e' : '#ef4444';
        ctx.fillRect(px - 14, py - 20, 28 * hpRatio, 4);
      }
    }
  }

  renderProjectilesAndParticles(ctx, view, dtSec, ts) {
    for (const proj of view.projectiles) {
      const totalDur = Math.max(1, proj.impactAtMs - proj.spawnedAtMs);
      const t = Math.min(1, Math.max(0, (view.nowMs - proj.spawnedAtMs) / totalDur));
      const cx = (proj.startX + (proj.targetX - proj.startX) * t) * ts;
      const cy = (proj.startY + (proj.targetY - proj.startY) * t) * ts;

      ctx.fillStyle = '#fef08a';
      ctx.beginPath();
      ctx.arc(cx, cy, 3.5, 0, Math.PI * 2);
      ctx.fill();
    }

    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i];
      p.life += dtSec;
      if (p.life >= p.maxLife) {
        this.particles.splice(i, 1);
        continue;
      }
      p.x += p.vx * dtSec;
      p.y += p.vy * dtSec;
      ctx.fillStyle = p.color;
      ctx.globalAlpha = Math.max(0, 1 - p.life / p.maxLife);
      ctx.fillRect(p.x - p.size / 2, p.y - p.size / 2, p.size, p.size);
      ctx.globalAlpha = 1;
    }
  }

  renderBuildPreview(ctx, view, ts) {
    const def = STRUCTURE_DEFS[this.buildMode.structureType];
    if (!def) return;
    const gx = this.hoverCell.gx;
    const gy = this.hoverCell.gy;
    if (gx < 0 || gy < 0) return;

    const px = gx * ts;
    const py = gy * ts;
    const w = def.width * ts;
    const h = def.height * ts;

    const isValid = this.buildMode.isValid !== false;
    ctx.fillStyle = isValid ? 'rgba(34, 197, 94, 0.28)' : 'rgba(239, 68, 68, 0.35)';
    ctx.strokeStyle = isValid ? '#22c55e' : '#ef4444';
    ctx.lineWidth = 2;
    ctx.fillRect(px, py, w, h);
    ctx.strokeRect(px, py, w, h);
  }

  renderFogOfWar(ctx, view, mapCells, ts) {
    const startGx = Math.max(0, Math.floor(this.camera.x / ts) - 1);
    const endGx = Math.min(mapCells, Math.ceil((this.camera.x + this.canvas.width / this.camera.zoom) / ts) + 1);
    const startGy = Math.max(0, Math.floor(this.camera.y / ts) - 1);
    const endGy = Math.min(mapCells, Math.ceil((this.camera.y + this.canvas.height / this.camera.zoom) / ts) + 1);

    ctx.fillStyle = 'rgba(2, 6, 14, 0.64)';
    for (let gy = startGy; gy < endGy; gy++) {
      for (let gx = startGx; gx < endGx; gx++) {
        const cx = gx + 0.5;
        const cy = gy + 0.5;
        let visible = false;
        for (const src of view.visionSources) {
          if (Math.hypot(cx - src.x, cy - src.y) <= src.r) {
            visible = true;
            break;
          }
        }
        if (!visible) {
          ctx.fillRect(gx * ts, gy * ts, ts, ts);
        }
      }
    }
  }

  renderAtmosphericRain(ctx, width, height, dtSec) {
    ctx.strokeStyle = 'rgba(186, 230, 253, 0.14)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    for (const drop of this.rainDrops) {
      drop.x -= drop.speed * 0.25 * dtSec;
      drop.y += drop.speed * dtSec;
      if (drop.y > height) {
        drop.y = -20;
        drop.x = Math.random() * (width + 200);
      }
      ctx.moveTo(drop.x, drop.y);
      ctx.lineTo(drop.x - drop.len * 0.25, drop.y + drop.len);
    }
    ctx.stroke();
  }

  destroy() {
    this.canvas.removeEventListener('mousedown', this.onMouseDown);
    window.removeEventListener('mousemove', this.onMouseMove);
    window.removeEventListener('mouseup', this.onMouseUp);
    this.canvas.removeEventListener('wheel', this.onWheel);
    this.canvas.removeEventListener('contextmenu', this.onContextMenu);
  }
}
