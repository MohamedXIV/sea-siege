# SEA SIEGE — Drowned Industrial Naval RTS

**SEA SIEGE** is a multiplayer top-down real-time strategy, territorial base-building, and naval warfare game set in a flooded industrial dystopia. It combines a **SpacetimeDB-native authoritative backend** with a **Phaser 4 / 2D overhead interactive ocean renderer** and a customized **React + Tailwind CSS + shadcn/ui-styled tactical interface**.

---

## 1. Architecture & System Overview

### Core Design Pillars Implemented
1. **Build Your Territory (Multi-Layer Spatial Occupancy & Connectivity)**:
   - Players expand outward from their **3×3 Command Core** by placing **1×1 Floating Platforms** (`surface` channel) on navigable water.
   - Heavy industrial superstructures (**2×2 Naval Shipyard**, **2×2 Industrial Workshop**, **2×2 Salvage Extractor**, and **1×1 Defensive Cannon**) occupy the `superstructure` channel on top of completed, connected platforms without overwriting the platform record underneath.
   - **Authoritative Structural Dependency & Connectivity**: Destroying a supporting platform immediately collapses any superstructure mounted above its footprint and runs an orthogonal BFS connectivity check from the Command Core. Disconnected structures lose operational power (`isConnected = false`) until reconnected.
2. **Control the Sea & Salvage Economy**:
   - Deterministic seeded world generation (`src/shared/worldgen.ts`) creates radially balanced spawn anchors for 2–8 factions, local expansion salvage deposits, central high-yield contested salvage basins, and drowned industrial chokepoints.
   - **Salvage** is gathered via passive Command Core output, **Salvage Extractors** built near deposits, active dredging by **Scout Hydrofoils** and **Ironclad Gunboats**, and combat kill bounties.
3. **Expand Your Fleet & Independent Turret Combat**:
   - **Scout Hydrofoil** (fast recon & salvage harvester), **Ironclad Gunboat** (mainline armored fleet combatant), and **Dreadnought Siege Monitor** (long-range splash fortification breaker).
   - Ship hull heading (`hullAngleDeg`) and weapon turret aim (`turretAngleDeg`) rotate independently. Projectiles travel deterministically and deal server-authoritative hull/structure damage with armor reduction.
4. **First-Class Server-Owned AI Bots**:
   - Bots (`BotBrainTable`, private server-only table) execute on configurable strategic intervals (`Cadet`, `Commander`, `Admiral`) using the exact same placement, salvage affordability, production queue, and order rules as human players.
5. **Server-Side Fog of War & Security**:
   - Clients subscribe to authorized projections (`getAuthorizedMatchView`) that filter out unseen enemy ships/structures outside the faction's vision radius and redact secret enemy move orders, production queues, and private bot brain state.

---

## 2. Project Structure

```text
sea-siege/
├── spacetimedb/
│   └── src/
│       └── index.ts                   # SpacetimeDB server module schema & tables
├── src/
│   ├── shared/
│   │   ├── balance.ts                 # Data-driven unit, building, economy & preset configs
│   │   └── worldgen.ts                # Deterministic seeded map & chunk generator
│   ├── backend/
│   │   └── spacetimedb-authority.ts   # Authoritative reducers, simulation tick, AI bots & FoW view
│   ├── spacetimedb-bindings/
│   │   └── index.ts                   # Generated TypeScript client SDK adapter & reconnect handler
│   ├── game/
│   │   ├── assets.ts                  # Procedural pixel-art ship/structure sprite generator
│   │   ├── audio.ts                   # Synthesized Web Audio sound & ocean ambience engine
│   │   └── scene.ts                   # 90-deg overhead interactive ocean & battlefield renderer
│   └── App.tsx                        # React + Tailwind + shadcn-style menus, lobbies & RTS HUD
├── tests/
│   └── sea-siege.test.mjs             # Automated Gameplay, Security, Determinism & 15-step E2E tests
├── .env.example                       # Environment variable configuration
└── package.json                       # Scripts for Vite dev/build, tests, and SpacetimeDB CLI
```

---

## 3. Setup, Development & SpacetimeDB Execution Instructions

### Environment Variables (`.env.example`)
```ini
VITE_SPACETIMEDB_URI=ws://localhost:3000
VITE_SPACETIMEDB_MODULE=sea-siege
```

### Running Automated Verification Tests
```bash
npm test
# or directly:
node tests/sea-siege.test.mjs
```

### Running with Local SpacetimeDB CLI & Vite
1. Install dependencies:
   ```bash
   npm install
   ```
2. Start a local SpacetimeDB instance and publish the module:
   ```bash
   spacetime start
   npm run spacetime:publish
   npm run spacetime:generate
   ```
3. Launch the development server:
   ```bash
   npm run dev
   ```
4. Build for production:
   ```bash
   npm run build
   ```

> **Note on Sandbox Environment**: When running inside a browser sandbox or Canvas preview without a local `spacetime` daemon on port 3000, `DbConnection` in `src/spacetimedb-bindings/index.ts` automatically binds to the embedded `SpacetimeAuthorityServer` instance so all authoritative reducers, multi-client seat switching, late-join bot takeovers, disconnects/reconnects, and AI bots execute identically in-browser.
