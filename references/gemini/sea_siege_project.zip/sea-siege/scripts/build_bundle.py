#!/usr/bin/env python3
"""
Builds the complete self-contained playable SEA SIEGE HTML application
by embedding the shared balance, worldgen, SpacetimeDB authority engine,
client bindings, audio engine, pixel asset generator, interactive ocean
battlefield renderer, and full UI/HUD controller into a single standalone
HTML file, and also updates src/App.tsx with the complete UI implementation.
"""

import os
import re

BASE_DIR = "/working_dir/c_88d7db860444227b/artifacts/file_generation/ttl=63d/intermediate/sea-siege"
OUT_INTERMEDIATE = "/working_dir/c_88d7db860444227b/artifacts/file_generation/ttl=63d/intermediate/sea_siege.html"
OUT_FINAL = "/working_dir/c_88d7db860444227b/artifacts/file_generation/ttl=63d/output/sea_siege.html"

def strip_esm(code: str) -> str:
    # Remove import statements
    code = re.sub(r'^\s*import\s+[\s\S]*?from\s+[\'"][^\'"]+[\'"];?\s*$', '', code, flags=re.MULTILINE)
    # Replace export const / export function / export class / export default
    code = re.sub(r'^\s*export\s+default\s+', '', code, flags=re.MULTILINE)
    code = re.sub(r'^\s*export\s+(const|let|var|function|class)\s+', r'\1 ', code, flags=re.MULTILINE)
    code = re.sub(r'^\s*export\s*\{[\s\S]*?\};?\s*$', '', code, flags=re.MULTILINE)
    return code.strip()

balance_js = strip_esm(open(f"{BASE_DIR}/src/shared/balance.ts").read())
worldgen_js = strip_esm(open(f"{BASE_DIR}/src/shared/worldgen.ts").read())
authority_js = strip_esm(open(f"{BASE_DIR}/src/backend/spacetimedb-authority.ts").read())
bindings_js = strip_esm(open(f"{BASE_DIR}/src/spacetimedb-bindings/index.ts").read())
audio_js = strip_esm(open(f"{BASE_DIR}/src/game/audio.ts").read())
assets_js = strip_esm(open(f"{BASE_DIR}/src/game/assets.ts").read())
scene_js = strip_esm(open(f"{BASE_DIR}/src/game/scene.ts").read())

html_template = f"""<!DOCTYPE html>
<html lang="en" class="dark">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
  <title>SEA SIEGE — Drowned Industrial Naval RTS (SpacetimeDB + Phaser 4 Architecture)</title>
  <script src="https://cdn.tailwindcss.com/3.4.17"></script>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=JetBrains+Mono:wght@400;600;700&display=swap" rel="stylesheet">
  <style>
    * {{ box-sizing: border-box; user-select: none; -webkit-user-select: none; }}
    body, html {{
      margin: 0; padding: 0; width: 100%; height: 100%;
      background-color: #040d17; color: #e2e8f0;
      font-family: 'Inter', system-ui, sans-serif;
      overflow: hidden;
    }}
    .font-mono-tech {{ font-family: 'JetBrains Mono', monospace; }}
    .industrial-panel {{
      background: linear-gradient(180deg, rgba(15, 23, 42, 0.95) 0%, rgba(7, 13, 25, 0.98) 100%);
      border: 1px solid rgba(56, 189, 248, 0.25);
      box-shadow: 0 10px 30px -5px rgba(0, 0, 0, 0.7), inset 0 1px 0 0 rgba(148, 163, 184, 0.12);
    }}
    .industrial-btn {{
      background: linear-gradient(180deg, #1e293b 0%, #0f172a 100%);
      border: 1px solid rgba(148, 163, 184, 0.28);
      transition: all 0.15s ease;
    }}
    .industrial-btn:hover:not(:disabled) {{
      border-color: #38bdf8;
      background: linear-gradient(180deg, #1e3a5f 0%, #0f172a 100%);
      transform: translateY(-1px);
    }}
    .industrial-btn:active:not(:disabled) {{
      transform: translateY(0px);
    }}
    .industrial-btn-primary {{
      background: linear-gradient(180deg, #0284c7 0%, #0369a1 100%);
      border: 1px solid #38bdf8;
      color: #f8fafc;
      transition: all 0.15s ease;
    }}
    .industrial-btn-primary:hover:not(:disabled) {{
      background: linear-gradient(180deg, #0ea5e9 0%, #0284c7 100%);
      box-shadow: 0 0 15px rgba(56, 189, 248, 0.35);
    }}
    .industrial-btn-amber {{
      background: linear-gradient(180deg, #d97706 0%, #b45309 100%);
      border: 1px solid #fbbf24;
      color: #fef3c7;
      transition: all 0.15s ease;
    }}
    .industrial-btn-amber:hover:not(:disabled) {{
      background: linear-gradient(180deg, #f59e0b 0%, #d97706 100%);
      box-shadow: 0 0 15px rgba(245, 158, 11, 0.35);
    }}
    ::-webkit-scrollbar {{ width: 6px; height: 6px; }}
    ::-webkit-scrollbar-track {{ background: #090d16; }}
    ::-webkit-scrollbar-thumb {{ background: #334155; border-radius: 3px; }}
  </style>
</head>
<body class="w-full h-full relative overflow-hidden">

  <!-- AMBIENT OCEAN BACKGROUND CANVAS FOR MENUS -->
  <canvas id="menuBgCanvas" class="fixed inset-0 w-full h-full pointer-events-none z-0"></canvas>

  <!-- ACTIVE BATTLEFIELD GAMEPLAY CANVAS -->
  <canvas id="battlefieldCanvas" class="fixed inset-0 w-full h-full z-10 hidden"></canvas>

  <!-- TOAST NOTIFICATION BANNER -->
  <div id="toastBanner" class="fixed top-16 left-1/2 -translate-x-1/2 z-50 hidden px-4 py-2 rounded border text-xs font-mono-tech tracking-wide shadow-lg transition-all"></div>

  <!-- ==================================================================== -->
  <!-- SCREEN 1: MAIN MENU                                                  -->
  <!-- ==================================================================== -->
  <section id="screenMainMenu" class="relative z-20 w-full h-full flex flex-col justify-between p-4 md:p-8 overflow-y-auto">
    <div class="flex items-center justify-between border-b border-sky-500/20 pb-3">
      <div class="flex items-center gap-3">
        <div class="w-3 h-3 rounded-full bg-emerald-400 animate-pulse"></div>
        <span class="font-mono-tech text-xs text-sky-300 tracking-wider uppercase">SpacetimeDB Authority Engine // Online</span>
      </div>
      <div class="flex items-center gap-2 text-xs font-mono-tech text-slate-400">
        <span>Client Identity:</span>
        <span id="menuIdentityBadge" class="text-amber-400 bg-slate-900/90 px-2 py-0.5 rounded border border-amber-500/30">stdb_id_...</span>
      </div>
    </div>

    <div class="my-auto max-w-5xl w-full mx-auto grid grid-cols-1 lg:grid-cols-12 gap-6 items-center py-4">
      <!-- Title & Lore Column -->
      <div class="lg:col-span-7 space-y-4">
        <div class="inline-flex items-center gap-2 px-3 py-1 rounded bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs font-mono-tech uppercase tracking-widest">
          Drowned Industrial Naval Warfare
        </div>
        <h1 class="text-5xl md:text-6xl font-extrabold tracking-tight text-white leading-none">
          SEA <span class="text-sky-400">SIEGE</span>
        </h1>
        <p class="text-slate-300 text-sm md:text-base max-w-xl leading-relaxed">
          Command a fragile industrial citadel in a world swallowed by the abyss. Dredge submerged salvage, expand modular floating platforms, construct shipyards and rotary artillery, and shatter rival strongholds across a living reactive ocean.
        </p>

        <!-- Player Callsign Input -->
        <div class="industrial-panel p-3.5 rounded-lg max-w-md space-y-1.5">
          <label for="playerNameInput" class="block text-xs font-mono-tech uppercase text-sky-300">Commander Callsign</label>
          <div class="flex gap-2">
            <input id="playerNameInput" type="text" value="Commander Vance" maxlength="22"
              class="w-full bg-slate-950 border border-slate-700 focus:border-sky-400 rounded px-3 py-1.5 text-sm text-white outline-none font-mono-tech" />
          </div>
        </div>

        <!-- Feature Pills -->
        <div class="grid grid-cols-3 gap-2 max-w-lg pt-1 text-xs font-mono-tech text-slate-300">
          <div class="bg-slate-900/80 border border-slate-800 rounded p-2">
            <div class="text-sky-400 font-bold">2–8 Factions</div>
            <div class="text-[11px] text-slate-400">Human or Server AI</div>
          </div>
          <div class="bg-slate-900/80 border border-slate-800 rounded p-2">
            <div class="text-amber-400 font-bold">Multi-Layer Grid</div>
            <div class="text-[11px] text-slate-400">Platforms & Bridges</div>
          </div>
          <div class="bg-slate-900/80 border border-slate-800 rounded p-2">
            <div class="text-emerald-400 font-bold">Server FoW</div>
            <div class="text-[11px] text-slate-400">Authoritative Combat</div>
          </div>
        </div>
      </div>

      <!-- Command Navigation Menu Column -->
      <div class="lg:col-span-5 industrial-panel rounded-xl p-5 space-y-2.5">
        <div class="text-xs font-mono-tech uppercase tracking-wider text-slate-400 pb-1 border-b border-slate-800">
          Tactical Deployment Console
        </div>

        <button id="btnQuickPlay" class="w-full industrial-btn-primary py-3 px-4 rounded-lg font-bold text-sm flex items-center justify-between">
          <span>⚡ QUICK PLAY (INSTANT SKIRMISH)</span>
          <span class="font-mono-tech text-xs opacity-80">4P AUTO</span>
        </button>

        <button id="btnOpenCreateMatch" class="w-full industrial-btn py-2.5 px-4 rounded-lg font-semibold text-sm flex items-center justify-between text-slate-100">
          <span>🏗️ Create Private Match / Lobby</span>
          <span class="font-mono-tech text-xs text-sky-400">2–8 SLOTS</span>
        </button>

        <button id="btnOpenJoinMatch" class="w-full industrial-btn py-2.5 px-4 rounded-lg font-semibold text-sm flex items-center justify-between text-slate-100">
          <span>🔑 Join Private Match by Code</span>
          <span class="font-mono-tech text-xs text-amber-400">CODE / LATE-JOIN</span>
        </button>

        <button id="btnPlayVsBots" class="w-full industrial-btn-amber py-2.5 px-4 rounded-lg font-semibold text-sm flex items-center justify-between">
          <span>🤖 Play vs AI Bots (Custom Preset)</span>
          <span class="font-mono-tech text-xs">1v1 TO 1v7</span>
        </button>

        <div class="grid grid-cols-3 gap-2 pt-2">
          <button id="btnOpenHowToPlay" class="industrial-btn py-2 px-2 rounded text-xs font-mono-tech text-slate-300">
            📖 How to Play
          </button>
          <button id="btnOpenSettings" class="industrial-btn py-2 px-2 rounded text-xs font-mono-tech text-slate-300">
            ⚙️ Settings
          </button>
          <button id="btnOpenCredits" class="industrial-btn py-2 px-2 rounded text-xs font-mono-tech text-slate-300">
            🛡️ Architecture
          </button>
        </div>
      </div>
    </div>

    <div class="flex flex-wrap items-center justify-between text-xs font-mono-tech text-slate-500 border-t border-slate-800/80 pt-3">
      <span>SEA SIEGE v1.0 // Deterministic Seeded World & Multi-Layer Occupancy</span>
      <span>Controls: LMB Select/Build • RMB Move/Attack/Harvest • Scroll Zoom • WASD/Arrows Pan</span>
    </div>
  </section>

  <!-- ==================================================================== -->
  <!-- SCREEN 2: MATCH CONFIGURATION & BOT SETUP                            -->
  <!-- ==================================================================== -->
  <section id="screenMatchConfig" class="relative z-20 w-full h-full hidden items-center justify-center p-4 overflow-y-auto">
    <div class="industrial-panel rounded-xl max-w-2xl w-full p-6 space-y-5 my-auto">
      <div class="flex items-center justify-between border-b border-slate-800 pb-3">
        <div>
          <h2 class="text-xl font-bold text-white">Configure Naval Theater</h2>
          <p class="text-xs text-slate-400">Customize player capacity, server-owned AI bots, map seed, and visibility rules.</p>
        </div>
        <button id="btnBackFromConfig" class="industrial-btn px-3 py-1.5 rounded text-xs font-mono-tech">← Back</button>
      </div>

      <!-- Presets Row -->
      <div class="space-y-1.5">
        <label class="text-xs font-mono-tech uppercase text-sky-400">Theater Preset</label>
        <div class="grid grid-cols-4 gap-2">
          <button data-preset="Duel" class="preset-btn industrial-btn py-2 px-3 rounded text-center">
            <div class="font-bold text-sm text-white">Duel</div>
            <div class="text-[11px] font-mono-tech text-slate-400">2 Slots (56×56)</div>
          </button>
          <button data-preset="Skirmish" class="preset-btn industrial-btn py-2 px-3 rounded text-center border-sky-400">
            <div class="font-bold text-sm text-white">Skirmish</div>
            <div class="text-[11px] font-mono-tech text-slate-400">4 Slots (64×64)</div>
          </button>
          <button data-preset="Standard" class="preset-btn industrial-btn py-2 px-3 rounded text-center">
            <div class="font-bold text-sm text-white">Standard</div>
            <div class="text-[11px] font-mono-tech text-slate-400">6 Slots (72×72)</div>
          </button>
          <button data-preset="Large" class="preset-btn industrial-btn py-2 px-3 rounded text-center">
            <div class="font-bold text-sm text-white">Large</div>
            <div class="text-[11px] font-mono-tech text-slate-400">8 Slots (80×80)</div>
          </button>
        </div>
      </div>

      <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label for="cfgMaxSlots" class="block text-xs font-mono-tech uppercase text-slate-300 mb-1">Max Faction Slots (2–8)</label>
          <input id="cfgMaxSlots" type="number" min="2" max="8" value="4"
            class="w-full bg-slate-950 border border-slate-700 rounded px-3 py-2 text-sm font-mono-tech text-white" />
        </div>
        <div>
          <label for="cfgBotCount" class="block text-xs font-mono-tech uppercase text-slate-300 mb-1">Server AI Bot Count (0–7)</label>
          <input id="cfgBotCount" type="number" min="0" max="7" value="3"
            class="w-full bg-slate-950 border border-slate-700 rounded px-3 py-2 text-sm font-mono-tech text-white" />
        </div>
        <div>
          <label for="cfgBotDifficulty" class="block text-xs font-mono-tech uppercase text-slate-300 mb-1">AI Strategic Difficulty</label>
          <select id="cfgBotDifficulty" class="w-full bg-slate-950 border border-slate-700 rounded px-3 py-2 text-sm font-mono-tech text-white">
            <option value="Cadet">Cadet (Measured Expansion)</option>
            <option value="Commander" selected>Commander (Balanced Naval Combined Arms)</option>
            <option value="Admiral">Admiral (Aggressive Fleet Siege)</option>
          </select>
        </div>
        <div>
          <label for="cfgMapSeed" class="block text-xs font-mono-tech uppercase text-slate-300 mb-1">Deterministic World Seed</label>
          <div class="flex gap-2">
            <input id="cfgMapSeed" type="number" value="778899"
              class="w-full bg-slate-950 border border-slate-700 rounded px-3 py-2 text-sm font-mono-tech text-white" />
            <button id="btnRandomSeed" class="industrial-btn px-3 rounded text-xs font-mono-tech">🎲</button>
          </div>
        </div>
      </div>

      <div class="flex flex-wrap items-center gap-6 pt-1">
        <label class="inline-flex items-center gap-2 text-xs font-mono-tech text-slate-300 cursor-pointer">
          <input id="cfgFogOfWar" type="checkbox" checked class="accent-sky-400 w-4 h-4" />
          <span>Enforce Server-Side Fog of War</span>
        </label>
        <label class="inline-flex items-center gap-2 text-xs font-mono-tech text-slate-300 cursor-pointer">
          <input id="cfgBotOnlySpectate" type="checkbox" class="accent-amber-400 w-4 h-4" />
          <span>Bot-Only Simulation Mode (Spectate AI War)</span>
        </label>
      </div>

      <div class="flex flex-wrap justify-end gap-3 pt-3 border-t border-slate-800">
        <button id="btnOpenLobbyFromConfig" class="industrial-btn px-4 py-2.5 rounded-lg text-xs font-mono-tech uppercase tracking-wider text-sky-300">
          Create Private Lobby (Get Join Code)
        </button>
        <button id="btnLaunchImmediateFromConfig" class="industrial-btn-primary px-5 py-2.5 rounded-lg text-sm font-bold">
          🚀 Launch Match Immediately
        </button>
      </div>
    </div>
  </section>

  <!-- ==================================================================== -->
  <!-- SCREEN 3: JOIN PRIVATE MATCH BY CODE                                 -->
  <!-- ==================================================================== -->
  <section id="screenJoinMatch" class="relative z-20 w-full h-full hidden items-center justify-center p-4">
    <div class="industrial-panel rounded-xl max-w-md w-full p-6 space-y-4">
      <div class="flex items-center justify-between border-b border-slate-800 pb-3">
        <h2 class="text-lg font-bold text-white">Join Private Match</h2>
        <button id="btnBackFromJoin" class="industrial-btn px-3 py-1 rounded text-xs font-mono-tech">← Back</button>
      </div>
      <p class="text-xs text-slate-300 leading-relaxed">
        Enter a 6-character lobby join code. If the match is already underway, Late-Join will assign you to take over an active AI Bot faction or join as Spectator.
      </p>
      <div>
        <label for="joinCodeField" class="block text-xs font-mono-tech uppercase text-amber-400 mb-1">6-Character Join Code</label>
        <input id="joinCodeField" type="text" placeholder="E.G. K7M9P2" maxlength="8"
          class="w-full bg-slate-950 border border-slate-700 rounded px-3 py-2.5 text-center text-lg font-mono-tech tracking-widest uppercase text-white" />
      </div>
      <div id="activeLobbiesList" class="space-y-1.5 text-xs font-mono-tech text-slate-400"></div>
      <button id="btnSubmitJoinCode" class="w-full industrial-btn-primary py-2.5 rounded-lg font-bold text-sm">
        Connect to Match Authority
      </button>
    </div>
  </section>

  <!-- ==================================================================== -->
  <!-- SCREEN 4: MULTIPLAYER LOBBY                                          -->
  <!-- ==================================================================== -->
  <section id="screenLobby" class="relative z-20 w-full h-full hidden items-center justify-center p-4 overflow-y-auto">
    <div class="industrial-panel rounded-xl max-w-3xl w-full p-6 space-y-4 my-auto">
      <div class="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 pb-3">
        <div>
          <div class="text-xs font-mono-tech text-sky-400 uppercase">SpacetimeDB Synchronized Lobby</div>
          <h2 id="lobbyTitle" class="text-xl font-bold text-white">Theater Staging Area</h2>
        </div>
        <div class="flex items-center gap-3">
          <div class="bg-slate-950 border border-amber-500/40 px-3 py-1.5 rounded flex items-center gap-2">
            <span class="text-xs font-mono-tech text-slate-400">JOIN CODE:</span>
            <span id="lobbyJoinCodeDisplay" class="font-mono-tech font-bold text-amber-400 tracking-widest text-sm">------</span>
            <button id="btnCopyJoinCode" class="text-xs text-sky-400 hover:underline font-mono-tech ml-1">COPY</button>
          </div>
          <button id="btnLeaveLobby" class="industrial-btn px-3 py-1.5 rounded text-xs font-mono-tech text-rose-300">Leave</button>
        </div>
      </div>

      <div id="lobbySlotsContainer" class="grid grid-cols-1 md:grid-cols-2 gap-2.5"></div>

      <div class="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-slate-800">
        <div class="flex items-center gap-2">
          <button id="btnToggleReady" class="industrial-btn px-4 py-2 rounded text-xs font-mono-tech text-emerald-300">
            ✓ Toggle Ready Status
          </button>
          <button id="btnSimulateSecondHuman" class="industrial-btn px-3 py-2 rounded text-xs font-mono-tech text-sky-300" title="Spawns a second connected human client in this lobby to test multiplayer slot synchronization">
            + Connect 2nd Human Client
          </button>
        </div>
        <button id="btnStartMatchFromLobby" class="industrial-btn-primary px-6 py-2.5 rounded-lg font-bold text-sm">
          ⚔️ Start Authoritative Match
        </button>
      </div>
    </div>
  </section>

  <!-- ==================================================================== -->
  <!-- SCREEN 5: HOW TO PLAY / TACTICAL FIELD MANUAL                        -->
  <!-- ==================================================================== -->
  <section id="screenHowToPlay" class="relative z-20 w-full h-full hidden items-center justify-center p-4 overflow-y-auto">
    <div class="industrial-panel rounded-xl max-w-3xl w-full p-6 space-y-4 my-auto">
      <div class="flex items-center justify-between border-b border-slate-800 pb-3">
        <h2 class="text-xl font-bold text-white">SEA SIEGE — Tactical Field Manual</h2>
        <button id="btnCloseHowTo" class="industrial-btn px-3 py-1.5 rounded text-xs font-mono-tech">← Return</button>
      </div>
      <div class="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs leading-relaxed text-slate-300">
        <div class="bg-slate-900/70 border border-slate-800 p-3.5 rounded-lg space-y-1.5">
          <div class="font-mono-tech font-bold text-sky-400 uppercase">1. Floating Platforms & Territory</div>
          <p>Expand outward from your 3×3 <b>Command Core</b> by placing <b>Floating Platforms</b> (25 Salvage) orthogonally adjacent to existing connected platforms.</p>
          <p>Superstructures (<b>Shipyard</b>, <b>Workshop</b>, <b>Salvage Extractor</b>, <b>Defensive Cannon</b>) must be placed on top of completed, connected platforms. If an enemy destroys a bridge platform, isolated buildings go <b>OFFLINE</b>!</p>
        </div>
        <div class="bg-slate-900/70 border border-slate-800 p-3.5 rounded-lg space-y-1.5">
          <div class="font-mono-tech font-bold text-amber-400 uppercase">2. Salvage Economy</div>
          <p><b>Salvage</b> is the lifeblood of your industrial outpost. Gather it in three ways:</p>
          <ul class="list-disc pl-4 space-y-1">
            <li>Build <b>Salvage Extractors</b> near golden salvage deposits.</li>
            <li>Select <b>Scout Hydrofoils</b> or <b>Gunboats</b> and Right-Click a Salvage Deposit to dredge scrap directly.</li>
            <li>Destroy enemy warships and structures for combat salvage bounties.</li>
          </ul>
        </div>
        <div class="bg-slate-900/70 border border-slate-800 p-3.5 rounded-lg space-y-1.5">
          <div class="font-mono-tech font-bold text-emerald-400 uppercase">3. Fleet Production & Naval Combat</div>
          <p>Construct a 2×2 <b>Naval Shipyard</b> with at least one adjacent open water cell. Queue <b>Scout Hydrofoils</b> (fast recon), <b>Ironclad Gunboats</b> (brawlers), and <b>Dreadnought Siege Monitors</b> (long-range base breakers).</p>
          <p>Ship turrets rotate independently of the hull. Build an <b>Industrial Workshop</b> to passively repair nearby ships/structures and research Fleet Weapon Upgrades.</p>
        </div>
        <div class="bg-slate-900/70 border border-slate-800 p-3.5 rounded-lg space-y-1.5">
          <div class="font-mono-tech font-bold text-rose-400 uppercase">4. Controls & Victory Conditions</div>
          <ul class="list-disc pl-4 space-y-1">
            <li><b>Left-Click / Drag:</b> Select ship(s) or inspect structure.</li>
            <li><b>Right-Click Water:</b> Move selected fleet in formation.</li>
            <li><b>Right-Click Enemy:</b> Focus-fire target with turrets.</li>
            <li><b>Victory:</b> Destroy all rival <b>Command Cores</b> or lead the Sudden Death Tiebreaker score.</li>
          </ul>
        </div>
      </div>
    </div>
  </section>

  <!-- ==================================================================== -->
  <!-- SCREEN 6: SETTINGS                                                   -->
  <!-- ==================================================================== -->
  <section id="screenSettings" class="relative z-20 w-full h-full hidden items-center justify-center p-4">
    <div class="industrial-panel rounded-xl max-w-md w-full p-6 space-y-4">
      <div class="flex items-center justify-between border-b border-slate-800 pb-3">
        <h2 class="text-lg font-bold text-white">Audio & Graphics Settings</h2>
        <button id="btnCloseSettings" class="industrial-btn px-3 py-1 rounded text-xs font-mono-tech">← Return</button>
      </div>

      <div class="space-y-3 text-xs font-mono-tech">
        <label class="flex items-center justify-between cursor-pointer">
          <span>Mute All Audio</span>
          <input id="setMuteToggle" type="checkbox" class="accent-sky-400 w-4 h-4" />
        </label>
        <div>
          <div class="flex justify-between mb-1"><span>Effects Volume (Cannons / UI)</span><span id="sfxVolLabel">65%</span></div>
          <input id="setSfxSlider" type="range" min="0" max="100" value="65" class="w-full accent-sky-400" />
        </div>
        <div>
          <div class="flex justify-between mb-1"><span>Ocean & Storm Ambience</span><span id="musicVolLabel">35%</span></div>
          <input id="setMusicSlider" type="range" min="0" max="100" value="35" class="w-full accent-sky-400" />
        </div>
        <div class="pt-2 border-t border-slate-800">
          <label for="setGraphicsQuality" class="block mb-1">Ocean & Weather Shader Detail</label>
          <select id="setGraphicsQuality" class="w-full bg-slate-950 border border-slate-700 rounded px-3 py-2 text-white">
            <option value="high" selected>High (Quantized Wave Foam + Rain + Full Wakes)</option>
            <option value="low">Low / Performance (Reduced Particles & Rain Off)</option>
          </select>
        </div>
        <label class="flex items-center justify-between cursor-pointer pt-1">
          <span>Desktop Edge-Scrolling</span>
          <input id="setEdgeScroll" type="checkbox" class="accent-sky-400 w-4 h-4" />
        </label>
      </div>
    </div>
  </section>

  <!-- ==================================================================== -->
  <!-- SCREEN 7: CREDITS & SPACETIMEDB ARCHITECTURE                         -->
  <!-- ==================================================================== -->
  <section id="screenCredits" class="relative z-20 w-full h-full hidden items-center justify-center p-4">
    <div class="industrial-panel rounded-xl max-w-xl w-full p-6 space-y-4">
      <div class="flex items-center justify-between border-b border-slate-800 pb-3">
        <h2 class="text-lg font-bold text-white">SEA SIEGE — Architecture & Credits</h2>
        <button id="btnCloseCredits" class="industrial-btn px-3 py-1 rounded text-xs font-mono-tech">← Return</button>
      </div>
      <div class="space-y-2.5 text-xs text-slate-300 leading-relaxed">
        <p><b>SEA SIEGE</b> is engineered with an authoritative <b>SpacetimeDB</b> relational world model (`Match`, `MatchSlot`, `WorldChunk`, `ResourceNode`, `Structure`, `Ship`, `Projectile`, `WorldEvent`, `BotBrain`) and a 90-degree overhead naval presentation engine.</p>
        <p>All resource deductions, multi-layer footprints (`surface` + `superstructure`), platform bridge connectivity BFS, ship production timers, turret cooldowns, projectile hits, and server-side Fog of War projections execute atomically through server reducers.</p>
        <div class="bg-slate-950 border border-slate-800 p-3 rounded font-mono-tech text-[11px] text-sky-300">
          Stack: SpacetimeDB TypeScript Module & SDK • Phaser 4 / HTML5 2D Overhead Naval Renderer • Tailwind CSS • Synthesized Web Audio
        </div>
      </div>
    </div>
  </section>

  <!-- ==================================================================== -->
  <!-- SCREEN 8: ACTIVE MATCH TACTICAL HUD OVERLAY                          -->
  <!-- ==================================================================== -->
  <div id="hudOverlay" class="fixed inset-0 pointer-events-none z-30 hidden flex-col justify-between">
    <!-- TOP BAR: Faction Identity, Salvage Economy, Match Clock, Multiplayer Seat/Reconnect Controls -->
    <div class="pointer-events-auto industrial-panel border-t-0 border-x-0 px-3 py-2 flex flex-wrap items-center justify-between gap-2">
      <div class="flex items-center gap-3">
        <div id="hudFactionSwatch" class="w-3.5 h-3.5 rounded-sm border border-white/40 bg-sky-400"></div>
        <div>
          <div id="hudFactionName" class="text-xs font-bold text-white leading-none">Commander</div>
          <div id="hudMatchCode" class="text-[10px] font-mono-tech text-slate-400">CODE: ------</div>
        </div>

        <!-- SALVAGE COUNTER -->
        <div class="bg-slate-950 border border-amber-500/40 rounded px-3 py-1 flex items-center gap-2 ml-2">
          <span class="text-amber-400 font-mono-tech text-xs font-bold">⚙️ SALVAGE:</span>
          <span id="hudSalvageAmount" class="font-mono-tech font-extrabold text-amber-300 text-sm">420</span>
          <span id="hudSalvageRate" class="text-[10px] font-mono-tech text-emerald-400">(+4/s)</span>
        </div>

        <!-- FLEET & TERRITORY COUNTERS -->
        <div class="hidden sm:flex items-center gap-3 text-xs font-mono-tech text-slate-300 bg-slate-950/80 px-2.5 py-1 rounded border border-slate-800">
          <span>🚢 Fleet: <b id="hudShipCount" class="text-sky-300">2</b></span>
          <span>🏗️ Structs: <b id="hudStructCount" class="text-slate-100">7</b></span>
          <span>⬆️ Wpn Lvl: <b id="hudUpgradeLvl" class="text-amber-300">0</b></span>
        </div>
      </div>

      <!-- RIGHT TOP CONTROLS: Faction Standings, Multiplayer Inspector, Camera Center, Surrender/Menu -->
      <div class="flex items-center gap-1.5">
        <div id="hudClockBadge" class="font-mono-tech text-xs bg-slate-950 px-2.5 py-1 rounded border border-slate-800 text-slate-300">
          00:00
        </div>
        <button id="btnCenterBase" class="industrial-btn px-2.5 py-1 rounded text-xs font-mono-tech text-sky-300" title="Center Camera on Command Core (Space)">
          🎯 Home
        </button>
        <button id="btnToggleReconnectSim" class="industrial-btn px-2.5 py-1 rounded text-xs font-mono-tech text-emerald-300" title="Test SpacetimeDB Disconnect & Identity Reconnection">
          🔌 Connected
        </button>
        <button id="btnLateJoinSim" class="industrial-btn px-2.5 py-1 rounded text-xs font-mono-tech text-amber-300" title="Simulate a Late-Joining Player Taking Over an AI Bot Faction">
          👤 Late-Join Takeover
        </button>
        <button id="btnMuteHud" class="industrial-btn px-2 py-1 rounded text-xs font-mono-tech">
          🔊
        </button>
        <button id="btnSurrenderMatch" class="industrial-btn px-2.5 py-1 rounded text-xs font-mono-tech text-rose-400">
          🏳️ Surrender
        </button>
        <button id="btnExitToMenu" class="industrial-btn px-2.5 py-1 rounded text-xs font-mono-tech text-slate-300">
          ✕ Menu
        </button>
      </div>
    </div>

    <!-- MIDDLE FLOATING FACTION SCOREBOARD (TOP-RIGHT) -->
    <div class="flex justify-end px-3 mt-2 pointer-events-none">
      <div id="hudFactionList" class="pointer-events-auto industrial-panel rounded-lg p-2 space-y-1 w-52 text-[11px] font-mono-tech"></div>
    </div>

    <!-- BOTTOM TACTICAL DOCK: Minimap (Left) + Construction Menu (Center) + Selection/Queue Inspector (Right) -->
    <div class="mt-auto pointer-events-none p-2 md:p-3 grid grid-cols-1 lg:grid-cols-12 gap-2 items-end">
      <!-- MINIMAP PANEL -->
      <div class="lg:col-span-3 pointer-events-auto industrial-panel rounded-lg p-2 flex flex-col items-center">
        <div class="w-full flex justify-between items-center text-[10px] font-mono-tech text-slate-400 mb-1">
          <span>TACTICAL RADAR</span>
          <span id="hudCoordsLabel">X: 32 Y: 32</span>
        </div>
        <canvas id="minimapCanvas" width="168" height="168" class="border border-slate-700 rounded bg-slate-950 cursor-crosshair"></canvas>
      </div>

      <!-- CONSTRUCTION & TERRITORY EXPANSION CONSOLE -->
      <div class="lg:col-span-5 pointer-events-auto industrial-panel rounded-lg p-2.5 space-y-2">
        <div class="flex items-center justify-between border-b border-slate-800 pb-1">
          <span class="text-[11px] font-mono-tech uppercase text-sky-400 font-bold">Construction & Platform Expansion</span>
          <span id="buildModeStatus" class="text-[10px] font-mono-tech text-amber-300">Select structure to place</span>
        </div>
        <div class="grid grid-cols-5 gap-1.5" id="constructionButtonsGrid">
          <!-- Populated dynamically from STRUCTURE_DEFS -->
        </div>
      </div>

      <!-- SELECTED ENTITY / SHIPYARD PRODUCTION / FLEET ORDERS PANEL -->
      <div class="lg:col-span-4 pointer-events-auto industrial-panel rounded-lg p-2.5 min-h-[142px] flex flex-col justify-between">
        <div id="selectionPanelContent" class="space-y-2 text-xs">
          <!-- Populated dynamically based on selected ships/structures -->
        </div>
      </div>
    </div>
  </div>

  <!-- ==================================================================== -->
  <!-- MODAL: VICTORY / DEFEAT / MATCH RESULTS & REMATCH                    -->
  <!-- ==================================================================== -->
  <div id="victoryModal" class="fixed inset-0 bg-slate-950/85 backdrop-blur-sm z-40 hidden items-center justify-center p-4">
    <div class="industrial-panel rounded-xl max-w-2xl w-full p-6 space-y-4 border-2 border-sky-500/40">
      <div class="text-center space-y-1">
        <div id="victoryBadge" class="inline-block px-3 py-0.5 rounded font-mono-tech text-xs uppercase tracking-widest bg-amber-500/20 text-amber-300">
          Theater Concluded
        </div>
        <h2 id="victoryHeadline" class="text-3xl font-extrabold text-white">VICTORY</h2>
        <p id="victorySubtext" class="text-xs font-mono-tech text-slate-300"></p>
      </div>

      <div class="overflow-x-auto">
        <table class="w-full text-left border-collapse text-xs font-mono-tech">
          <thead>
            <tr class="border-b border-slate-800 text-slate-400">
              <th class="py-2 px-2">Faction</th>
              <th class="py-2 px-2">Status</th>
              <th class="py-2 px-2 text-right">Salvage Gathered</th>
              <th class="py-2 px-2 text-right">Structs Built</th>
              <th class="py-2 px-2 text-right">Ships Built</th>
              <th class="py-2 px-2 text-right">Kills</th>
            </tr>
          </thead>
          <tbody id="victoryScoreTableBody"></tbody>
        </table>
      </div>

      <div class="flex flex-wrap justify-between items-center gap-3 pt-3 border-t border-slate-800">
        <button id="btnSpectateAfterEnd" class="industrial-btn px-4 py-2 rounded text-xs font-mono-tech text-slate-300">
          👁️ Inspect Battlefield
        </button>
        <div class="flex gap-2">
          <button id="btnRematchSameSeed" class="industrial-btn px-4 py-2 rounded text-xs font-mono-tech text-amber-300">
            🔁 Replay Same Seed
          </button>
          <button id="btnNewRematch" class="industrial-btn-primary px-5 py-2 rounded font-bold text-xs font-mono-tech">
            ⚔️ New Rematch
          </button>
        </div>
      </div>
    </div>
  </div>

  <!-- ==================================================================== -->
  <!-- AUTHORITATIVE SPACETIMEDB + BATTLEFIELD ENGINE SCRIPT                -->
  <!-- ==================================================================== -->
  <script>
  (function() {{
    // --- 1. SHARED BALANCE & DEFINITIONS ---
    {balance_js}

    // --- 2. DETERMINISTIC SEEDED WORLD GENERATOR ---
    {worldgen_js}

    // --- 3. SPACETIMEDB AUTHORITATIVE SERVER ENGINE ---
    {authority_js}

    // --- 4. SPACETIMEDB CLIENT SDK BINDINGS ---
    {bindings_js}

    // --- 5. SYNTHESIZED WEB AUDIO ENGINE ---
    {audio_js}

    // --- 6. PROCEDURAL PIXEL-ART SPRITE GENERATOR ---
    {assets_js}

    // --- 7. INTERACTIVE OCEAN & BATTLEFIELD RENDERER ---
    {scene_js}

    // --- 8. APPLICATION CONTROLLER & UI BINDINGS ---
    const audio = new SeaSiegeAudioEngine();
    const clientConn = new DbConnection({{ serverInstance: sharedEmbeddedAuthority }});
    let secondaryClients = [];
    let currentScreen = 'menu';
    let currentMatchId = null;
    let latestView = null;
    let selectedEntityIds = [];
    let activeBuildType = null;
    let victoryModalDismissed = false;
    let victorySoundPlayed = false;

    // Elements
    const screens = {{
      menu: document.getElementById('screenMainMenu'),
      config: document.getElementById('screenMatchConfig'),
      join: document.getElementById('screenJoinMatch'),
      lobby: document.getElementById('screenLobby'),
      howto: document.getElementById('screenHowToPlay'),
      settings: document.getElementById('screenSettings'),
      credits: document.getElementById('screenCredits'),
    }};
    const menuBgCanvas = document.getElementById('menuBgCanvas');
    const battlefieldCanvas = document.getElementById('battlefieldCanvas');
    const hudOverlay = document.getElementById('hudOverlay');
    const victoryModal = document.getElementById('victoryModal');
    const minimapCanvas = document.getElementById('minimapCanvas');
    const minimapCtx = minimapCanvas.getContext('2d');

    document.getElementById('menuIdentityBadge').textContent = clientConn.identity.slice(0, 18);

    function showToast(msg, variant = 'info') {{
      const el = document.getElementById('toastBanner');
      el.textContent = msg;
      el.className = 'fixed top-16 left-1/2 -translate-x-1/2 z-50 px-4 py-2 rounded border text-xs font-mono-tech tracking-wide shadow-lg transition-all ' +
        (variant === 'error'
          ? 'bg-rose-950/95 border-rose-500 text-rose-200'
          : 'bg-sky-950/95 border-sky-400 text-sky-200');
      el.classList.remove('hidden');
      clearTimeout(el._timer);
      el._timer = setTimeout(() => el.classList.add('hidden'), 3200);
    }}

    function switchScreen(target) {{
      currentScreen = target;
      Object.entries(screens).forEach(([k, el]) => {{
        if (k === target) {{
          el.classList.remove('hidden');
          if (k !== 'menu') el.classList.add('flex');
        }} else {{
          el.classList.add('hidden');
          el.classList.remove('flex');
        }}
      }});

      if (target === 'game') {{
        menuBgCanvas.classList.add('hidden');
        battlefieldCanvas.classList.remove('hidden');
        hudOverlay.classList.remove('hidden');
        hudOverlay.classList.add('flex');
        resizeBattlefieldCanvas();
      }} else {{
        menuBgCanvas.classList.remove('hidden');
        battlefieldCanvas.classList.add('hidden');
        hudOverlay.classList.add('hidden');
        hudOverlay.classList.remove('flex');
        victoryModal.classList.add('hidden');
        victoryModal.classList.remove('flex');
      }}
    }}

    // Initialize Battlefield Renderer
    const battlefield = new SeaSiegeBattlefieldRenderer(battlefieldCanvas, {{
      audio,
      onSelectEntities: (ids) => {{
        selectedEntityIds = ids;
        renderSelectionInspector();
      }},
      onIssueOrder: (orderArgs) => {{
        if (!currentMatchId) return;
        try {{
          clientConn.reducers.issueShipOrder({{
            matchId: currentMatchId,
            ...orderArgs,
          }});
        }} catch (err) {{
          showToast(err.message, 'error');
        }}
      }},
      onPlaceStructure: ({{ structureType, gridX, gridY, rotationDeg }}) => {{
        if (!currentMatchId) return;
        try {{
          clientConn.reducers.placeStructure({{
            matchId: currentMatchId,
            structureType,
            gridX,
            gridY,
            rotationDeg,
          }});
          audio.playBuildPlace();
          // Keep platform selected for rapid bridge building unless shift is not held and it's a building
          if (structureType !== 'platform') {{
            setBuildMode(null);
          }}
        }} catch (err) {{
          showToast(err.message, 'error');
        }}
      }},
    }});

    function resizeBattlefieldCanvas() {{
      battlefieldCanvas.width = window.innerWidth;
      battlefieldCanvas.height = window.innerHeight;
      menuBgCanvas.width = window.innerWidth;
      menuBgCanvas.height = window.innerHeight;
    }}
    window.addEventListener('resize', resizeBattlefieldCanvas);
    resizeBattlefieldCanvas();

    function getCallsign() {{
      const v = document.getElementById('playerNameInput').value.trim();
      return v || 'Commander Vance';
    }}

    // Subscribe to Authoritative Match State
    function bindToMatch(matchId) {{
      currentMatchId = matchId;
      victoryModalDismissed = false;
      victorySoundPlayed = false;
      clientConn.subscribeToMatch(matchId, (view) => {{
        const wasNull = !latestView || latestView.match.matchId !== view.match.matchId;
        latestView = view;
        battlefield.viewState = view;

        if (wasNull && view.match.status === 'active') {{
          battlefield.centerCameraOnFaction(view);
        }}

        // Update placement preview validity in real time
        if (battlefield.buildMode && view.callerSlotIndex >= 0) {{
          const check = sharedEmbeddedAuthority.validateStructurePlacement(
            matchId,
            view.callerSlotIndex,
            battlefield.buildMode.structureType,
            battlefield.hoverCell.gx,
            battlefield.hoverCell.gy,
            0
          );
          battlefield.buildMode.isValid = check.valid;
          document.getElementById('buildModeStatus').textContent = check.valid
            ? 'LMB: Construct • RMB: Cancel'
            : check.reason;
        }}

        if (currentScreen === 'lobby') {{
          renderLobbyView();
          if (view.match.status === 'active') {{
            switchScreen('game');
            battlefield.centerCameraOnFaction(view);
          }}
        }} else if (currentScreen === 'game') {{
          updateHudFromView();
        }}
      }});
    }}

    // Build Mode Helper
    function setBuildMode(structureType) {{
      activeBuildType = structureType;
      battlefield.buildMode = structureType ? {{ structureType, rotationDeg: 0, isValid: true }} : null;
      document.querySelectorAll('.build-card-btn').forEach((btn) => {{
        if (btn.dataset.struct === structureType) {{
          btn.classList.add('border-sky-400', 'bg-sky-950/60');
        }} else {{
          btn.classList.remove('border-sky-400', 'bg-sky-950/60');
        }}
      }});
      document.getElementById('buildModeStatus').textContent = structureType
        ? `Placing ${{STRUCTURE_DEFS[structureType].name}} (RMB to cancel)`
        : 'Select structure to place';
    }}

    // Populate Construction Buttons
    function initConstructionGrid() {{
      const container = document.getElementById('constructionButtonsGrid');
      container.innerHTML = '';
      const buildableKeys = ['platform', 'shipyard', 'salvage_rig', 'cannon', 'workshop'];
      for (const key of buildableKeys) {{
        const def = STRUCTURE_DEFS[key];
        const btn = document.createElement('button');
        btn.dataset.struct = key;
        btn.className = 'build-card-btn industrial-btn rounded p-1.5 text-left flex flex-col justify-between h-16';
        btn.innerHTML = `
          <div class="flex items-center justify-between">
            <span class="font-mono-tech font-bold text-[10px] text-white">${{def.shortName}}</span>
            <span class="font-mono-tech text-[10px] text-amber-400">${{def.cost}}⚙️</span>
          </div>
          <div class="text-[10px] text-slate-300 leading-tight truncate">${{def.name}}</div>
          <div class="text-[9px] font-mono-tech text-slate-400">${{def.width}}×${{def.height}} ${{def.channel === 'surface' ? 'Surface' : 'On Plat'}}</div>
        `;
        btn.addEventListener('click', () => {{
          audio.playUiClick();
          if (activeBuildType === key) setBuildMode(null);
          else setBuildMode(key);
        }});
        container.appendChild(btn);
      }}
    }}
    initConstructionGrid();

    // Update Active Match HUD
    function updateHudFromView() {{
      if (!latestView) return;
      const view = latestView;
      const mySlot = view.slots.find((s) => s.slotIndex === view.callerSlotIndex);

      if (mySlot) {{
        document.getElementById('hudFactionSwatch').style.backgroundColor = mySlot.factionColor;
        document.getElementById('hudFactionName').textContent = `${{mySlot.playerName}} ${{mySlot.eliminated ? '(ELIMINATED)' : ''}}`;
        document.getElementById('hudSalvageAmount').textContent = Math.floor(mySlot.salvage);
        document.getElementById('hudUpgradeLvl').textContent = mySlot.weaponUpgradeLevel;
      }} else {{
        document.getElementById('hudFactionName').textContent = 'Spectator Mode';
      }}

      document.getElementById('hudMatchCode').textContent = `CODE: ${{view.match.joinCode}} • SEED: ${{view.match.seed}}`;

      const myShips = view.ships.filter((s) => s.factionId === view.callerSlotIndex);
      const myStructs = view.structures.filter((s) => s.factionId === view.callerSlotIndex);
      const activeRigs = myStructs.filter((s) => s.structureType === 'salvage_rig' && s.isComplete && s.isConnected).length;
      const passiveRate = GAME_CONSTANTS.PASSIVE_CORE_SALVAGE_PER_SEC + activeRigs * STRUCTURE_DEFS.salvage_rig.passiveIncomePerSec;
      document.getElementById('hudSalvageRate').textContent = `(+${{passiveRate}}/s)`;
      document.getElementById('hudShipCount').textContent = myShips.length;
      document.getElementById('hudStructCount').textContent = myStructs.length;

      // Clock
      const elapsedSec = Math.max(0, Math.floor((view.nowMs - view.match.startedAtMs) / 1000));
      const mins = String(Math.floor(elapsedSec / 60)).padStart(2, '0');
      const secs = String(elapsedSec % 60).padStart(2, '0');
      document.getElementById('hudClockBadge').textContent = `${{mins}}:${{secs}}`;

      // Faction Scoreboard
      const listEl = document.getElementById('hudFactionList');
      listEl.innerHTML = view.slots
        .filter((s) => s.slotType !== 'empty')
        .map((s) => {{
          const isMe = s.slotIndex === view.callerSlotIndex;
          return `
            <div class="flex items-center justify-between px-1.5 py-0.5 rounded ${{isMe ? 'bg-sky-950/60 border border-sky-500/30' : ''}} ${{s.eliminated ? 'opacity-45 line-through' : ''}}">
              <div class="flex items-center gap-1.5 truncate">
                <span class="w-2 h-2 rounded-full inline-block" style="background:${{s.factionColor}}"></span>
                <span class="truncate text-slate-200">${{s.playerName}}</span>
              </div>
              <span class="text-[10px] text-slate-400">${{s.slotType === 'bot' ? '🤖' : (s.connected ? '🟢' : '🔴')}}</span>
            </div>
          `;
        }})
        .join('');

      renderSelectionInspector();
      renderMinimap();

      // Check Victory Modal
      if (view.match.status === 'finished' && !victoryModalDismissed) {{
        showVictoryModal(view);
      }}
    }}

    function renderSelectionInspector() {{
      const container = document.getElementById('selectionPanelContent');
      if (!latestView) return;
      const view = latestView;

      const selShips = view.ships.filter((s) => selectedEntityIds.includes(s.shipId));
      const selStructs = view.structures.filter((s) => selectedEntityIds.includes(s.structureId));

      if (selShips.length > 0) {{
        const first = selShips[0];
        const def = SHIP_DEFS[first.shipType];
        const isOwned = first.factionId === view.callerSlotIndex;
        container.innerHTML = `
          <div class="flex items-center justify-between border-b border-slate-800 pb-1">
            <span class="font-mono-tech font-bold text-sky-400">${{selShips.length > 1 ? `${{selShips.length}} Naval Vessels Selected` : def.name}}</span>
            <span class="font-mono-tech text-[11px] text-emerald-400">HP: ${{Math.round(first.hp)}}/${{first.maxHp}}</span>
          </div>
          <p class="text-[11px] text-slate-300">${{def.description}}</p>
          ${{isOwned ? `
            <div class="flex flex-wrap gap-1.5 pt-1">
              <button id="btnOrderAttackMove" class="industrial-btn px-2.5 py-1 rounded font-mono-tech text-[10px] text-amber-300">⚔️ Patrol / Attack Center</button>
              <button id="btnOrderHarvestNearest" class="industrial-btn px-2.5 py-1 rounded font-mono-tech text-[10px] text-emerald-300">⚙️ Harvest Nearest Salvage</button>
              <button id="btnOrderStop" class="industrial-btn px-2.5 py-1 rounded font-mono-tech text-[10px] text-rose-300">🛑 Stop Motors</button>
            </div>
          ` : `<div class="text-[10px] font-mono-tech text-rose-400">Hostile Warship // Right-click with your fleet to engage</div>`}}
        `;
        if (isOwned) {{
          document.getElementById('btnOrderStop')?.addEventListener('click', () => {{
            clientConn.reducers.issueShipOrder({{
              matchId: currentMatchId,
              shipIds: selShips.map((s) => s.shipId),
              orderType: 'stop',
            }});
          }});
          document.getElementById('btnOrderAttackMove')?.addEventListener('click', () => {{
            const mid = view.match.mapCells / 2;
            clientConn.reducers.issueShipOrder({{
              matchId: currentMatchId,
              shipIds: selShips.map((s) => s.shipId),
              orderType: 'attack_move',
              targetX: mid,
              targetY: mid,
            }});
            audio.playOrderAck();
          }});
          document.getElementById('btnOrderHarvestNearest')?.addEventListener('click', () => {{
            const nodes = view.resourceNodes.filter((n) => n.remaining > 0);
            if (nodes.length > 0) {{
              nodes.sort((a, b) => Math.hypot(a.gridX - first.x, a.gridY - first.y) - Math.hypot(b.gridX - first.x, b.gridY - first.y));
              clientConn.reducers.issueShipOrder({{
                matchId: currentMatchId,
                shipIds: selShips.map((s) => s.shipId),
                orderType: 'harvest',
                targetX: nodes[0].gridX + 0.5,
                targetY: nodes[0].gridY + 0.5,
              }});
              audio.playOrderAck();
            }}
          }});
        }}
        return;
      }}

      if (selStructs.length > 0) {{
        const st = selStructs[0];
        const def = STRUCTURE_DEFS[st.structureType];
        const isOwned = st.factionId === view.callerSlotIndex;
        const queue = JSON.parse(st.productionQueueJson || '[]');

        let actionsHtml = '';
        if (isOwned && st.structureType === 'shipyard' && st.isComplete && st.isConnected) {{
          actionsHtml = `
            <div class="grid grid-cols-3 gap-1.5 pt-1">
              ${{Object.values(SHIP_DEFS).map((sDef) => `
                <button data-ship="${{sDef.id}}" class="produce-ship-btn industrial-btn p-1.5 rounded text-left">
                  <div class="flex justify-between font-mono-tech text-[10px]">
                    <span class="font-bold text-white">${{sDef.shortName}}</span>
                    <span class="text-amber-400">${{sDef.cost}}⚙️</span>
                  </div>
                  <div class="text-[9px] text-slate-400">HP ${{sDef.maxHp}} • DMG ${{sDef.damage}}</div>
                </button>
              `).join('')}}
            </div>
            <div class="text-[10px] font-mono-tech text-slate-400">
              Queue (${{queue.length}}/${{def.maxQueueSize}}): ${{queue.map((q) => q.shipType.toUpperCase()).join(' → ') || 'Idle'}}
            </div>
          `;
        }} else if (isOwned && st.structureType === 'workshop' && st.isComplete && st.isConnected) {{
          const mySlot = view.slots.find((s) => s.slotIndex === view.callerSlotIndex);
          const lvl = mySlot ? mySlot.weaponUpgradeLevel : 0;
          const upCost = GAME_CONSTANTS.WORKSHOP_UPGRADE_COST * (lvl + 1);
          actionsHtml = `
            <div class="flex items-center justify-between pt-1">
              <span class="text-[11px] font-mono-tech text-slate-300">Aura Repair: +16 HP/s (6 cells)</span>
              ${{lvl < 3 ? `<button id="btnUpgradeFleetWeapons" class="industrial-btn-amber px-2.5 py-1 rounded font-mono-tech text-[10px]">⬆️ Upgrade Weapons (${{upCost}}⚙️)</button>` : `<span class="text-[10px] font-mono-tech text-emerald-400">MAX WEAPON TECH</span>`}}
            </div>
          `;
        }}

        const canDemolish = isOwned && st.structureType !== 'command_core';
        const canRepair = isOwned && st.hp < st.maxHp;

        container.innerHTML = `
          <div class="flex items-center justify-between border-b border-slate-800 pb-1">
            <span class="font-mono-tech font-bold text-sky-400">${{def.name}} ${{!st.isConnected ? '(DISCONNECTED)' : ''}}</span>
            <span class="font-mono-tech text-[11px] text-emerald-400">HP: ${{Math.round(st.hp)}}/${{st.maxHp}}</span>
          </div>
          <p class="text-[11px] text-slate-300">${{def.description}}</p>
          ${{actionsHtml}}
          <div class="flex gap-2 pt-1">
            ${{canRepair ? `<button id="btnRepairStruct" class="industrial-btn px-2.5 py-1 rounded font-mono-tech text-[10px] text-emerald-300">🔧 Repair (+220 HP / 30⚙️)</button>` : ''}}
            ${{canDemolish ? `<button id="btnDemolishStruct" class="industrial-btn px-2.5 py-1 rounded font-mono-tech text-[10px] text-rose-300">🧨 Demolish (Refund)</button>` : ''}}
          </div>
        `;

        container.querySelectorAll('.produce-ship-btn').forEach((btn) => {{
          btn.addEventListener('click', () => {{
            try {{
              clientConn.reducers.queueShipProduction({{
                matchId: currentMatchId,
                structureId: st.structureId,
                shipType: btn.dataset.ship,
              }});
              audio.playUiClick();
            }} catch (err) {{
              showToast(err.message, 'error');
            }}
          }});
        }});

        document.getElementById('btnUpgradeFleetWeapons')?.addEventListener('click', () => {{
          try {{
            clientConn.reducers.upgradeWeapons({{ matchId: currentMatchId }});
            audio.playBuildPlace();
            showToast('Fleet weapon caliber upgraded!', 'info');
          }} catch (err) {{
            showToast(err.message, 'error');
          }}
        }});

        document.getElementById('btnRepairStruct')?.addEventListener('click', () => {{
          try {{
            clientConn.reducers.repairStructure({{ matchId: currentMatchId, structureId: st.structureId }});
            audio.playBuildPlace();
          }} catch (err) {{
            showToast(err.message, 'error');
          }}
        }});

        document.getElementById('btnDemolishStruct')?.addEventListener('click', () => {{
          try {{
            clientConn.reducers.demolishStructure({{ matchId: currentMatchId, structureId: st.structureId }});
            selectedEntityIds = [];
            audio.playExplosion();
          }} catch (err) {{
            showToast(err.message, 'error');
          }}
        }});
        return;
      }}

      // Default unselected tactical summary
      container.innerHTML = `
        <div class="font-mono-tech font-bold text-slate-300 border-b border-slate-800 pb-1">Tactical Command Inspector</div>
        <div class="text-[11px] text-slate-400 space-y-1">
          <div>• Click any friendly <b>Shipyard</b> to queue Scout Hydrofoils, Gunboats, or Siege Monitors.</div>
          <div>• Select or drag-box your <b>Ships</b> and Right-Click water to move, deposits to harvest, or enemies to attack.</div>
          <div>• Build <b>Floating Platforms</b> to expand your connected grid toward Salvage Deposits.</div>
        </div>
      `;
    }}

    // Minimap Rendering & Click-to-Pan
    function renderMinimap() {{
      if (!latestView) return;
      const view = latestView;
      const mw = minimapCanvas.width;
      const mh = minimapCanvas.height;
      const mapCells = view.match.mapCells;
      const scale = mw / mapCells;

      minimapCtx.fillStyle = '#06131f';
      minimapCtx.fillRect(0, 0, mw, mh);

      // Terrain
      if (view.terrainCells) {{
        for (let gy = 0; gy < mapCells; gy += 2) {{
          for (let gx = 0; gx < mapCells; gx += 2) {{
            const t = view.terrainCells[gy * mapCells + gx];
            if (t === TERRAIN_TYPES.RUINED_PILLAR || t === TERRAIN_TYPES.WRECKAGE_SHOAL) {{
              minimapCtx.fillStyle = '#475569';
              minimapCtx.fillRect(gx * scale, gy * scale, 2 * scale, 2 * scale);
            }}
          }}
        }}
      }}

      // Resource Nodes
      for (const nd of view.resourceNodes) {{
        if (nd.remaining <= 0) continue;
        minimapCtx.fillStyle = '#eab308';
        minimapCtx.fillRect(nd.gridX * scale - 1.5, nd.gridY * scale - 1.5, 3, 3);
      }}

      // Structures
      for (const st of view.structures) {{
        const pal = FACTION_PALETTES[st.factionId % FACTION_PALETTES.length];
        minimapCtx.fillStyle = pal.primary;
        minimapCtx.fillRect(st.gridX * scale, st.gridY * scale, Math.max(2, st.width * scale), Math.max(2, st.height * scale));
      }}

      // Ships
      for (const sh of view.ships) {{
        const pal = FACTION_PALETTES[sh.factionId % FACTION_PALETTES.length];
        minimapCtx.fillStyle = '#ffffff';
        minimapCtx.fillRect(sh.x * scale - 1.5, sh.y * scale - 1.5, 3, 3);
        minimapCtx.fillStyle = pal.primary;
        minimapCtx.fillRect(sh.x * scale - 1, sh.y * scale - 1, 2, 2);
      }}

      // Camera Viewport Rectangle
      const ts = GAME_CONSTANTS.TILE_SIZE;
      const camCellX = battlefield.camera.x / ts;
      const camCellY = battlefield.camera.y / ts;
      const camCellW = battlefieldCanvas.width / (ts * battlefield.camera.zoom);
      const camCellH = battlefieldCanvas.height / (ts * battlefield.camera.zoom);
      minimapCtx.strokeStyle = '#38bdf8';
      minimapCtx.lineWidth = 1;
      minimapCtx.strokeRect(camCellX * scale, camCellY * scale, camCellW * scale, camCellH * scale);
    }}

    minimapCanvas.addEventListener('mousedown', (e) => {{
      if (!latestView) return;
      const rect = minimapCanvas.getBoundingClientRect();
      const mx = e.clientX - rect.left;
      const my = e.clientY - rect.top;
      const mapCells = latestView.match.mapCells;
      const cellX = (mx / minimapCanvas.width) * mapCells;
      const cellY = (my / minimapCanvas.height) * mapCells;
      const ts = GAME_CONSTANTS.TILE_SIZE;
      battlefield.camera.x = cellX * ts - battlefieldCanvas.width / (2 * battlefield.camera.zoom);
      battlefield.camera.y = cellY * ts - battlefieldCanvas.height / (2 * battlefield.camera.zoom);
    }});

    // Render Lobby Screen
    function renderLobbyView() {{
      if (!latestView) return;
      const view = latestView;
      document.getElementById('lobbyJoinCodeDisplay').textContent = view.match.joinCode;
      document.getElementById('lobbyTitle').textContent = `${{view.match.preset}} Theater Lobby (${{view.match.maxSlots}} Slots • Seed ${{view.match.seed}})`;

      const container = document.getElementById('lobbySlotsContainer');
      container.innerHTML = view.slots.map((slot) => {{
        const isHost = view.match.hostIdentity === clientConn.identity;
        const isSelf = slot.occupantIdentity === clientConn.identity;
        return `
          <div class="bg-slate-900/90 border ${{isSelf ? 'border-sky-400' : 'border-slate-800'}} rounded-lg p-3 flex items-center justify-between">
            <div class="flex items-center gap-2.5">
              <div class="w-4 h-4 rounded" style="background:${{slot.factionColor}}"></div>
              <div>
                <div class="text-xs font-bold text-white">Slot #${{slot.slotIndex + 1}}: ${{slot.playerName}}</div>
                <div class="text-[10px] font-mono-tech text-slate-400 uppercase">${{slot.slotType}} ${{slot.slotType === 'bot' ? `(${{slot.botDifficulty}})` : ''}} • ${{slot.ready ? 'READY' : 'NOT READY'}}</div>
              </div>
            </div>
            <div class="flex items-center gap-1">
              ${{slot.slotType === 'empty' ? `<button data-claim="${{slot.slotIndex}}" class="claim-slot-btn industrial-btn px-2 py-1 rounded text-[10px] font-mono-tech text-sky-300">Claim</button>` : ''}}
              ${{isHost && !isSelf ? `
                <button data-bot="${{slot.slotIndex}}" class="set-bot-btn industrial-btn px-2 py-1 rounded text-[10px] font-mono-tech text-amber-300">Bot</button>
                <button data-empty="${{slot.slotIndex}}" class="set-empty-btn industrial-btn px-2 py-1 rounded text-[10px] font-mono-tech text-slate-400">Clear</button>
              ` : ''}}
            </div>
          </div>
        `;
      }}).join('');

      container.querySelectorAll('.claim-slot-btn').forEach((btn) => {{
        btn.addEventListener('click', () => {{
          try {{
            clientConn.reducers.claimSlot({{
              matchId: currentMatchId,
              slotIndex: Number(btn.dataset.claim),
              playerName: getCallsign(),
            }});
          }} catch (err) {{ showToast(err.message, 'error'); }}
        }});
      }});
      container.querySelectorAll('.set-bot-btn').forEach((btn) => {{
        btn.addEventListener('click', () => {{
          try {{
            clientConn.reducers.configureLobbySlot({{
              matchId: currentMatchId,
              slotIndex: Number(btn.dataset.bot),
              slotType: 'bot',
              botDifficulty: document.getElementById('cfgBotDifficulty').value,
            }});
          }} catch (err) {{ showToast(err.message, 'error'); }}
        }});
      }});
      container.querySelectorAll('.set-empty-btn').forEach((btn) => {{
        btn.addEventListener('click', () => {{
          try {{
            clientConn.reducers.configureLobbySlot({{
              matchId: currentMatchId,
              slotIndex: Number(btn.dataset.empty),
              slotType: 'empty',
            }});
          }} catch (err) {{ showToast(err.message, 'error'); }}
        }});
      }});
    }}

    function showVictoryModal(view) {{
      victoryModal.classList.remove('hidden');
      victoryModal.classList.add('flex');
      const isWinner = view.match.winnerFactionId === view.callerSlotIndex;
      if (!victorySoundPlayed) {{
        victorySoundPlayed = true;
        audio.playVictory(isWinner);
      }}
      document.getElementById('victoryHeadline').textContent = isWinner
        ? 'NAVAL SUPREMACY ACHIEVED'
        : (view.isSpectator ? 'MATCH CONCLUDED' : 'COMMAND CORE DESTROYED');
      document.getElementById('victoryHeadline').className = 'text-2xl md:text-3xl font-extrabold ' +
        (isWinner ? 'text-emerald-400' : 'text-amber-400');
      document.getElementById('victorySubtext').textContent = view.match.victoryReason;

      const tbody = document.getElementById('victoryScoreTableBody');
      tbody.innerHTML = view.slots
        .filter((s) => s.slotType !== 'empty')
        .map((s) => `
          <tr class="border-b border-slate-800/60 ${{s.slotIndex === view.match.winnerFactionId ? 'bg-emerald-950/30 text-emerald-200' : 'text-slate-300'}}">
            <td class="py-2 px-2 flex items-center gap-2">
              <span class="w-2.5 h-2.5 rounded-full inline-block" style="background:${{s.factionColor}}"></span>
              <span>${{s.playerName}}</span>
            </td>
            <td class="py-2 px-2">${{s.slotIndex === view.match.winnerFactionId ? '🏆 VICTOR' : (s.eliminated ? 'Eliminated' : 'Survived')}}</td>
            <td class="py-2 px-2 text-right">${{Math.round(s.totalSalvageGathered)}}</td>
            <td class="py-2 px-2 text-right">${{s.structuresBuilt}}</td>
            <td class="py-2 px-2 text-right">${{s.shipsBuilt}}</td>
            <td class="py-2 px-2 text-right">${{s.enemiesDestroyed}}</td>
          </tr>
        `).join('');
    }}

    // --- BUTTON LISTENERS ---
    document.getElementById('btnQuickPlay').addEventListener('click', () => {{
      audio.playUiClick();
      const res = clientConn.reducers.quickPlay({{
        playerName: getCallsign(),
        preset: 'Skirmish',
        botDifficulty: 'Commander',
      }});
      bindToMatch(res.matchId);
      switchScreen('game');
      showToast(`Deployed into Skirmish Match (Join Code: ${{res.joinCode}})`);
    }});

    document.getElementById('btnOpenCreateMatch').addEventListener('click', () => {{
      audio.playUiClick();
      switchScreen('config');
    }});

    document.getElementById('btnPlayVsBots').addEventListener('click', () => {{
      audio.playUiClick();
      switchScreen('config');
    }});

    document.getElementById('btnOpenJoinMatch').addEventListener('click', () => {{
      audio.playUiClick();
      // List any existing active lobbies for convenience
      const list = [];
      for (const m of sharedEmbeddedAuthority.matches.values()) {{
        if (m.status !== 'finished') list.push(`${{m.joinCode}} (${{m.preset}} - ${{m.status}})`);
      }}
      document.getElementById('activeLobbiesList').textContent = list.length > 0
        ? `Active Server Matches: ${{list.join(' • ')}}`
        : 'Tip: Create a lobby first or enter an active Join Code.';
      switchScreen('join');
    }});

    document.getElementById('btnOpenHowToPlay').addEventListener('click', () => {{
      audio.playUiClick();
      switchScreen('howto');
    }});
    document.getElementById('btnOpenSettings').addEventListener('click', () => {{
      audio.playUiClick();
      switchScreen('settings');
    }});
    document.getElementById('btnOpenCredits').addEventListener('click', () => {{
      audio.playUiClick();
      switchScreen('credits');
    }});

    document.getElementById('btnBackFromConfig').addEventListener('click', () => switchScreen('menu'));
    document.getElementById('btnBackFromJoin').addEventListener('click', () => switchScreen('menu'));
    document.getElementById('btnCloseHowTo').addEventListener('click', () => switchScreen('menu'));
    document.getElementById('btnCloseSettings').addEventListener('click', () => switchScreen('menu'));
    document.getElementById('btnCloseCredits').addEventListener('click', () => switchScreen('menu'));

    // Preset selector buttons
    let selectedPreset = 'Skirmish';
    document.querySelectorAll('.preset-btn').forEach((btn) => {{
      btn.addEventListener('click', () => {{
        audio.playUiClick();
        selectedPreset = btn.dataset.preset;
        const cfg = MATCH_PRESETS[selectedPreset];
        document.getElementById('cfgMaxSlots').value = cfg.maxSlots;
        document.getElementById('cfgBotCount').value = cfg.defaultBots;
        document.querySelectorAll('.preset-btn').forEach((b) => b.classList.remove('border-sky-400'));
        btn.classList.add('border-sky-400');
      }});
    }});

    document.getElementById('btnRandomSeed').addEventListener('click', () => {{
      document.getElementById('cfgMapSeed').value = Math.floor(100000 + Math.random() * 899999);
    }});

    function createConfiguredMatch(startImmediately) {{
      const maxSlots = Number(document.getElementById('cfgMaxSlots').value) || 4;
      const botCount = Number(document.getElementById('cfgBotCount').value) || 1;
      const botDifficulty = document.getElementById('cfgBotDifficulty').value;
      const seed = Number(document.getElementById('cfgMapSeed').value) || 778899;
      const fogOfWarEnabled = document.getElementById('cfgFogOfWar').checked;
      const botOnly = document.getElementById('cfgBotOnlySpectate').checked;

      const res = clientConn.reducers.createMatch({{
        preset: selectedPreset,
        maxSlots,
        botCount,
        botDifficulty,
        seed,
        playerName: getCallsign(),
        fogOfWarEnabled,
        botOnly,
      }});
      bindToMatch(res.matchId);
      if (startImmediately) {{
        clientConn.reducers.startMatch({{ matchId: res.matchId }});
        switchScreen('game');
      }} else {{
        switchScreen('lobby');
      }}
    }}

    document.getElementById('btnOpenLobbyFromConfig').addEventListener('click', () => {{
      audio.playUiClick();
      try {{ createConfiguredMatch(false); }} catch (err) {{ showToast(err.message, 'error'); }}
    }});

    document.getElementById('btnLaunchImmediateFromConfig').addEventListener('click', () => {{
      audio.playUiClick();
      try {{ createConfiguredMatch(true); }} catch (err) {{ showToast(err.message, 'error'); }}
    }});

    document.getElementById('btnSubmitJoinCode').addEventListener('click', () => {{
      audio.playUiClick();
      try {{
        const code = document.getElementById('joinCodeField').value.trim();
        const res = clientConn.reducers.joinMatchByCode({{
          joinCode: code,
          playerName: getCallsign(),
        }});
        bindToMatch(res.matchId);
        const view = clientConn.getAuthorizedView(res.matchId);
        switchScreen(view.match.status === 'active' ? 'game' : 'lobby');
      }} catch (err) {{
        showToast(err.message, 'error');
      }}
    }});

    document.getElementById('btnCopyJoinCode').addEventListener('click', () => {{
      if (!latestView) return;
      try {{
        const temp = document.createElement('input');
        temp.value = latestView.match.joinCode;
        document.body.appendChild(temp);
        temp.select();
        document.execCommand('copy');
        document.body.removeChild(temp);
        showToast(`Copied Join Code: ${{latestView.match.joinCode}}`);
      }} catch {{}}
    }});

    document.getElementById('btnLeaveLobby').addEventListener('click', () => switchScreen('menu'));

    document.getElementById('btnToggleReady').addEventListener('click', () => {{
      if (!latestView) return;
      const mySlot = latestView.slots.find((s) => s.slotIndex === latestView.callerSlotIndex);
      if (mySlot) {{
        clientConn.reducers.setPlayerReady({{ matchId: currentMatchId, ready: !mySlot.ready }});
      }}
    }});

    document.getElementById('btnSimulateSecondHuman').addEventListener('click', () => {{
      if (!latestView) return;
      try {{
        const peerConn = new DbConnection({{
          identity: 'stdb_peer_' + (secondaryClients.length + 2),
          serverInstance: sharedEmbeddedAuthority,
        }});
        secondaryClients.push(peerConn);
        peerConn.reducers.joinMatchByCode({{
          joinCode: latestView.match.joinCode,
          playerName: `Allied Cmdr #${{secondaryClients.length + 1}}`,
        }});
        showToast('Second human client connected via SpacetimeDB join code!');
      }} catch (err) {{
        showToast(err.message, 'error');
      }}
    }});

    document.getElementById('btnStartMatchFromLobby').addEventListener('click', () => {{
      try {{
        clientConn.reducers.startMatch({{ matchId: currentMatchId }});
        switchScreen('game');
      }} catch (err) {{
        showToast(err.message, 'error');
      }}
    }});

    // Top HUD Controls
    document.getElementById('btnCenterBase').addEventListener('click', () => {{
      battlefield.centerCameraOnFaction(latestView);
    }});

    document.getElementById('btnToggleReconnectSim').addEventListener('click', (e) => {{
      const btn = e.currentTarget;
      if (clientConn.connected) {{
        clientConn.disconnect();
        btn.textContent = '🔌 Disconnected (Click to Reconnect)';
        btn.classList.replace('text-emerald-300', 'text-rose-400');
        showToast('Client disconnected from SpacetimeDB. Click again to restore session via identity token.', 'error');
      }} else {{
        clientConn.reconnect();
        btn.textContent = '🔌 Connected';
        btn.classList.replace('text-rose-400', 'text-emerald-300');
        showToast('Identity verified! Authoritative match ownership and state restored.');
      }}
    }});

    document.getElementById('btnLateJoinSim').addEventListener('click', () => {{
      if (!latestView) return;
      try {{
        const lateClient = new DbConnection({{
          identity: 'stdb_latejoin_' + Date.now(),
          serverInstance: sharedEmbeddedAuthority,
        }});
        const res = lateClient.reducers.joinMatchByCode({{
          joinCode: latestView.match.joinCode,
          playerName: 'Reinforcement Cmdr',
        }});
        if (res.tookOverBot) {{
          showToast(`Late-Joiner took over Slot #${{res.slotIndex + 1}} from AI Bot!`);
        }} else {{
          showToast('Late-Joiner connected in Spectator Mode (no Bot slots remaining).');
        }}
      }} catch (err) {{
        showToast(err.message, 'error');
      }}
    }});

    document.getElementById('btnMuteHud').addEventListener('click', (e) => {{
      audio.setMuted(!audio.muted);
      e.currentTarget.textContent = audio.muted ? '🔇' : '🔊';
      document.getElementById('setMuteToggle').checked = audio.muted;
    }});

    document.getElementById('btnSurrenderMatch').addEventListener('click', () => {{
      if (!currentMatchId) return;
      try {{
        clientConn.reducers.surrenderMatch({{ matchId: currentMatchId }});
        showToast('Command Core scuttled. Entering spectator view.');
      }} catch (err) {{
        showToast(err.message, 'error');
      }}
    }});

    document.getElementById('btnExitToMenu').addEventListener('click', () => {{
      switchScreen('menu');
    }});

    // Victory Modal Buttons
    document.getElementById('btnSpectateAfterEnd').addEventListener('click', () => {{
      victoryModalDismissed = true;
      victoryModal.classList.add('hidden');
      victoryModal.classList.remove('flex');
    }});

    document.getElementById('btnRematchSameSeed').addEventListener('click', () => {{
      if (!latestView) return;
      const m = latestView.match;
      const res = clientConn.reducers.createMatch({{
        preset: m.preset,
        maxSlots: m.maxSlots,
        botCount: m.maxSlots - 1,
        seed: m.seed,
        playerName: getCallsign(),
        fogOfWarEnabled: m.fogOfWarEnabled,
      }});
      bindToMatch(res.matchId);
      clientConn.reducers.startMatch({{ matchId: res.matchId }});
      victoryModal.classList.add('hidden');
      victoryModal.classList.remove('flex');
    }});

    document.getElementById('btnNewRematch').addEventListener('click', () => {{
      if (!latestView) return;
      const m = latestView.match;
      const res = clientConn.reducers.createMatch({{
        preset: m.preset,
        maxSlots: m.maxSlots,
        botCount: m.maxSlots - 1,
        seed: Math.floor(100000 + Math.random() * 899999),
        playerName: getCallsign(),
        fogOfWarEnabled: m.fogOfWarEnabled,
      }});
      bindToMatch(res.matchId);
      clientConn.reducers.startMatch({{ matchId: res.matchId }});
      victoryModal.classList.add('hidden');
      victoryModal.classList.remove('flex');
    }});

    // Settings Controls
    document.getElementById('setMuteToggle').addEventListener('change', (e) => {{
      audio.setMuted(e.target.checked);
      document.getElementById('btnMuteHud').textContent = audio.muted ? '🔇' : '🔊';
    }});
    document.getElementById('setSfxSlider').addEventListener('input', (e) => {{
      const v = Number(e.target.value);
      document.getElementById('sfxVolLabel').textContent = `${{v}}%`;
      audio.setVolumes({{ sfx: v / 100 }});
    }});
    document.getElementById('setMusicSlider').addEventListener('input', (e) => {{
      const v = Number(e.target.value);
      document.getElementById('musicVolLabel').textContent = `${{v}}%`;
      audio.setVolumes({{ music: v / 100 }});
    }});
    document.getElementById('setGraphicsQuality').addEventListener('change', (e) => {{
      battlefield.graphicsQuality = e.target.value;
    }});
    document.getElementById('setEdgeScroll').addEventListener('change', (e) => {{
      battlefield.edgeScrollEnabled = e.target.checked;
    }});

    // Keyboard Shortcuts (WASD / Arrows pan, Space center, Escape cancel build mode, 1-5 build hotkeys)
    window.addEventListener('keydown', (e) => {{
      if (currentScreen !== 'game') return;
      if (e.target && (e.target.tagName === 'INPUT' || e.target.tagName === 'SELECT')) return;
      battlefield.keysDown.add(e.key.toLowerCase());
      if (e.key === 'Escape') setBuildMode(null);
      if (e.key === ' ') {{
        e.preventDefault();
        battlefield.centerCameraOnFaction(latestView);
      }}
      const hotkeys = {{ '1': 'platform', '2': 'shipyard', '3': 'salvage_rig', '4': 'cannon', '5': 'workshop' }};
      if (hotkeys[e.key]) {{
        setBuildMode(activeBuildType === hotkeys[e.key] ? null : hotkeys[e.key]);
      }}
    }});
    window.addEventListener('keyup', (e) => {{
      battlefield.keysDown.delete(e.key.toLowerCase());
    }});

    // Authoritative Server Simulation Loop (5 Hz = 200ms)
    setInterval(() => {{
      sharedEmbeddedAuthority.stepSimulation(GAME_CONSTANTS.SIMULATION_TICK_MS);
    }}, GAME_CONSTANTS.SIMULATION_TICK_MS);

    // 60 FPS Render Loop & Menu Ocean Background Animation
    let lastFrameMs = performance.now();
    function frameLoop(nowMs) {{
      const dtSec = Math.min(0.1, (nowMs - lastFrameMs) / 1000);
      lastFrameMs = nowMs;

      if (currentScreen === 'game') {{
        // Handle keyboard & optional edge camera panning
        const panSpeed = (420 / battlefield.camera.zoom) * dtSec;
        if (battlefield.keysDown.has('w') || battlefield.keysDown.has('arrowup')) battlefield.camera.y -= panSpeed;
        if (battlefield.keysDown.has('s') || battlefield.keysDown.has('arrowdown')) battlefield.camera.y += panSpeed;
        if (battlefield.keysDown.has('a') || battlefield.keysDown.has('arrowleft')) battlefield.camera.x -= panSpeed;
        if (battlefield.keysDown.has('d') || battlefield.keysDown.has('arrowright')) battlefield.camera.x += panSpeed;

        if (battlefield.hoverCell.gx >= 0) {{
          document.getElementById('hudCoordsLabel').textContent = `X: ${{battlefield.hoverCell.gx}} Y: ${{battlefield.hoverCell.gy}}`;
        }}
        battlefield.render(dtSec, nowMs);
      }} else {{
        // Render atmospheric animated ocean background behind menus
        const ctx = menuBgCanvas.getContext('2d');
        const w = menuBgCanvas.width;
        const h = menuBgCanvas.height;
        ctx.fillStyle = '#040d17';
        ctx.fillRect(0, 0, w, h);
        const t = nowMs * 0.001;
        const step = 48;
        for (let y = 0; y < h; y += step) {{
          for (let x = 0; x < w; x += step) {{
            const v = Math.sin(x * 0.012 + t) * 0.5 + Math.cos(y * 0.015 - t * 0.7) * 0.5;
            if (v > 0.35) {{
              ctx.fillStyle = 'rgba(12, 39, 60, 0.55)';
              ctx.fillRect(x, y, step - 2, step - 2);
            }}
          }}
        }}
      }}
      requestAnimationFrame(frameLoop);
    }}
    requestAnimationFrame(frameLoop);
  }})();
  </script>
</body>
</html>
"""

open(OUT_INTERMEDIATE, "w").write(html_template)
open(OUT_FINAL, "w").write(html_template)
print(f"Built {OUT_FINAL} ({len(html_template)} bytes)")
